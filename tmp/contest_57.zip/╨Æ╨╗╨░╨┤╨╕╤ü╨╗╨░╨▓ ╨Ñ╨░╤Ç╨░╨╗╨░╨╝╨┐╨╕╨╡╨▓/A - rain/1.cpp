#include <iostream>
#include <cstdio>
#include <algorithm>
#define BASE 18
#define null 1000000
using namespace std;
int N,L,K;
int sak[100010],cap[100010];
// RMQ
int s2[BASE],up[100010];
void init(){
  s2[0]=1;
  for(int i=1;i<BASE;i++)s2[i]=s2[i-1]<<1;
  up[1]=0;
  for(int i=2;i<100002;i++){
   up[i]=up[i-1];
   while(s2[up[i]]<=i)up[i]++;up[i]--;
                           }
}
int R[100010][BASE];
void init_RMQ(int drop){
  int i,j;
  R[L][0]=j=0;
  for(i=L-1;i>=0;i--)
   if(cap[i]<=drop)R[i][0]=++j;
   else R[i][0]=j=0;
  for(j=1;j<BASE;j++){
   for(i=0;i<L;i++){
     R[i][j]=R[i][j-1];
     if(i+s2[j-1]<L)R[i][j]=max(R[i][j],R[i+s2[j-1]][j-1]);
                   }
   if(s2[j]>L)break;
                     }
}
int get(int f,int t){
  int S=up[t-f+1];
  return max(R[f][S],R[t-s2[S]+1][S]);
}
int get_first(int f,int w){
  if(get(f,L-1)<w)return null;
  if(R[f][0]>=w)return f;
  short int S=up[L-f];
  while(1){
    while(S>=0){if(R[f][S]<w)break;S--;}
    if(S<0)return f;
    else f+=s2[S];
          }
  return f;
}
// </end>
// REAL SOLUTION
int DP[100010][21];
bool try_drop(int how){
  int i,j,pos,np;
  init_RMQ(how);
  for(i=0;i<=L;i++)for(j=0;j<=K;j++)DP[i][j]=-1;
  DP[0][K]=0;
  for(i=0;i<L;i++)
   for(j=0;j<=K;j++){
    pos=DP[i][j];np=pos+1;
    if(pos>=N)return true;if(pos<0)continue;
    // putting risky
    if(i+sak[pos]<=L && j>0)
     if(DP[i+sak[pos]][j-1]<np){DP[i+sak[pos]][j-1]=np;if(np>=N)return true;}
    // putting safe
    int dest=get_first(i,sak[pos]);
    if(dest+sak[pos]<=L)
     if(DP[dest+sak[pos]][j]<np){DP[dest+sak[pos]][j]=np;if(np>=N)return true;}
                    }
  return false;
}
int bin_find(int f,int t){
  int m,ret=null;
  while(f<=t){
   m=(f+t)/2;
   if(try_drop(m)){ret=min(m,ret);t=m-1;}
   else f=m+1;
             }
  return ret;
}
int main(){
  init();
  int i,j;
  //system("pause");
  scanf("%d%d%d",&N,&L,&K);
  for(i=0;i<N;i++)scanf("%d",&sak[i]);
  for(i=0;i<L;i++)scanf("%d",&cap[i]);
  printf("%d\n",bin_find(0,100001));
  //system("pause");
  return 0;
}
