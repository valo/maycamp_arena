/*
LANG: C++
TASK: rain
AUTH: Alexander Georgiev
COMP: Spring National Contest
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <set>

#define MAX_K 22
#define MAX_N 100002
#define MAX_L 100002

#define LEVELS 18
#define TABLE MAX_L
#define INF 999666333

using namespace std;
FILE *in; FILE *out;

int n, l, k;
int a[MAX_N], b[MAX_L];
int best[MAX_L][MAX_K];
int tree[LEVELS][TABLE];
int maxPower[MAX_L];

int findPos(int cap, int idx)
{
	if (tree[LEVELS-1][idx] < cap) return INF;
	if (tree[0][idx] >= cap) return idx;
	
	int pwr = maxPower[l - 1 - idx] + 1;
	while (pwr)
	{
		while (pwr > 0 && tree[pwr][idx] >= cap) pwr--;
		if (tree[pwr][idx] < cap) idx += (1 << pwr);
	}
	return idx;
}
int br=0;
int eval(int cap)
{
	int cnt = 0;
	for (int i = l - 1; i >= 0; i--)
	{
		if (b[i] > cap) tree[0][i] = cnt = 0;
		else tree[0][i] = ++cnt;
	}
	for (int i = 1; i < LEVELS; i++)
	{
		int size = (1 << (i - 1));
		for (int c = 0; c + size < l; c++)
			tree[i][c] = max(tree[i - 1][c], tree[i - 1][c + size]);
		for (int c = l - size; c < l; c++)
			tree[i][c] = tree[i - 1][c];
	}
	
	memset(best, -1, sizeof(best));
	best[0][k] = 0;
	for (int i = 0; i < l; i++)
	{
		for (int c = 0; c <= k; c++) if (best[i][c] != -1)
		{
			int cur = best[i][c];
                  br++;
			// Let acid fall into current flower pot
			if (c > 0 && i + a[cur] <= l)
			{
				if (cur + 1 == n) return 1;
				best[i + a[cur]][c - 1] = max(best[i + a[cur]][c - 1], cur + 1);
			}
			
			// Find a safe place for the current flower pot
			int pos = findPos(a[cur], i);
			if (pos + a[cur] <= l)
			{
				if (cur + 1 == n) return 1;
				best[pos + a[cur]][c] = max(best[pos + a[cur]][c], cur + 1);
			}
		}
	}
	return 0;
}

int main(void)
{
//	unsigned sTime = clock();
	in = stdin; out = stdout;
//	in = fopen("Rain.in", "rt"); out = fopen("Rain.out", "wt");
	
	fscanf(in, "%d %d %d", &n, &l, &k);
	for (int i = 0; i < n; i++) fscanf(in, "%d", &a[i]);
	for (int i = 0; i < l; i++) fscanf(in, "%d", &b[i]);
	
	maxPower[0] = 0; maxPower[1] = 0;
	int next = 2, pwr = 0;
	for (int i = 2; i < MAX_L; i++)
	{
		if (i == next) {pwr++; next <<= 1;}
		maxPower[i] = pwr;
	}
	
	int ans = INF;
	int left = 0, right = 100000;
	while (left <= right)
	{
		int mid = (left + right) / 2;
		if (eval(mid)) {ans = min(ans, mid); right = mid - 1;}
		else left = mid + 1;
	}
	fprintf(out, "%d\n", ans);	
//	fprintf(stderr, "Execution time: %.3lfs\n", (double)(clock() - sTime) / (double)CLOCKS_PER_SEC); system("pause");
      printf("%d\n",br);
	return 0;
}
