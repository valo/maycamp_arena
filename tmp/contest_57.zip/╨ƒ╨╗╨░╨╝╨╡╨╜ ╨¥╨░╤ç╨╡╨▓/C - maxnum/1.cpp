#include<iostream>
#include<algorithm>
using namespace std;
unsigned int a[1000000];
int main ()
{ int n,i;

cin>>n;

for(i=0; i<n; i++)
cin>>a[i];

sort(a,a+n);

for(i=0; i<n; i++)
cout<<a[i];
cout<<endl;

cin>>n;
return 0;
}
