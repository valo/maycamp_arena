/*

  ID: nigo1

  LANG: C++

  TASK: pass

*/

#include <iostream>

#include <stdio.h>

#include <math.h>

#include <algorithm>

#include <vector>

#include <cstring>

#include <map>

#include <queue>

#include <set>

#include <stack>



#define pf printf

#define sf scanf

#define TIME pf("%f", (double)clock()/CLOCKS_PER_SEC);



using namespace std;



int N;
char c[21];
long long num [20], ans = 1;


int main()

{

	//freopen ("pass.in", "r", stdin);

	//freopen ("pass.out", "w", stdout);

    sf ("%s", &c);

    N = strlen (c);

    sort (c, c + N);
    int unique = 1;
    num[0] = 1;
    for (int i = 1; i < N; i++)
        if (c[i] != c[i - 1]) num[unique++] = 1;
        else num[unique - 1]++;

    if (N == 3) pf ("%i\n", unique != 1 ? 3 : 1);
    else {
        for (int i = 2; i <= N; i++) ans *= i;

        for (int i = 0; i < unique; i++) {
            int fact = 1;
            for (int j = 1; j <= num[i]; j++)
                fact *= j;
            ans /= fact;
        }

        pf ("%lld\n", ans);
    }
}
