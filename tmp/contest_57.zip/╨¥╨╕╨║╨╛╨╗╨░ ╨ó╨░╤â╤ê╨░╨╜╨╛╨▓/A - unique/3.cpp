/*
  ID: nigo1
  LANG: C++
  TASK:
*/
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <cstring>
#include <map>
#include <queue>
#include <set>
#include <stack>

#define pf printf
#define sf scanf
#define MAX_N 1e+14
#define TIME pf("%f", (double)clock()/CLOCKS_PER_SEC);

using namespace std;

long long N;
long long DP[64][8][8][8];

long long dp (int pos, int maxsum, int minsum, int sum) {
    long long &res = DP[pos][minsum + 3][maxsum + 3][sum + 3];

    if (res != -1) return res;
    if (pos == 0) return 1;

    res = 0;
    //put 'a' on position pos
    int tmp = sum + 1;
    if (abs(tmp) <= 3)
        if (abs(tmp - minsum) <= 3 && abs(tmp - maxsum) <= 3 && max(maxsum, tmp) - minsum <= 3)
            res += dp (pos - 1, max(maxsum, tmp), minsum, tmp);

    //put 'b' on position pos
    tmp = sum - 1;
    if (abs(tmp) <= 3)
        if (abs(tmp - minsum) <= 3 && abs(tmp - maxsum) <= 3 && maxsum - min(minsum, tmp) <= 3)
            res += dp (pos - 1, maxsum, min(tmp, minsum), tmp);

    return res;
}

bool ans[128];

void find_ans (long long n, int pos, int maxsum, int minsum, int sum) {
    if (!pos) return;

    long long cnt = 0;

    //put 'a' on position pos
    int tmp = sum + 1;
    if (abs(tmp) <= 3)
        if (abs(tmp - minsum) <= 3 && abs(tmp - maxsum) <= 3 && max(maxsum, tmp) - minsum <= 3) {
            cnt = dp (pos - 1, max(maxsum, tmp), minsum, tmp);
            if (cnt >= n) {
                find_ans (cnt == n ? 0 : n, pos - 1, max(maxsum, tmp), minsum, tmp);
                if (n) return;
            } else n -= cnt;
        }

    //put 'b' on position pos
    tmp = sum - 1;
    if (abs(tmp) <= 3)
        if (abs(tmp - minsum) <= 3 && abs(tmp - maxsum) <= 3 && maxsum - min(minsum, tmp) <= 3) {
            cnt = dp (pos - 1, maxsum, min(tmp, minsum), tmp);
            ans[pos] = 1;
            find_ans (cnt == n ? 0 : n, pos - 1, maxsum, min(tmp, minsum), tmp);
        }
}

int main()
{
	//freopen (".in", "r", stdin);
	//freopen (".out", "w", stdout);
    memset (DP, -1, sizeof (DP));
    sf ("%lld", &N);

    long long cnt = 0, len = 0;
    for (int i = 1; i < 64 && !len; i++)
        if ((cnt += dp(i, 0, 0, 0)) >= N) len = i;

    if (len > 1) N -= cnt - dp (len, 0, 0, 0);

    find_ans (N, len, 0, 0, 0);

    for (int i = 0; i < len; i++) pf ("%c", 'a' + ans[len - i]);
    pf ("\n");
}

