#include <iostream>
using namespace std;

int x, y, k, p[2000];
string sum, w;

void c()
{
int i, j;
for(i = max(x, y) + 1; i <= x+y; i++)
      {
      j = i;
      for(k=2; k*k<=i; k++)
      while(j % k == 0) j /= k, p[k]++;
      p[j] += (j != 1);
      }
for(i = 2; i <= min(x, y); i++)
      {
      j = i;
      for(k=2; k*k<=i; k++)
      while(j % k == 0) j /= k, p[k]--;
      p[j] -= (j != 1);
      }
}

string preo(int x)
{
string s;
while(x) s += x % 10 + '0', x /= 10;
reverse(s.begin(), s.end());
return s;
}

string sub(string a, string b)
{
int i, as = a.size(), bs = b.size(), mx = max(as, bs), naum = 0;
string c(mx - as, '0'), d(mx - bs, '0'), e;
c += a, d += b;
for(i=mx-1; i>=0; i--)
{
e += (c[i] + d[i] - 96 + naum)%10 + '0';
naum = (c[i] + d[i] - 96 + naum) / 10;
}
if(naum) e += naum + '0';
reverse(e.begin(), e.end());
return e;
}

string umn1(string a, int b)
{
string c;
int i, as = a.size(), naum = 0;
for(i=as-1; i>=0; i--)
{
c += ((a[i] - '0') * b + naum) % 10 + '0';
naum = ((a[i] - '0') * b + naum) / 10;
}
if(naum) c += naum + '0';
reverse(c.begin(), c.end());
return c;
}

string umn(string a, int b)
{
int i, br = 0, dig[4];
while(b) dig[br++] = b % 10, b /= 10;
string ans = "0";
for(i=0; i<br; i++)
{
string e(i, '0');
ans = sub(ans, umn1(a, dig[i]) + e);
}
return ans;
}
string del(string a, int b, bool fl)
{
string c;
int as = a.size(), i, x=0;
for(i=0; i<as; i++)
{
if(a[i] == '.') { c += "."; continue; }
x = x * 10 + a[i] - '0';
if(x >= b) { c += x / b + '0', x %= b; break; }
}

for(++i; i<as; i++)
{
if(a[i] == '.') { c += "."; continue; }
x = x * 10 + a[i] - '0';
c += x / b + '0';
x %= b;
}
if(!fl) return c;
c += ".";
for(i=0; i<4; i++)
{
x = x * 10;
c += x / b + '0';
x %= b;
}
return c;
}

double preobr(string sum)
{
double ans = 0;
int i;
k = sum.size();
for(i=0; i<k && sum[i] != '.'; i++) ans = ans * 10 + sum[i] - '0';
int x = i+5, r = 10;
for(++i; i < k && i < x; i++) ans += double(sum[i] - '0') / double(r), r *= 10;
return ans;
}

void solve()
{
int i, j;
for(i=2; i<2000; i++)
if(p[i])
{
k = 1;
for(j=0; j<p[i]; j++) k *= i;
sum = del(sum, k, 1);
break;
}
for(++i; i<2000; i++)
if(p[i])
{
k = 1;
for(j=0; j<p[i]; j++) k *= i;
sum = del(sum, k, 0);
}
printf("%.3lf\n", preobr(sum));
}

int main()
{
int i;
scanf("%d%d", &x, &y);
c();
sum = w = preo(x);
sum = sub(sum, umn(w, x+1));
for(i=x+2; i<=x+y; i++)
           {
           w = umn(w, i-1);
           w = del(w, i-x, 0);
           sum = sub(sum, umn(w, i));
           }
solve();
return 0;
}
