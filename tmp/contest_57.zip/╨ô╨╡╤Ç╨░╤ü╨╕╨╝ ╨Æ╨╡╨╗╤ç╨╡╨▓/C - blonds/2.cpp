#include <iostream>
#include <cstring>
using namespace std;

int p[2000];

double c(int a, int b)
{
double ans = 1;
int i, j, k;
memset(p, 0, sizeof(p));
for(i = max(b, a-b) + 1; i <= a; i++) 
      {
      j = i; 
      for(k=2; k*k<=i; k++) while(j % k == 0) { j /= k; p[k]++;  }
      if(j != 1) p[j]++;
      }
for(i = 2; i <= min(b, a-b); i++)    
      {
      j = i;
      for(k=2; k*k<=i; k++) while(j % k == 0) { j /= k; p[k]--; }
      if(j != 1) p[j]--;
      }
for(i=2; i<2000; i++) 
for(k=0; k<p[i]; k++)
ans *= double(i);
return ans;
}

int main()
{
int x, y, i;
scanf("%d%d", &x, &y);
double sum = c(x+y, x);
double sum2 = double(x), w;
w = c(x, x-1);
sum2 += double(x+1) * w;
for(i=x+2; i<=x+y; i++) 
           {
           w *= double(i-1) / double(i-x); 
           sum2 += double(i) * w; 
           }
printf("%.3lf\n", sum2 / sum);
return 0;    
}
