#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
int n, i, j, k;
string a[100];
bool cmp(string x, string y) { return x > y; }
int main()
{
scanf("%d", &n);
for(i=0; i<n; i++) cin >> a[i]; 
sort(a, a+n, cmp);
for(i=0; i<n-1; i++)
for(j=i+1; j<n; j++)
{
string s1 = a[i] + a[j];
string s2 = a[j] + a[i];
if(s1 < s2) swap(a[i], a[j]); 
}
for(i=0; i<n; i++) cout << a[i];
printf("\n");
return 0;    
}
