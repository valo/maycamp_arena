#include <cstdio>
#include <cstring>
using namespace std;

typedef long long ll;

char s[32];
ll fact[32];
int num[128];

int main ()
{
    scanf ("%s", s);

    int size = strlen (s);

    fact[0] = 1;
    for (int i=1; i <= size; ++i)
        fact[i] = fact[i-1]*i;

    ll ans = fact[size];
    for (int i=0; i < size; ++i)
        num[int (s[i])] ++;

    for (int i=0; i < 128; ++i)
        ans /= fact[num[i]];

    if (ans == fact[size]) ans /= 2LL;
    printf ("%lld\n", ans);
    return 0;
}
