#include <cstdio>
#include <algorithm>
#include <vector>
#define MAXN (1 << 7)
using namespace std;

int n;
int a[MAXN];

void divide (vector<int> &into, int a)
{
    while (a)
    {
        into.push_back (a % 10);
        a /= 10;
    }
    reverse (into.begin (), into.end ());
}

inline int mycmp (const int &num1, const int &num2)
{
    vector <int> dig1, dig2;
    dig1.clear (); dig2.clear ();
    divide (dig1, num1);
    divide (dig2, num2);

    long long first=num1, second=num2;
    for (int i=0; i < dig1.size(); ++i)
        second = second*10LL + (long long) dig1[i];
    for (int i=0; i < dig2.size(); ++i)
        first = first*10LL + (long long) dig2[i];

    return first > second;
}

int main ()
{
    scanf ("%d", &n);

    for (int i=0; i < n; ++i)
        scanf ("%d" , &a[i]);

    sort (a, a+n, mycmp);
    for (int i=0; i < n; ++i)
        printf ("%d", a[i]);
    printf ("\n");
    return 0;
}
