#include <cstdio>
using namespace std;

int a, b;

int main ()
{
    scanf ("%d%d", &a, &b);
    double A = a, B = b;
    printf ("%.3lf\n", A + B*(A/(A+1.)));
    return 0;
}
