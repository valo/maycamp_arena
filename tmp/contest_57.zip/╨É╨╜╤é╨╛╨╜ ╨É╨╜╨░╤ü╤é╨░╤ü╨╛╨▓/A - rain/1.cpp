
#include <cstdio>
#include <algorithm>
using namespace std;

const int MAX_N = 100000 + 5;
const int MAX_L = 100000 + 5;
const int MAX_K = 20 + 5;

int N, L, K;
int lens[MAX_N];
int cost[MAX_L];

void read() {
	scanf("%d %d %d", &N, &L, &K);
	for (int i = 0; i < N; ++i)
		scanf("%d", &lens[i]);
	for (int i = 0; i < L; ++i)
		scanf("%d", &cost[i]);
}

inline void remax(int &a, int b) {
	if (a < b)
		a = b;
}

bool can(int F) {
	static bool mark[MAX_L];
	for (int i = 0; i < L; ++i) {
		mark[i] = (cost[i] <= F) ? true : false;
	}
	static int seq[MAX_L];
	seq[L] = 0;
	for (int i = L - 1; i >= 0; --i) {
		seq[i] = seq[i + 1];
		if (mark[i])
			++seq[i];
		else
			seq[i] = 0;
	}
	static int best[MAX_N][MAX_K];
	for (int i = 0; i <= L; ++i)
		memset(best[i], -1, sizeof(int) * (K + 1));
	best[0][0] = 0;
	for (int i = 0; i < L; ++i)
		for (int j = 0; j <= K; ++j)
			if (best[i][j] >= 0) {
				remax(best[i + 1][j], best[i][j]);
				if (best[i][j] < N) {
					if (seq[i] >= lens[best[i][j]])
						remax(best[i + lens[best[i][j]]][j], best[i][j] + 1);
					if (i + lens[best[i][j]] <= L)
						remax(best[i + lens[best[i][j]]][j + 1], best[i][j] + 1);
				}
			}
	for (int k = 0; k <= K; ++k)
		if (best[L][k] == N)
			return true;
	return false;
}

void solve() {
	int l = -1;
	int r = *max_element(cost, cost + L) + 5;
	while (r - l > 1) {
		int m = (l + r) / 2;
		if (can(m))
			r = m;
		else
			l = m;
	}
	printf("%d\n", r);
}

int main() {
	read();
	solve();
	return 0;
}
