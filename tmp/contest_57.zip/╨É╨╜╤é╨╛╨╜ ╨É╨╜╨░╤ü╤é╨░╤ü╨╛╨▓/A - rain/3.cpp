#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int MAX_N = 200000 + 5;
const int MAX_L = 200000 + 5;
const int MAX_K = 20 + 5;

int N, L, K;
int lens[MAX_N];
int cost[MAX_L];

void read() {
	scanf("%d %d %d", &N, &L, &K);
	for (int i = 0; i < N; ++i)
		scanf("%d", &lens[i]);
	for (int i = 0; i < L; ++i)
		scanf("%d", &cost[i]);
}

inline void remax(int &a, int b) {
	if (a < b)
		a = b;
}

bool can(int F) {
	static bool mark[MAX_L];
	for (int i = 0; i < L; ++i) {
		mark[i] = (cost[i] <= F) ? true : false;
	}
	static int seq[MAX_L];
	seq[L] = 0;
	for (int i = L - 1; i >= 0; --i) {
		seq[i] = seq[i + 1];
		if (mark[i])
			++seq[i];
		else
			seq[i] = 0;
	}
	static int best[2][MAX_L];
	memset(best[0], -1, sizeof(int) * (L + 1));
	best[0][0] = 0;
	for (int j = 0; j <= K; ++j) {
		memset(best[(j + 1) & 1], -1, sizeof(int) * (L + 1));
		for (int i = 0; i < L; ++i)
			if (best[j & 1][i] >= 0) {
				remax(best[j & 1][i + 1], best[j & 1][i]);
				if (best[j & 1][i] < N) {
					if (seq[i] >= lens[best[j & 1][i]])
						remax(best[j & 1][i + lens[best[j & 1][i]]], best[j & 1][i] + 1);
					remax(best[(j + 1) & 1][i + lens[best[j & 1][i]]], best[j & 1][i] + 1);
				}
			}
		if (best[j & 1][L] == N)
			return true;
	}
	return false;
}

void solve() {
	int l = -1;
	int r = *max_element(cost, cost + L) + 5;
	while (r - l > 1) {
		int m = (l + r) / 2;
		if (can(m))
			r = m;
		else
			l = m;
	}
	printf("%d\n", r);
}

int main() {
	read();
	solve();
	return 0;
}
