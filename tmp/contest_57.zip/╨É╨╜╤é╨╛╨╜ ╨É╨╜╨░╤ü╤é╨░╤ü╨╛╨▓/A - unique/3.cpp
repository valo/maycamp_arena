
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;

typedef long long LL;

const int MAX_L = 500 + 5;

LL cache[MAX_L][8][8][8];

LL getAm(int len, int delta, int low, int high) {
	low = min(low, delta);
	high = max(high, delta);
	if (high - low > 3)
		return 0LL;
	if (len == 0)
		return 1LL;
	LL &res = cache[len][delta + 4][low + 4][high +  4];
	if (res >= 0)
		return res;
	res = getAm(len - 1, delta - 1, low, high) + getAm(len - 1, delta + 1, low, high);
	return res;
}

LL getAmComplete(int len, int delta, int low, int high) {
	return getAm(len, delta, low, high);
}

int main() {
	memset(cache, -1, sizeof(cache));
	LL kth;
	scanf("%lld", &kth);
	for (int len = 1; true; ++len) {
		LL am = getAmComplete(len, 0, 0, 0);
		if (kth > am)
			kth -= am;
		else {
			int delta = 0;
			int low = 0;
			int high = 0;
			for (int i = 0; i < len; ++i)
				for (int j = -1; j <= 1; j += 2) {
					LL cam = getAmComplete(len - 1 - i, delta + j, low, high);
					if (kth > cam)
						kth -= cam;
					else {
						delta += j;
						low = min(low, delta);
						high = max(high, delta);
						if (j == -1) {
							putchar('a');
						} else {
							putchar('b');
						}
						break;
					}
				}
			puts("");
			exit(0);
		}
	}
	return 0;
}
