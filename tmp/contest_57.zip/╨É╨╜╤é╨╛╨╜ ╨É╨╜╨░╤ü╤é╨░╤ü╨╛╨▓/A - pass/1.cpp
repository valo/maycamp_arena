#include <iostream>
#include <algorithm>
using namespace std;

typedef long long LL;

LL fact[32];

string go(string str) {
	swap(str[2], str[0]);
	swap(str[2], str[1]);
	return str;
}

int main() {
	fact[0] = 1LL;
	for (int i = 1; i < 32; ++i)
		fact[i] = fact[i - 1] * LL(i);
	string str;
	cin >> str;
	LL res = 0;
	string pstr = str;
	sort(pstr.begin(), pstr.end());
	bool ok = true;
	for (int i = 1; i < int(pstr.size()); ++i)
		if (pstr[i - 1] == pstr[i]) {
			ok = false;
		}
	if (ok) {
		cout << fact[str.size()] / 2 << endl;
		return 0;
	}
	if (str.size() == 3) {
		string all[] = {str, go(str), go(go(str))};
//		cout << all[0] << " " << all[1] << " " << all[2] << endl;
		sort(all, all + 3);
		res = 1;
		for (int i = 1; i < 3; ++i)
			if (all[i] != all[i - 1])
				++res;
	} else {
		res = fact[str.size()];
		sort(str.begin(), str.end());
		for (int i = 0; i < int(str.size()); ) {
			int cnt = 0;
			int j = i;
			while (j < int(str.size()) && str[i] == str[j]) {
				++cnt;
				++j;
			}
			res /= fact[cnt];
			i = j;
		}
	} 
	cout << res << endl;
	return 0;
}
