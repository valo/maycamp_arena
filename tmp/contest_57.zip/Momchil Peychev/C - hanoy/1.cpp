/*
PROB: hanoy
LANG: C++
*/
#include <stdio.h>
#include <iostream>
#include <stack>
#include <stdlib.h>
#include <deque>
#include <map>
#include <algorithm>

#define pb push_back

using namespace std;

int n,p,q;
int m[32];
stack<int> a,b,c;
deque<string> sol;

map< pair< stack<int> , pair< stack<int> , stack<int> > > , bool > used;

void init()
{
  scanf("%d%d%d",&n,&p,&q);
  for(int i=1;i<=n;i++) m[i]=i;
  swap(m[p],m[q]);
  for(int i=n;i>=1;i--) a.push(m[i]);
}

void print(stack<int> t1,stack<int> t2,stack<int> t3)
{
  while(!t1.empty()) { printf("%d ",t1.top()); t1.pop(); }
  printf("\n");
  while(!t2.empty()) { printf("%d ",t2.top()); t2.pop(); }
  printf("\n");
  while(!t3.empty()) { printf("%d ",t3.top()); t3.pop(); }
  printf("\n");
  cout << endl;
}

void solve(stack<int> x,stack<int> y,stack<int> z)
{
  pair< stack<int> , pair< stack<int> , stack<int> > > state;
  state.first=x;
  state.second.first=y;
  state.second.second=z;
  if(used[state]) return;
  used[state]=1;
  //print(x,y,z);
  //system("Pause");

  if(z.size()==n)
  {
    for(int i=0;i<sol.size();i++) cout << sol[i] << endl;
    exit(0);
  }
  if(!x.empty() && (y.empty() || x.top()<y.top()))
  {
    sol.pb("AB");
    y.push(x.top());
    x.pop();
    solve(x,y,z);
    sol.pop_back();
    x.push(y.top());
    y.pop();
  }
  if(!x.empty() && (z.empty() || x.top()<z.top()))
  {
    sol.pb("AC");
    z.push(x.top());
    x.pop();
    solve(x,y,z);
    sol.pop_back();
    x.push(z.top());
    z.pop();
  }
  if(!y.empty() && (z.empty() || y.top()<z.top()))
  {
    sol.pb("BC");
    z.push(y.top());
    y.pop();
    solve(x,y,z);
    sol.pop_back();
    y.push(z.top());
    z.pop();
  }
  if(!y.empty() && (x.empty() || y.top()<x.top()))
  {
    sol.pb("BA");
    x.push(y.top());
    y.pop();
    solve(x,y,z);
    sol.pop_back();
    y.push(x.top());
    x.pop();
  }
  if(!z.empty() && (y.empty() || z.top()<y.top()))
  {
    sol.pb("CB");
    y.push(z.top());
    z.pop();
    solve(x,y,z);
    sol.pop_back();
    z.push(y.top());
    y.pop();
  }
  if(!z.empty() && (x.empty() || z.top()<x.top()))
  {
    sol.pb("CA");
    x.push(z.top());
    z.pop();
    solve(x,y,z);
    sol.pop_back();
    z.push(x.top());
    x.pop();
  }
}

int main()
{
  init();
  solve(a,b,c);

  return 0;
}
