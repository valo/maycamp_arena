#include <stdio.h>
#include <iostream>

#define Rep(i,l,r) for(int i=l;i<r;i++)

using namespace std;

int r,c;
double pas[2048][1024],sum;

void init()
{
    scanf("%d %d",&r,&c);
    
    pas[0][0]=1;
    pas[1][0]=1; pas[1][1]=1;
    for(int i=2;i<=r+c;i++)
    {
        pas[i][0]=1;
        for(int j=1;j<=min(i,r);j++) pas[i][j]=pas[i-1][j]+pas[i-1][j-1];
    }
}

void solve()
{
    Rep(i,r,r+c+1) sum+=(double)i*pas[i-1][r-1];
    printf("%.3lf\n",sum/pas[r+c][r]);
}

int main()
{
    init();
    solve();
    
    return 0;
}
