#include <stdio.h>
#include <iostream>

using namespace std;

double r,c;

int main()
{
    scanf("%lf %lf",&r,&c);
    printf("%.3lf\n",r+c*(r/(r+1)));
    
    return 0;
}
