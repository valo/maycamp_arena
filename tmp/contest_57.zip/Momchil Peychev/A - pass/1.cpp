#include <stdio.h>
#include <iostream>
#include <string>
#include <map>

using namespace std;

map<string , bool> used;
string s;
int sol;

void f(string a)
{
    if(used[a]) return;
    sol++;
    used[a]=1;
    for(int i=0;i<=a.size()-3;i++)
    {
        string next=a;
        next[i]=a[i+2];
        next[i+1]=a[i];
        next[i+2]=a[i+1];
        f(next);
    }
}

int main()
{
    cin >> s;
    f(s);
    cout << sol << endl;
    
    return 0;
}
