#include <stdio.h>
#include <iostream>
#include <string.h>

#define Rep(i,l,r) for(int i=l;i<r;i++)

using namespace std;

typedef unsigned long long ll;

char s[32];
int n,m[64];
bool fl;

int encode(char c)
{
    if(c>='a' && c<='z') return (int)(c-'a');
    if(c>='A' && c<='Z') return (int)(c-'A'+26);
    return (int)(c-'0'+52);
}

void init()
{
    scanf("%s",&s);
    n=strlen(s);
    Rep(i,0,n) m[encode(s[i])]++;
}

ll perm(int x)
{
    if(x>1) fl=true;
    ll ret=1;
    Rep(i,1,x+1) ret*=i;
    return ret;
}

void solve()
{
    ll p=perm(n);
    fl=false;
    Rep(i,0,64) p/=perm(m[i]);
    if(fl) cout << p << endl;
    else cout << p/2 << endl;
}

int main()
{
    init();
    solve();
    
    return 0;
}
