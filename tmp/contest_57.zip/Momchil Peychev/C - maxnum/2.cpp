/*
PROB: maxnum
LANG: C++
*/
#include <stdio.h>
#include <iostream>
#include <string>
#include <algorithm>

#define Rep(i,l,r) for(int i=l;i<r;i++)

using namespace std;

int n;
string a[128];

bool cmp(string x,string y)
{
    if(x>y) return true;
    return false;
}

void init()
{
    scanf("%d",&n);
    Rep(i,0,n) cin >> a[i];
    sort(a,a+n,cmp);
}

void solve()
{
    Rep(i,0,n)
     Rep(j,i+1,n)
     {
            string s1=a[i]+a[j];
            string s2=a[j]+a[i];
            if(s1<s2) swap(a[i],a[j]);
     }
}

void print()
{
    Rep(i,0,n) cout << a[i];
    printf("\n");
}

int main()
{
    init();
    solve();
    print();
    
    return 0;
}
