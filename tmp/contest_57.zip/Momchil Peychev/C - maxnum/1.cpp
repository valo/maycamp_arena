/*
PROB: maxnum
LANG: C++
*/
#include <stdio.h>
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

#define pb push_back

using namespace std;

int n;
vector<string> a;
string sol;

bool cmp(string x,string y)
{
  if(x<y) return false;
  return true;
}

void init()
{
  scanf("%d",&n);
  for(int i=0;i<n;i++)
  {
    string t;
    cin >> t;
    a.pb(t);
  }
  sort(a.begin(),a.end(),cmp);
  for(int i=0;i<n;i++) sol+=a[i];
//  cout << sol << endl;
}

void make_new(int x,int y)
{
  vector<string> tmp;
  string s;
  for(int i=0;i<y;i++)
  {
    s+=a[i];
    tmp.pb(a[i]);
  }
  s+=a[x];
  tmp.pb(a[x]);
  for(int i=y;i<x;i++)
  {
    s+=a[i];
    tmp.pb(a[i]);
  }
  for(int i=x+1;i<n;i++)
  {
    s+=a[i];
    tmp.pb(a[i]);
  }
  if(s>sol) { sol=s; a=tmp; }
}

void solve()
{
//  for(int k=0;k<n;k++)
   for(int i=n-1;i>=0;i--)
    for(int j=i-1;j>=0;j--)
     make_new(i,j);
  cout << sol << endl;
}

int main()
{
  init();
  solve();

  return 0;
}
