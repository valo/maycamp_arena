#include <cstdio>
#include <cstring>

char s[32];
int cnt[256], N;
unsigned long long f[32];

int main (void) {
	
	scanf ( "%s", s );
	N = strlen ( s );
	
	f[0] = 1LL;
	for ( int i=1; i<=N; ++i ) f[i] = f[i-1] * (long long)i;
	
	bool key = false;
	for ( int i=0; i<N; ++i ) {
		++ cnt[ (int)s[i] ];
		if ( cnt[ (int)s[i] ] > 1 ) key = true;
		}
	
	unsigned long long ans = f[N];
	if ( !key ) ans /= 2LL;
	else for ( int i=0; i<256; ++i ) if ( cnt[i] > 1 ) ans /= f[ cnt[i] ];
	
	printf ( "%llu\n", ans );
	
}
