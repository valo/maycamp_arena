#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long ll;

ll N, f[100][7][7][7];

ll go ( int n, int l, int h, int c ) {
	
	if ( h-l > 3 ) return 0;
	if ( n == 0 ) return 1LL;
	
	ll &ref = f[n][l][h][c];
	if ( ref != -1 ) return ref;
	
	return ref = go ( n-1, l, max ( h, c+1 ), c+1 ) + go ( n-1, min ( l, c-1 ), h, c-1 );
	
}

int main (void) {
	
	scanf ( "%lld", &N );
	memset ( f, -1, sizeof f );
	
	ll sum = 0LL;
	int n = 0, l, h, c;
	while ( sum < N ) sum += go ( ++n, 2, 2, 2 );
	
	N -= ( sum - go ( n, 2, 2, 2 ) );
	
	l = h = c = 2;
	while ( n -- ) {
		
		ll temp = go ( n, l, max ( h, c+1 ), c+1 );
		
		if ( N <= temp ) {
			++ c; h = max ( h, c );
			printf ( "a" );
			}
		else {
			-- c; l = min ( l, c );
			printf ( "b" );
			N -= temp;
			}
		
		}
	
	printf ( "\n" );
	
}
