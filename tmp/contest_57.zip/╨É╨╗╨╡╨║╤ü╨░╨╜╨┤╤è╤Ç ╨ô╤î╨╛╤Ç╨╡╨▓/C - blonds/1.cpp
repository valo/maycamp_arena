#include <cstdio>
#include <cstring>

int A, B;
bool cache[1005][1005];
double f[1005][1005];

double go ( int a, int b ) {
	
	if ( a == 0 ) return 0.;
	if ( b == 0 ) return (double)a;
	
	double &ref = f[a][b];
	if ( cache[a][b] ) return ref;
	cache[a][b] = true;
	
	return ref = 1. + ( a * go ( a-1, b ) + b * go ( a, b-1 ) ) / ( a+b );
	
}

int main (void) {
	
	scanf ( "%d%d", &A, &B );
	printf ( "%.3lf\n", go ( A, B ) );
	
}
