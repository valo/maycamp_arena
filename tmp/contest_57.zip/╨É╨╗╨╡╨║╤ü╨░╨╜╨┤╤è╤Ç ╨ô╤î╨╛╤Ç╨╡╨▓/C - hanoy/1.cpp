#include <cstdio>

inline void go ( char a, char b ) {
	printf ( "%c%c\n", a, b );
}

void move ( char a, char b, char c, int n ) { // n disks - a->b->c
	
	if ( n == 1 ) go ( a, c );
	else {
		
		move ( a, c, b, n-1 );
		go ( a, c );
		move ( b, a, c, n-1 );
		
		}
	
}

int N, P, Q;

inline void BNS ( char a, char b, char c, int n ) {
	go ( a, c );
	if ( n == 3 ) {
		go ( a, c ); go ( a, c );
		}
	else {
		move ( a, c, b, n-3 );
		go ( a, c ); go ( a, b );
		move ( b, a, c, n-2 );
		}
}

int main (void) {
	
	scanf ( "%d%d%d", &N, &P, &Q );
	
	if ( N == 2 ) {
		go ( 'A', 'C' ); go ( 'A', 'C' );
		goto end;
		}
	
	if ( P == 1 && Q == 2 ) { // BSN
		go ( 'A', 'B' ); go ( 'A', 'B' );
		move ( 'B', 'C', 'A', 2 );
		move ( 'A', 'B', 'C', N );
		goto end;
		}
	
	if ( P == N-1 && Q == N ) { // NBS
		move ( 'A', 'C', 'B', N-2 );
		go ( 'A', 'C' ); go ( 'A', 'C' );
		move ( 'B', 'A', 'C', N-2 );
		goto end;
		}
	
	if ( P == 1 && Q == N ) { // BNS
		BNS ( 'A', 'B', 'C', N );
		goto end;
		}
	
	if ( P == 1 && Q != N && Q-P > 1 ) { // BN1SN2
		BNS ( 'A', 'C', 'B', Q );
		move ( 'B', 'C', 'A', Q );
		move ( 'A', 'B', 'C', N );
		goto end;
		}
	
	if ( P > 1 && Q < N && Q-P == 1 ) { //N1BSN2
		move ( 'A', 'C', 'B', P-1 );
		go ( 'A', 'C' ); go ( 'A', 'C' );
		move ( 'B', 'A', 'C', P-1 );
		move ( 'C', 'B', 'A', Q );
		move ( 'A', 'B', 'C', N );
		goto end;
		}
	
	if ( P > 1 && Q == N && Q-P > 1 ) { // N1BN2S
		move ( 'A', 'C', 'B', P-1 );
		go ( 'A', 'C' );
		move ( 'B', 'C', 'A', P-1 );
		move ( 'A', 'C', 'B', N-3 );
		go ( 'A', 'C' );
		move ( 'B', 'C', 'A', P-1 );
		move ( 'A', 'C', 'B', P );
		move ( 'B', 'A', 'C', N-2 );
		goto end;
		}
	
	if ( P != 1 && Q != N && Q-P > 1 ) { // N1BN2SN3
		move ( 'A', 'C', 'B', P-1 );
		go ( 'A', 'C' );
		move ( 'B', 'C', 'A', P-1 );
		move ( 'A', 'C', 'B', Q-3 );
		go ( 'A', 'C' );
		move ( 'B', 'C', 'A', P-1 );
		move ( 'A', 'C', 'B', P );
		move ( 'B', 'A', 'C', Q-2 );
		move ( 'C', 'B', 'A', Q );
		move ( 'A', 'B', 'C', N );
		}
	
	end : ;
}
