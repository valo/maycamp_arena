#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

int N, a[128];

inline bool Compare ( const int &p1, const int &p2 ) {
	
	char s1[16], s2[16];
	sprintf ( s1, "%d%d", p1, p2 );
	sprintf ( s2, "%d%d", p2, p1 );
	
	if ( strcmp ( s1, s2 ) > 0 ) return true;
	return false;
	
}

int main (void) {
	
	scanf ( "%d", &N );
	for ( int i=0; i<N; ++i ) scanf ( "%d", a+i );
	
	sort ( a, a+N, Compare );
	for ( int i=0; i<N; ++i ) printf ( "%d", a[i] );
	printf ( "\n" );
	
}
