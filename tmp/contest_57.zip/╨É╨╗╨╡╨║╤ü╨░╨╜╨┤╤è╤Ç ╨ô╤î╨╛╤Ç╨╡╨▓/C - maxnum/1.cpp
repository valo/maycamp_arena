#include <cstdio>
#include <vector>
#include <string>
#include <cstring>
#include <algorithm>

using namespace std;

int N, a[128];
vector < int > v[128];
char s1[16], s2[16];
bool par[128];
int d[128], p[128];

void dfs ( int x ) {
	
	int maxi = 0;
	if ( d[x] ) return;
	
	for ( int i=0; i<(int)v[x].size (); ++i ) {
		
		dfs ( v[x][i] );
		if ( maxi <= d[ v[x][i] ] ) {
			maxi = d[ v[x][i] ] + 1;
			p[x] = v[x][i];
			}
		
		}
	d[x] = maxi;
	
}

int main (void) {
	
	scanf ( "%d", &N );
	for ( int i=0; i<N; ++i ) scanf ( "%d", a+i );
	
	for ( int i=0; i<N; ++i )
		for ( int j=i+1; j<N; ++j ) {
			
			sprintf ( s1, "%d%d", a[i], a[j] );
			sprintf ( s2, "%d%d", a[j], a[i] );
			string ss1; ss1 = s1;
			string ss2; ss2 = s2;
			
			if ( ss1 > ss2 ) par[j] = 1, v[i].push_back ( j );
			else par[i] = 1, v[j].push_back ( i );
			
			}
	
	memset ( p, -1, sizeof p );
	for ( int i=0; i<N; ++i )
		if ( !par[i] ) {
			
			dfs ( i );
			int idx = max_element ( d, d+N ) - d;
			while ( idx != -1 ) {
				printf ( "%d", a[idx] );
				idx = p[idx];
				}
			printf ( "\n" );
			
			}
	
}
