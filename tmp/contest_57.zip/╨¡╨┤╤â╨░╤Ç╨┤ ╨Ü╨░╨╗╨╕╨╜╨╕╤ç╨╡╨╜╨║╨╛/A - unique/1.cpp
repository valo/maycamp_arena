#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAXN 105

int main ()
{
	long long int N;
	scanf("%lli",&N);
	static long long int a[MAXN][2][2][2][2][2][2][2];
	int i, xm3, xm2, xm1, x0, x1, x2, x3;
	for (xm3 = 0; xm3 <= 1; xm3++)
	{
		for (xm2 = 0; xm2 <= 1; xm2++)
		{
			for (xm1 = 0; xm1 <= 1; xm1++)
			{
				for (x0 = 0; x0 <= 1; x0++)
				{
					for (x1 = 0; x1 <= 1; x1++)
					{
						for (x2 = 0; x2 <= 1; x2++)
						{
							for (x3 = 0; x3 <= 1; x3++)
							{
								a[0][xm3][xm2][xm1][x0][x1][x2][x3] = 1;
							}
						}
					}
				}
			}
		}
	}
	for (i = 1; i <= 63; i++)
	{
		for (xm3 = 0; xm3 <= 1; xm3++)
		{
			for (xm2 = 0; xm2 <= 1; xm2++)
			{
				for (xm1 = 0; xm1 <= 1; xm1++)
				{
					for (x0 = 0; x0 <= 1; x0++)
					{
						for (x1 = 0; x1 <= 1; x1++)
						{
							for (x2 = 0; x2 <= 1; x2++)
							{
								for (x3 = 0; x3 <= 1; x3++)
								{
									a[i][xm3][xm2][xm1][x0][x1][x2][x3] = 0;
									if (x3 == 0)
									{
										a[i][xm3][xm2][xm1][x0][x1][x2][x3] += a[i-1][0][xm3][xm2][xm1][1][x1][x2];
									}
									if (xm3 == 0)
									{
										a[i][xm3][xm2][xm1][x0][x1][x2][x3] += a[i-1][xm2][xm1][1][x1][x2][x3][0];
									}
								}
							}
						}
					}
				}
			}
		}		
	}
	int len = 1;
	while ((N - a[len][0][0][0][0][0][0][0]) > 0)
	{
		N -= a[len][0][0][0][0][0][0][0];
		len++;
	}
	xm3 = 0; xm2 = 0; xm1 = 0; x0 = 0; x1 = 0; x2 = 0; x3 = 0;
	for (i = len; i >= 1; i--)
	{
		if (x3 == 0)
		{
			long long int nxt = a[i-1][0][xm3][xm2][xm1][1][x1][x2];
			if (nxt >= N) 
			{
				printf("a");
				x3 = x2; x2 = x1; x1 = 1; x0 = xm1; xm1 = xm2; xm2 = xm3; xm3 = 0;
			}
			else
			{
				N -= nxt;
				printf("b");
				xm3 = xm2; xm2 = xm1; xm1 = 1; x0 = x1; x1 = x2; x2 = x3; x3 = 0;
			}
		}
		else
		{
			printf("b");
			xm3 = xm2; xm2 = xm1; xm1 = 1; x0 = x1; x1 = x2; x2 = x3; x3 = 0;
		}
	}
	printf("\n");
	return 0;
}
