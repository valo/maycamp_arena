#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAXN 100005
#define MAXK 25
#define INFINITY 2000000000

int N, L, K;
static int data[MAXN];
static int lens[MAXN];
static int fr[MAXN];
static int pa1[MAXN];
static int pa2[MAXN];
int *a1 = pa1;
int *a2 = pa2;
int *temp;

char Can (int B)
{
	int i, j, k, len;
	fr[L] = 0;
	for (i = L-1; i >= 0; i--)
	{
		if (lens[i] > B) fr[i] = 0;
		else fr[i] = fr[i+1] + 1;
	}

	a1[0] = -1;
	for (i = 1; i <= N; i++)
	{
		if (a1[i-1] == INFINITY)
		{
			a1[i] = INFINITY;
		}
		else
		{
			len = data[i-1];
			k = a1[i-1] + 1;
			while ((k < L) && (fr[k] < len)) k++;
			if (k == L)
			{
				a1[i] = INFINITY;
			}
			else
			{
				a1[i] = k + len - 1;
			}
		}
	}
	if (a1[N] != INFINITY) return 1;

	for (j = 1; j <= K; j++)
	{
		for (i = 0; i < j; i++) a2[i] = INFINITY;
		for (i = j; i <= N; i++)
		{
			len = data[i-1];
			if (a2[i-1] != INFINITY)
			{
				k = a2[i-1] + 1;
				while ((k < L) && (k <= a1[i-1]) && (fr[k] < len)) k++;
				if (k == L)
				{
					a2[i] = INFINITY;
				}
				else
				{
					a2[i] = k + len - 1;
					if (a2[i] >= L) a2[i] = INFINITY;
				}
			}
			else
			{
				a2[i] = a1[i-1] + len;
				if (a2[i] >= L) a2[i] = INFINITY;
			}
		}
		temp = a1; a1 = a2; a2 = temp;
		if (a1[N] != INFINITY) return 1;
	}

	return 0;
}

int main ()
{
	scanf("%d %d %d",&N,&L,&K);
	int i;
	for (i = 0; i < N; i++) scanf("%d",&(data[i]));
	for (i = 0; i < L; i++) scanf("%d",&(lens[i]));
	int l, r, c;
	l = 0;
	r = MAXN;
	while (r > l)
	{
		c = (l+r) / 2;
		if (Can(c)) r = c;
		else l = c+1;
	}
	printf("%d\n",l);
	return 0;
}
