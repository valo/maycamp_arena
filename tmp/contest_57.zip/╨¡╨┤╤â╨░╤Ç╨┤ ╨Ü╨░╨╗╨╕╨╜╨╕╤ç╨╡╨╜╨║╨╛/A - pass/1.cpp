#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAXN 25

int main ()
{
	static char a[MAXN];
	static long long int fact[MAXN];
	scanf("%s",a);
	int N = strlen(a);
	int i;
	fact[0] = 1;
	for (i = 1; i <= N; i++) fact[i] = fact[i-1] * (long long int)(i);
	long long int res = fact[N];
	static int cnt[256];
	memset(cnt,0,sizeof(cnt));
	for (i = 0; i < N; i++)
	{
		cnt[(int)(a[i])]++;
	}
	char flag = 0;
	for (i = 0; i < 256; i++)
	{
		if (cnt[i] >= 2) flag = 1;
		res /= fact[cnt[i]];
	}
	if (!flag) res /= 2LL;
	printf("%lli\n",res);
	return 0;
}
