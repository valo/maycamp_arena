#include<iostream>
using namespace std;
     
int main()
{
float r,ch,i,i2,brn=1,bms;

cin>>r>>ch;
bms=r;
for(i=r+1,i2=r;i<=r+ch;i++,i2=i2*2)
{
cout<<bms<<endl;

brn=brn+i2;
bms=bms+i*i2;
cout<<bms<<endl;
}
//cout<<brn<<endl<<bms<<endl;
cout<<bms/brn<<endl;

//system("pause");
return 0;
}
