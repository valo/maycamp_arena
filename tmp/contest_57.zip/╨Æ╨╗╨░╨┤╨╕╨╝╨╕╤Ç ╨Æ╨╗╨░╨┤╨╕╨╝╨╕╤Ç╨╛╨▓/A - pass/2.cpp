#include<iostream>
#include<string.h>
using namespace std;

long long fakt(int ii)
{
     if ( !ii ) return 1;
     else 
          {
               long long p=1;
               for(int j=1; j<=ii; j++)
                       p*=j;
               return p;
          }
}

int main()
{
    int cnt[27];
    char a[50];
    int len;
    
    cin>>a;
    len=strlen(a);
    memset(cnt,0,sizeof(cnt));
    
    for(int i=0; i<len; i++)
            cnt[ a[i]-'A' ] ++;
    
    long long rez=fakt(len);
    for(int i=0; i<26; i++)
    {
            rez/=fakt(cnt[i]);
            //cout<<cnt[i]<<" ";
    }
    
    cout<<rez<<endl;
    
    //system("pause");
    return 0;
}
    
