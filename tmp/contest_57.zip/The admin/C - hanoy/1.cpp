#include <iostream>
#include <cstdio>
using namespace std;

void DiskMove(char a, char b) { printf("%c%c\n", a, b); }

void MoveDisks(char a, char c, char b, int numb) {
  if (1 == numb) DiskMove(a, c);
  else {
    MoveDisks(a, b, c, numb - 1);
    DiskMove(a, c);
    MoveDisks(b, c, a, numb - 1);
  }
}
void BNS (char s, char d, char e, unsigned n);

int main() {
  int n,p,q;
  cin>>n>>p>>q;

  if (n==2) printf("AC\nAC\n"); // *

  else {
    if (p==1 && q==2) {      // **       B-S-N !
    DiskMove('A','B');
    DiskMove('A','B');
    MoveDisks('B','A','C',2);
    MoveDisks('A','C','B',n);
    }

  else if (q==n && p==(n-1)) {  // ***      N-B-S !
    MoveDisks('A','B','C',n-2);
    DiskMove('A','C');
    DiskMove('A','C');
    MoveDisks('B','C','A',n-2);
    }

  else if (q==n && p==1) {     // ****      B-N-S !
    BNS('A','C','B',n);
    }

  else if (q==n && p>1 && q-p>1)  { // *****   N1-B-N2-S   !
    MoveDisks('A','B','C',p-1);
    DiskMove('A','C');
    MoveDisks('B','A','C',p-1);
    MoveDisks('A','B','C',n-3);
    DiskMove('A','C');
    MoveDisks('B','A','C',p-1);
    MoveDisks('A','B','C',p);
    MoveDisks('B','C','A',n-2);

    }

  else if (q<n && p>1 && q-p==1)  { // ******  N1-B-S-N2  !
    MoveDisks('A','B','C',p-1);
    DiskMove('A','C');
    DiskMove('A','C');
    MoveDisks('B','C','A',p-1);
    MoveDisks('C','A','B',q);
    MoveDisks('A','C','B',n);
    }

  else if (q<n && p==1 && q-p>1)  { // ******* B-N1-S-N2   !
    BNS('A','B','C',q);
    MoveDisks('B','A','C',q);
    MoveDisks('A','C','B',n);
    }

  else {                           // ******* N1-B-N2-S-N3   !
    MoveDisks('A','B','C',p-1);
    DiskMove('A','C');
    MoveDisks('B','A','C',p-1);
    MoveDisks('A','B','C',q-3);
    DiskMove('A','C');
    MoveDisks('B','A','C',p-1);
    MoveDisks('A','B','C',p);
    MoveDisks('B','C','A',q-2);
    MoveDisks('C','A','B',q);
    MoveDisks('A','C','B',n);
  }
  }
  return 0;
}

void BNS (char s, char d, char e, unsigned n){
  DiskMove(s,d);
  if (n==3) {
    DiskMove(s,d);
    DiskMove(s,d);
    }
  else {
    MoveDisks(s,e,d,n-3);
    DiskMove(s,d);
    DiskMove(s,e);
    MoveDisks(e,d,s,n-2);
  }
}
