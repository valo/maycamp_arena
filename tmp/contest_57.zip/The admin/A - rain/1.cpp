/*
LANG: C++
TASK: rain
AUTH: Alexander Georgiev
COMP: Spring National Contest
*/

#include <cstdio>
#include <cstring>
#include <algorithm>

#define MAX_N 100002
#define MAX_L 100002

#define INF 999666333

using namespace std;
FILE *in; FILE *out;

int n, l, k;
int a[MAX_N], b[MAX_L];
int best[2][MAX_N];
int queue[MAX_N][2], qlen, qidx;
int squeue[MAX_N][2], sqlen;

int findPos(int len, int startAt, int maxRight)
{
	while (qidx < qlen && queue[qidx][1] < startAt) qidx++;
	if (queue[qidx][0] < startAt) queue[qidx][0] = startAt;
	while (qidx < qlen && queue[qidx][1] - queue[qidx][0] + 1 < len && queue[qidx][0] + len <= maxRight) qidx++;
	if (qidx >= qlen) return INF;
	return queue[qidx][0] + len <= maxRight ? (queue[qidx][0] += len) - 1 : INF;
}

int eval(int cap)
{
	sqlen = 0;
	int start = -1;
	for (int i = 0; i <= l; i++)
	{
		if (b[i] <= cap)
		{
			if (start == -1) start = i;
		}
		else if (start != -1)
		{
			squeue[sqlen][0] = start;
			squeue[sqlen][1] = i - 1;
			sqlen++; start = -1;
		}
	}
	
	memset(best, 111, sizeof(best));
	for (int rem = 0; rem <= k; rem++)
	{
		qlen = sqlen; qidx = 0;
		memcpy(queue, squeue, sizeof(queue));

		int who = (rem & 1);
		if (rem) best[who][0] = a[0] - 1;
		else best[who][0] = findPos(a[0], 0, best[who][0]);
		for (int idx = 1; idx < n; idx++)
		{
			best[who][idx] = INF;
			if (rem) best[who][idx] = min(best[who][idx], best[!who][idx - 1] + a[idx]);
			best[who][idx] = min(best[who][idx], findPos(a[idx], best[who][idx - 1] + 1, best[who][idx]));
		}
		if (best[who][n - 1] < l) return 1;
	}
	return 0;
}

int main(void)
{
	in = stdin; out = stdout;
//	in = fopen("Rain.in", "rt"); out = fopen("Rain.out", "wt");
	
	fscanf(in, "%d %d %d", &n, &l, &k);
	for (int i = 0; i < n; i++) fscanf(in, "%d", &a[i]);
	for (int i = 0; i < l; i++) fscanf(in, "%d", &b[i]);
	b[l] = INF;
	
	int ans = INF;
	int left = 0, right = 100000;
	while (left <= right)
	{
		int mid = (left + right) / 2;
		if (eval(mid)) {ans = min(ans, mid); right = mid - 1;}
		else left = mid + 1;
	}
	fprintf(out, "%d\n", ans);	
	return 0;
}
