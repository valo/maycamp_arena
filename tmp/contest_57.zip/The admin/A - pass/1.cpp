#include <iostream>
#include <string.h>
using namespace std;
long long fact(int n)
{long long r=1;
 for (int i=2;i<=n;i++) r*=i;
 return r;
}
long long perm(int n,int c,int *a)
{long long r=fact(n);
 for (int i=0;i<c;i++) r/=fact(a[i]);
 return r;
}
int main(void)
{int a[24],c=0,n;
 char b[24],ch;
 bool f=false;
 cin>>b;
 n=strlen(b);
 for (int i=0;i<n;i++) if (b[i])
 {ch=b[i];
  a[c]=0;
  for (int j=i;j<n;j++) if (b[j]==ch)
  {a[c]++;
   if (a[c]>1) f=true;
   b[j]=0;
  }
  c++;
 }
 long long cnt=perm(n,c,a);
 if (!f) cnt>>=1;
 cout<<cnt<<endl;
 return 0;
}
