#include <cstdio>
#include <cstdlib>
#define MAX 1024
FILE *in; FILE *out;

double dyn[MAX][MAX];

double recurse(int n, int m)
{
	if (n == 0) return 0;
	if (m == 0) return n;
	if (dyn[n][m] > -1.0) return dyn[n][m];
	
	dyn[n][m] = 0.0;
	dyn[n][m] += (double)n / (double)(n + m) * (recurse(n - 1, m) + 1.0);
	dyn[n][m] += (double)m / (double)(n + m) * (recurse(n, m - 1) + 1.0);
	return dyn[n][m];
}

int main(void)
{
	int numTests = 1;
	for (int curTest = 1; curTest <= numTests; curTest++)
	{
    // char inpFile[32], outFile[32];
    // sprintf(inpFile, "blonds.%02d.in", curTest);
    // sprintf(outFile, "blonds.%02d.sol", curTest);
		FILE *in = stdin;
		FILE *out = stdout;

		int n, m;
		fscanf(in, "%d %d", &n, &m);
		fscanf(in, "%d %d", &n, &m);
		for (int i = 0; i < MAX; i++)
			for (int c = 0; c < MAX; c++)
				dyn[i][c] = -42;
		fprintf(out, "%.3lf\n", recurse(n, m));	
		fclose(in); fclose(out);
	}
  // fprintf(stderr, "Finished all tests successfully!\n");
  // system("pause");
	return 0;
}
