#include<cstdio>
#include<algorithm>
using namespace std;
int cmp(int x,int y)
{
    int x1=x,y1=y;
    int ansx,ansy;
    while(x1)
    {
        y1*=10;
        x1/=10;
    }
    ansy=y1+x;
    x1=x;
    y1=y;
    while(y1)
    {
        x1*=10;
        y1/=10;
    }
    ansx=x1+y;
    if(ansx>ansy) return 1;
    if(ansx==ansy) return 1;
    return 0;
}
int main()
{
    int a[128],n,i;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    sort(a,a+n,cmp);
    for(i=0;i<n;i++)
    printf("%d",a[i]);
    printf("\n");
    return 0;
}
