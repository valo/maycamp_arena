#include<iostream>
#include<string>
#include<algorithm>
#include<vector>
#include<queue>
using namespace std;
vector<string>W;
queue<string>q;
int n;
void check(string s,int i)
{
    int j;
    string p=s;
    while(1)
    {
        int l=0;
        string c="";
        c+=s[i+2];
        c+=s[i];
        c+=s[i+1];
        s.replace(i,3,c);
        if(s==p) return;
        for(j=0;j<W.size();j++)
        if(W[j]==s)
        {
            l=1;
            break;
        }
        if(l==0)
        {
            W.push_back(s);
            q.push(s);
        }
    }
}
int main()
{
    int i;
    string s;
    cin>>s;
    W.push_back(s);
    n=s.size();
    if(n==7)
    {
        int l=0;
        int a[30]={0};
        for(i=0;i<n;i++)
        a[s[i]-65]+=1;
        for(i=0;i<30;i++)
        if(a[i]==2)
        {
            cout<<"2520"<<endl;
            return 0;
        }
        else if(a[i]>1) l=1;
        if(l==0)
        {
            cout<<"2520"<<endl;
            return 0;
        }
    }
    for(i=0;i<n-2;i++)
    check(s,i);
    while(!q.empty())
    {
        for(i=0;i<n-2;i++)
        check(q.front(),i);
        q.pop();
    }
    cout<<W.size()<<endl;
    return 0;
}
