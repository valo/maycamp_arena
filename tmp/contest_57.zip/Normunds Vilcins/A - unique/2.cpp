#include <iostream>
#include <string>
using namespace std;

typedef long long ll;

#define MAXLEN 70

ll dp[4][4][MAXLEN][4], tot[4][4][MAXLEN];

void doDP()
{
    for(int h = 1; h < 4; h++){
        for(int lvl = 0; lvl <= h; lvl++){
            dp[h][lvl][0][lvl] = tot[h][lvl][0] = 1;
            for(int i = 1; i < MAXLEN; i++){
                for(int j = 0; j <= h; j++){
                    if(j){
                        dp[h][lvl][i][j] += dp[h][lvl][i - 1][j - 1];
                    }
                    if(j < h){
                        dp[h][lvl][i][j] += dp[h][lvl][i - 1][j + 1];
                    }
                    tot[h][lvl][i] += dp[h][lvl][i][j];
                }
            }
        }
    }
}

ll get1(int len)
{
    return tot[3][0][len] + tot[3][1][len] + tot[3][2][len] + tot[3][3][len] - tot[2][0][len] - tot[2][1][len] - tot[2][2][len];
}

ll get2(int u, int d, int pos, int len)
{
    if(u - d == 3){
        return tot[3][pos - d][len];
    }
    if(u - d == 2){
        return tot[3][pos - d][len] + tot[3][pos - d + 1][len] - tot[2][pos - d][len];
    }
    return tot[3][pos - d][len] + tot[3][pos - d + 1][len] + tot[3][pos - d + 2][len] - tot[2][pos - d][len] - tot[2][pos - d + 1][len];

}

string solve(ll N)
{
    doDP();
    string res = "";
    int len = 1, u = 0, d = 0, pos = 0;
    while(N > get1(len)){
        N -= get1(len++);
    }
    for(int i = 1; i <= len; i++){
        if(u - d == 3 && pos == u){
            res += "b";
            pos--;
        }
        else if(N > get2(max(u, pos + 1), d, pos + 1, len - i)){
            N -= get2(max(u, pos + 1), d, pos + 1, len - i);
            res += "b";
            d = min(--pos, d);
        }
        else{
            res += "a";
            u = min(++pos, u);
        }
    }
    return res;
}

int main()
{
    ll N;
    cin >> N;
    cout << solve(N) << endl;
}
