#include <cstdio>
using namespace std;

#define MAXN 100005
#define MAXL 100005
#define MAXVAL 100005
#define MAXK 25
#define INF 9999999

int N, L, K, len[MAXN], val[MAXL], next[MAXL], dp[2][MAXK], ind, id;

bool can(int x)
{
    next[L] = 0;
    for(int i = L - 1; i >= 0; i--){
        if(val[i] > x){
            next[i] = 0;
        }
        else{
            next[i] = 1 + next[i + 1];
        }
    }

    for(int k = 0; k <= K; k++){
        dp[0][k] = dp[1][k] = INF;
    }
    dp[0][0] = -1;
    id = 1;

    for(int i = 1; i <= N; i++){
        for(int k = 0; k <= K; k++){
            ind = dp[id ^ 1][k] + 1;
            while(ind + len[i] < L && next[ind] < len[i] && ind + len[i] - 1 < dp[id][k]){
                ind += next[ind] + 1;
            }
            if(ind + len[i] - 1 < L && next[ind] >= len[i] && ind + len[i] - 1 < dp[id][k]){
                dp[id][k] = ind + len[i] - 1;
            }
            if(dp[id ^ 1][k] + 1 < L && next[dp[id ^ 1][k] + 1] < len[i]){
                dp[id][k + 1] = dp[id ^ 1][k] + len[i];
            }
        }
        id ^= 1;
        for(int k = 0; k <= K; k++){
            dp[id][k] = INF;
        }
    }

    for(int k = 0; k <= K; k++){
        if(dp[id ^ 1][k] < L){
            return 1;
        }
    }
    return 0;
}

int solve()
{
    int d = 0, u = MAXVAL, mid;
    while(d + 1 < u){
        mid = (d + u) / 2;
        if(can(mid)){
            u = mid;
        }
        else{
            d = mid;
        }
    }
    if(can(d)){
        return d;
    }
    return u;
}

int main()
{
    scanf("%d%d%d", &N, &L, &K);
    for(int i = 1; i <= N; i++){
        scanf("%d", &len[i]);
    }
    for(int i = 0; i < L; i++){
        scanf("%d", &val[i]);
    }
    printf("%d\n", solve());
}
