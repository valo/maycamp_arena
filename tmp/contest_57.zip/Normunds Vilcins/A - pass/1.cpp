#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

typedef unsigned long long ull;

ull solve(string s)
{
    sort(s.begin(), s.end());
    ull res, factorial[21];
    factorial[0] = 1;
    for(int i = 1; i <= 20; i++){
        factorial[i] = i * factorial[i - 1];
    }
    res = factorial[s.size()];
    for(int i = 0; i < s.size(); i++){
        int j = 1;
        while(i + j < s.size() && s[i] == s[i + j]){
            j++;
        }
        res /= factorial[j];
        i += j - 1;
    }

    bool allDifferent = 1;
    for(int i = 0; i + 1 < s.size(); i++){
        allDifferent &= s[i] != s[i + 1];
    }
    if(allDifferent){
        return res / 2;
    }
    return res;
}

int main()
{
    string s;
    cin >> s;
    cout << solve(s) << endl;
}
