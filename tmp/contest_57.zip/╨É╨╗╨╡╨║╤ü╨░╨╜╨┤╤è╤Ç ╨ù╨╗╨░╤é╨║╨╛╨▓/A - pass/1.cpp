#include <cstdio>
#include <string.h>

int v[256];
char in[32];

long long fact ( int N ) {
     int ret = 1;
       for (int i = 2; i <= N; i++)
            ret *= i;
      return ret;
}

int main() {

    int N , i;
    scanf ( "%s" , in );
    N = (int) strlen ( in );

      for (i = 0; i < N; i++)
        ++v[ in[i] ];

    long long ret = fact ( N );
    long long div = 1;

    for (i = 0; i < 256; i++)
        div *= fact ( v[i] );

    if ( div == 1 ) printf ( "%lld\n" , ret / 2 );
    else printf ( "%lld\n" , ret / div );

    return 0;
}
