/*

TASK:pass

LANG:C++

*/

#include <iostream>

#include <map>

#include <cstring>

using namespace std;

typedef long long llong;

llong fact(int up){

  if(up==0)return 1;

  llong ret=1;

  for(int i=1;i<=up;i++)ret*=i;

  return ret;

}

map<char,int> br;

char vhod[30];

bool state_type=false;

int main(){

  int i,l;

  //system("pause");

  scanf("%s",&vhod);

  l=strlen(vhod);

  for(i=0;i<l;i++){br[vhod[i]]++;if(br[vhod[i]]>1)state_type=true;}

  if(!state_type)cout<<(fact(l)/((llong)(2)))<<'\n';

  else{

   llong ans=fact(l);

   for(map<char,int>::iterator it=br.begin();it!=br.end();it++)ans/=fact((it->second));

   cout<<ans<<'\n';

      }

  return 0;

}
