#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXN = 100002;

int n , l , dead;
int a[MAXN] , b[MAXN];
int dp[21][MAXN];
int  r[21][MAXN];

void read() {

     scanf ( "%d%d%d" , &n , &l , &dead );
     for (int i = 1; i <= n; i++)
             scanf ( "%d" , &a[i] );

     for (int i = 1; i <= l; i++)
             scanf ( "%d" , &b[i] );
}

void initRMQ() {

     int i , j;
       for (i = 1; i <= l; i++)
            r[0][i] = b[i];

       for (i = 1; (1 << i ) <= l; i++)
         for (j = 1; j + (1 << i ) - 1 <= l; j++)
             r[i][j] = max ( r[i - 1][j] , r[i - 1][j + (1 << (i - 1))] );
}

int can ( int lvl ) {

     int i , j , pos , t;

       for (i = 0; i <= dead; i++)
               for (j = 1; j <= n; j++)
             dp[i][j] = l + 1;

       for (i = 0; i <= dead; i++)
              dp[i][0] = 0;

       for (i = 0; i <= dead; i++) {
                for (j = 1; j <= n; j++) {
                    pos = dp[i][j - 1];

                    dp[i + 1][j] = min ( dp[i + 1][j] , pos + a[j] );

                    t = 31 - __builtin_clz ( a[j] );

                    for (pos++; pos + a[j] - 1 <= l; pos++ )
                        if ( max ( r[t][pos] , r[t][pos + a[j] - (1 << t)] ) <= lvl ) {
                           if ( dp[i][j] > pos + a[j] - 1 )
                                dp[i][j] = pos + a[j] - 1;
                                break;
                        }
                }

         if ( dp[i][n] <= l ) return 1;
       }

    return 0;
}

void solve() {

   int l = 0 , r = MAXN , mid;

   while ( l < r ) {
       mid =  ( r + l ) / 2;
       if ( can ( mid ) ) r = mid;
       else l = mid + 1;
   }

   printf ( "%d\n" , l );
}

int main() {

    read();
    initRMQ();
    solve();

    return 0;
}
