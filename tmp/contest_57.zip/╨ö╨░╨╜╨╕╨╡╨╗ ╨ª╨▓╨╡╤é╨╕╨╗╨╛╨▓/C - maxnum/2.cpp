#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <stdlib.h>
#include <iomanip>
#include <fstream>
#include <set>

#define SP system("pause");

int maxn = 99999;

typedef long long int lli;

using namespace std;

int n;
string p[ 105 ];
string a = "";
string max_n = "";
int used[ 105 ];

void check()
{
    if ( a > max_n ) max_n = a;
}
void find_max( int k )
{
    if ( k >= n ) check();
    else
    {
        for ( int i = 0; i < n; i++ )
        {
            if ( used[ i ] == 0 )
            {
                a += p[ i ];
                used[ i ] = 1;
                find_max( k + 1 );
                a.erase( a.end() - p[ i ].size(), a.end() );
                used[ i ] = 0;
            }
        }
    }
}
void input()
{
    cin >> n;
    for ( int i = 0; i < n; i++ )
    {
        cin >> p[ i ];
    }
    find_max( 0 );
}
int main()
{
     input();
     cout << max_n << endl;
       
	return 0;
}
