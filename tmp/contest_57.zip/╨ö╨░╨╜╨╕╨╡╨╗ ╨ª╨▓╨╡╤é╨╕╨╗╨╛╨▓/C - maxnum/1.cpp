#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <stdlib.h>
#include <iomanip>
#include <fstream>
#include <set>

#define SP system("pause");

int maxn = 99999;

typedef long long int lli;

using namespace std;

int main()
{
    int n;
    int a[ 105 ];
    cin >> n;
    for ( int i = 0; i < n; i++ )
    {
        cin >> a[ i ];
    }
    sort( a, a + n );
    for ( int i = n - 1; i >= 0; i-- ) cout << a[ i ];
    cout << endl;
       
	return 0;
}
