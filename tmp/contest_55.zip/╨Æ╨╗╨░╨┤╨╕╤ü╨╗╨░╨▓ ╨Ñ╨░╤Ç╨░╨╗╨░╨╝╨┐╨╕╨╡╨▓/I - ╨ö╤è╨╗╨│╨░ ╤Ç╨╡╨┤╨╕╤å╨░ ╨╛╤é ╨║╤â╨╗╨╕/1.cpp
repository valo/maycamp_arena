#include <cstdio>
#include <cstdlib>
#include <stack>
#define S 1000010
using namespace std;
int vhod[S],fl[S],fr[S];
int n;
stack<int> u;
void solve(){
  int i,j;
  scanf("%d",&n);
  vhod[0]=vhod[n+1]=-1;
  for(i=1;i<=n;i++)scanf("%d",&vhod[i]);
  while(!u.empty())u.pop();;u.push(n+1);
  for(i=n;i>0;i--){
   while(vhod[u.top()]>=vhod[i])u.pop();
   fr[i]=u.top();
   u.push(i);
                  }
  while(!u.empty())u.pop();;u.push(0);
  for(i=1;i<=n;i++){
   while(vhod[u.top()]>=vhod[i])u.pop();
   fl[i]=u.top();
   u.push(i);
                   }
  int ans=0;
  for(i=1;i<=n;i++)if(ans < (fr[i]-fl[i]-1)*vhod[i]) ans=(fr[i]-fl[i]-1)*vhod[i];
  printf("%d\n",ans);
}
int main(){
  int how;
  scanf("%d",&how);
  for(int i=0;i<how;i++)solve();
  return 0;
}
