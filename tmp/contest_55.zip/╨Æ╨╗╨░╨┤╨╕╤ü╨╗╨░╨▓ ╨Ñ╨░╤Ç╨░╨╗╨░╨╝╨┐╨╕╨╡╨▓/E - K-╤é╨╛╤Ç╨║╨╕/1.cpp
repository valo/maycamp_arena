#include <iostream>
using namespace std;
typedef long long ll;
ll cf[55][21];// k-orka, elem
bool solved[55][21];
int n,k;
int r[21];
int red[21][11];
ll calc(int how,int aft){
  if(how<0)return 0;
  if(how==0 && aft>=n)return 1;
  if(aft>=n)return 0;
  if(solved[how][aft])return cf[how][aft];
  solved[how][aft]=true;cf[how][aft]=0;
  for(int i=0;i<r[aft];i++)cf[how][aft]+=calc(how-red[aft][i],aft+1);
  return cf[how][aft];
}
void solve(){
  int i,j;
  cin>>n>>k;
  for(i=0;i<=k;i++)
   for(j=0;j<n;j++)solved[i][j]=false;
  for(i=0;i<n;i++){
   cin>>r[i];
   for(j=0;j<r[i];j++)cin>>red[i][j];
                  }
  cout<<calc(k,0)<<'\n';
}
int main(){
  //system("pause");
  int Q;cin>>Q;
  while((Q--)>0)solve();
  //system("pause");
  return 0;
}
