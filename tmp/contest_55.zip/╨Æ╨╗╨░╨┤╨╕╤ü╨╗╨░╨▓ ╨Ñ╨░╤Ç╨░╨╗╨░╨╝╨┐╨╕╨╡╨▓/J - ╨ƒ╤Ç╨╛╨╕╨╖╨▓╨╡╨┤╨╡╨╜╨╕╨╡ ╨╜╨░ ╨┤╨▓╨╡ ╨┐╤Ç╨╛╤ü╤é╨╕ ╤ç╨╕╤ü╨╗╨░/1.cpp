//#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
using namespace std;
typedef long long ll;
ll T;
ll gcd(ll a,ll b){
  if(b<0)b*=-1;
  if(a<b){T=a;a=b;b=T;}
  while(b>0){T=a%b;a=b;b=T;}
  return a;
}
int expected=100;
int polard(int a,int c){ // trying a, c is random constant
  int tek=rand()%a,cp=1,mp=2,del,base=a; 
  while(cp<expected){
   tek=((ll)(tek)*tek+c)%a;
   cp++;
   del=gcd(a,tek-base);
   if(del>1 && del<a)return del;
   if(cp==mp){mp*=2;base=tek;}
                    }
  return -1;
}
bool solve(){
  int a;
  if(scanf("%d",&a)==EOF)return false;
  expected=2.4*sqrt(sqrt(a))+20;
  int tmp;
  tmp=polard(a,1);if(tmp>0){if(tmp<(a/tmp))printf("%d %d\n",tmp,a/tmp);else printf("%d %d\n",a/tmp,tmp);return true;}
  tmp=polard(a,3);if(tmp>0){if(tmp<(a/tmp))printf("%d %d\n",tmp,a/tmp);else printf("%d %d\n",a/tmp,tmp);return true;}
  tmp=polard(a,13);if(tmp>0){if(tmp<(a/tmp))printf("%d %d\n",tmp,a/tmp);else printf("%d %d\n",a/tmp,tmp);return true;}
  return true;
}
int main(){
  srand(117451731);
  while(solve());
  return 0;
} 
