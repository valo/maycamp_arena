//#include <iostream>
#include <cstdio>
#include <vector>
#define null NULL
#define razm 131072
using namespace std;
// 1-d RMQ
struct el1{
  int st;el1 *l,*r;
  el1(){l=r=null;st=0;}
};
vector<el1* >fr1;
el1* new_el1(){el1* ret=new el1();fr1.push_back(ret);return ret;}
void free_el1(){for(int i=0;i<fr1.size();i++)delete(fr1[i]);}
class RMQ{
  public:
  el1* root;
  RMQ(){root=new_el1();}
  void vpush(el1* pos,int f,int t,int y){
   if(f==t){pos->st++;return;}
   if(y<=(f+t)/2){
    if(pos->l==null)pos->l=new_el1();
    vpush(pos->l,f,(f+t)/2,y);
    pos->st++;
                 }
   else{
    if(pos->r==null)pos->r=new_el1();
    vpush(pos->r,(f+t)/2+1,t,y);
    pos->st++;
       }
                                        }
  void push(int y){vpush(root,0,razm-1,y);}
  int vget(el1* pos,int f,int t,int y){
   if(y<f)return 0;if(t<=y)return pos->st;
   int ret=0;
   if(pos->l!=null)ret+=vget(pos->l,f,(f+t)/2,y);
   if(pos->r!=null)ret+=vget(pos->r,(f+t)/2+1,t,y);
   return ret;
                                      }
  int get(int y){return vget(root,0,razm-1,y);}
};
// 2-d RMQ
struct el2{
  RMQ st;el2 *l,*r;
  el2(){l=r=null;}
};
vector<el2* >fr2;
el2* new_el2(){el2* ret=new el2();fr2.push_back(ret);return ret;}
void free_el2(){for(int i=0;i<fr2.size();i++)delete(fr2[i]);}
el2* root2=new_el2();
void vpush(el2* pos,int f,int t,int x,int y){
 if(f==t){(pos->st).push(y);return;}
 if(x<=(f+t)/2){
  if(pos->l==null)pos->l=new_el2();
  vpush(pos->l,f,(f+t)/2,x,y);
  (pos->st).push(y);
               }
 else{
  if(pos->r==null)pos->r=new_el2();
  vpush(pos->r,(f+t)/2+1,t,x,y);
  (pos->st).push(y);
     }
                                      }
void push(int x,int y){vpush(root2,0,razm-1,x,y);}
int vget(el2* pos,int f,int t,int x,int y){
 if(x<f)return 0;if(t<=x)return (pos->st).get(y);
 int ret=0;
 if(pos->l!=null)ret+=vget(pos->l,f,(f+t)/2,x,y);
 if(pos->r!=null)ret+=vget(pos->r,(f+t)/2+1,t,x,y);
 return ret;
                                    }
int get(int x,int y){return vget(root2,0,razm-1,x,y);}
vector<int> X,Y;
void clear_all(){free_el1();free_el2();root2=new_el2();fr1.clear();fr2.clear();X.clear();Y.clear();}
void solve(){
  int i,x,y,n;
  scanf("%d",&n);
  for(int i=0;i<n;i++){
    scanf("%d%d",&x,&y);
    push(x,y);
    X.push_back(x);Y.push_back(y);
                      }
  for(int i=0;i<n;i++)printf("%d\n",get(X[i],Y[i])-1);
  clear_all();
}
int main(){
  //system("pause");
  int Q;scanf("%d",&Q);
  while((Q--)>0)solve();
  return 0;
}
