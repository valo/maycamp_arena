#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#define razm 100010
using namespace std;
// BIT
int tree[razm];
void init(){for(int i=1;i<razm;i++)tree[i]=0;}
void push(int p){for(;p<razm;p+=(p&(-p)))tree[p]++;}
int get(int p){int ret=0;for(;p>0;p-=(p&(-p)))ret+=tree[p];return ret;}
// </end>
struct point{
  int x,y,i;point(){}point(int a,int b,int c){x=a;y=b;i=c;}
  bool operator<(const point& w)const{
   if(x<w.x)return true;if(x>w.x)return false;
   return (y<w.y);
                                     }
};
vector<point> U;
int ans[50010];
void solve(){
  U.clear();init();
  int i,j,n,x,y;
  scanf("%d",&n);
  for(i=0;i<n;i++){
    scanf("%d%d",&x,&y);
    U.push_back(point(x,y,i));
                  }
  sort(U.begin(),U.end());
  for(i=0;i<n;i++){
    push(U[i].y);
    ans[U[i].i]=get(U[i].y)-1;
                  }
  for(i=0;i<n;i++)printf("%d\n",ans[i]);
}
int main(){
  //system("pause");
  int Q;scanf("%d",&Q);
  while((Q--)>0)solve();
  return 0;
}
