#include <cstdio>
int s1,t1,s2,t2;
int main(){
  int Q;scanf("%d",&Q);
  while((Q--)>0){
   scanf("%d%d%d%d",&s1,&s2,&t1,&t2);
   if(t1<=t2)printf("%d\n",s1);
   else printf("%d\n",s2);
                }
  return 0;
}
