#include <cstdio>
#define eps 0.0001
using namespace std;
double ABS(double w){return((w<0)?-w:w);}
double a,b,c;
void solve(int x1,int y1,int x2,int y2,int x3,int y3){
  double t=x1*x1-x2*x2,p=x1-x2,v=y1-y2;
  double t1=x2*x2-x3*x3,p1=x2-x3,v1=y2-y3;
  b=(t*v1-v*t1)/(t*p1-t1*p);
  a=(v-b*p)/t;
  c=y1-a*x1*x1-b*x1;
}
double yb;
double gety(double DELTA,int dx,int dy){return (yb+((DELTA)/dx)*dy);}
double get(double x){return(a*x*x+b*x+c);}
bool do_case(){
  int x1,y1,x2,y2,x3,y3;
  if(scanf("%d%d%d%d%d%d",&x1,&y1,&x2,&y2,&x3,&y3)==EOF)return false;
  solve(x1,y1,x2,y2,x3,y3);yb=y1;
  //cout<<a<<' '<<b<<' '<<c;system("pause");
  double last=x1,ans=0;
  //cout<<gety(1,2,-4);system("pause");
  for(double xp=x1+eps;xp<=x3;xp+=eps){
   ans+=(((eps)*( ABS(get(last)-gety(last-x1,x3-x1,y3-y1))+ABS(get(xp)-gety(xp-x1,x3-x1,y3-y1)) ) )/2);
   last=xp;
                                      }
  printf("%d\n",(int)(ans+0.5));
  return true;
}
int main(){
  while(do_case());
  return 0;
}
