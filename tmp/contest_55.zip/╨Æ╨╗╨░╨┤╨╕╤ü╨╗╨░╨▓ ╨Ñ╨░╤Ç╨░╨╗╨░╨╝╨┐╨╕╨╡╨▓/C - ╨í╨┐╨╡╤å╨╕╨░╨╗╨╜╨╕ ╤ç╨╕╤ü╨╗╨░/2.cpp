#include <iostream>
#include <cstring>
#include <algorithm>
#define NMAX 13
using namespace std;
char tabl[100][100];
char vhod[100];
int dp[2<<13][85];
int type[2<<13][85];
int tr=0,l;
bool is_set(int mask,int p){return (mask & (1<<p))!=0;}
void set_bit(int& mask,int p){mask|=(1<<p);}
int load(char m[],int mask,int p,int s){
  int i,hl=0,rs=0;
  for(i=0;i<s;i++)
   if(is_set(mask,i)){if(p>=l)return -1;m[hl++]=vhod[p++];rs++;}
   else m[hl++]='_';
  return rs;
}
int SIZE;
int calc(int m,int p){
  if(m==0 && p>=l)return 0;
  if(p>=l)return 1000000;
  if(type[m][p]==tr)return dp[m][p];
  type[m][p]=tr;dp[m][p]=1000000;
  char r1[81],r2[81],s1,s2;
  s1=load(r1,m,p,SIZE);if(s1<0)return 1000000;
  int i,j,upper=1<<SIZE;
  for(i=0;i<upper;i++){
   s2=load(r2,i,p+s1,SIZE);if(s2<0)continue;
   for(j=0;j<SIZE;j++)
    if(r1[j]!='_' && r2[j]!='_' && r1[j]!=r2[j])goto end;
   dp[m][p]=min(dp[m][p],calc(i,p+s1)+1);
   end:;
                      }
  return dp[m][p];
}
bool solve(){
  int i,j,s,up;
  int x,y;
  if(scanf("%s",&vhod)==EOF)return false;
  l=strlen(vhod);
  int ans=1000000;
  up=NMAX;if(up>l)up=l;
  for(i=1;i<=7;i++){
   SIZE=i;tr++;
   y=1<<SIZE;
   for(j=0;j<y;j++){ans=min(ans,2*(i+calc(j,0)));}
                    }
  printf("%d\n",ans);
  return true;
}
int main(){
  //system("pause");
  while(solve());
  //system("pause");
  return 0;
}
