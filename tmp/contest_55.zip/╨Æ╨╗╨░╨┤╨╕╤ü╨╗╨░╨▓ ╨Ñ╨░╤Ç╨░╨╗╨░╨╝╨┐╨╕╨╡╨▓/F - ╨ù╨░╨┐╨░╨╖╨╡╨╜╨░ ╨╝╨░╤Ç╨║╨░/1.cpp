#include <cstring>
#include <algorithm>
#include <vector>
#define base 51
#define code(a) (a-'a');
using namespace std;
typedef unsigned long long ll;
ll step[2010];
void init(){
 step[0]=1;
 for(int i=1;i<2005;i++)step[i]=step[i-1]*base;
}
char vhod[2010];
int data[2010],S;
vector<ll> H;
ll hash[2010];
void init_hash(){
  hash[0]=data[0]*step[0];
  for(int i=1;i<S;i++)hash[i]=hash[i-1]+data[i]*step[i];
}
ll get_hash(int p,int l){
  if(p==0)return (step[S-p]*hash[p+l-1]);
  else return (step[S-p]*(hash[p+l-1]-hash[p-1]));                
}
bool solve(){
  int ans=0;
  int i,j,l,up,B;
  if(scanf("%s",&vhod)==EOF)return false;S=strlen(vhod);
  for(i=0;i<S;i++)data[i]=code(vhod[i]);
  init_hash();
  for(l=1;l<=S;l++){
   H.clear();
   up=S-l+1;
   if(l*up<=ans)continue;
   for(i=0;i<up;i++)H.push_back(get_hash(i,l));
   sort(H.begin(),H.end());
   j=1;B=1;
   for(i=1;i<up;i++){
    if(H[i]==H[i-1])j++;
    else{if(B<j)B=j;j=1;}        
                    }
   if(B<j)B=j;
   if(ans<B*l)ans=B*l;
                   }
  printf("%d\n",ans);
  return true;
}
int main(){
  init();
  while(solve());
  return 0;
}
