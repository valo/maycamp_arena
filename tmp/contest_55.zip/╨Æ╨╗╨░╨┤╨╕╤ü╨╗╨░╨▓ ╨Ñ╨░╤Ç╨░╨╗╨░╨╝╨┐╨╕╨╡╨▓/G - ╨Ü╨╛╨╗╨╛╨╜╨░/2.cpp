#include <iostream>
using namespace std;
typedef unsigned long long ull;
int n;
ull dp[110][4];
int is[110][4],st=0;
ull calc(int len,int type){
  if(len==type)return 1;
  if(len<=0)return 0;
  if(is[len][type]==st)return dp[len][type];
  is[len][type]=st;dp[len][type]=0;
  for(int i=1;i<=3;i++)
   if(i!=type)dp[len][type]+=calc(len-type,i);
  return dp[len][type];
}
void solve(){
  cin>>n;
  st++;
  cout<<(calc(n,1)+calc(n,2)+calc(n,3))<<'\n';
}
int main(){
  int Q;cin>>Q;
  while((Q--)>0)solve();
  return 0;
}
