#include <iostream>
using namespace std;
int main(){
    long long m;
    int t;
    while ( cin >> m ){
    for ( long long i = 2; i * i <= m; ++ i )
        if ( m % i == 0 ) { cout << i << " " << m / i << endl; break;}
    }
}
