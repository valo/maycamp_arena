#include <iostream>
#include <vector>
#include <cstring>
using namespace std;
void solve(){
    int n, k;
    cin >> n >> k;
    vector <int> v[n + 2];
    for ( int i = 0; i < n; ++i ){
        int tmp;
        cin >> tmp;
        for ( int j = 0; j < tmp; ++j ){
            int tt;
            cin >> tt;
            v[i].push_back(tt);
        }
    }
    long long dp[128][128];
    memset(dp, 0, sizeof(dp));
    dp[0][0] = 1;
    for ( int i = 1; i <= n; ++i )
        for ( int j = 0; j <= k; ++j )
            for ( int p = 0; p < v[i - 1].size(); ++p )
                if ( v[i - 1][p] <= j ) dp[i][j] += dp[i - 1][j -  v[i - 1][p] ];
    cout << dp[n][k] << endl;
}
int main(){
    int tests;
    cin >> tests;
    while ( tests-- ) solve();
}
