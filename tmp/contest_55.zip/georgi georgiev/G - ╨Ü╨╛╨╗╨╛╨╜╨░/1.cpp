#include <iostream>
using namespace std;
long long dp[128][3];
int main(){
    dp[1][0] = 1;
    dp[2][1] = 1;
    dp[3][2] = 1;
    dp[3][0] = 1;
    dp[3][1] = 1;
    for ( int i = 4; i < 128; ++i ){
        dp[i][0] += dp[i - 1][2] + dp[i - 1][1];
        dp[i][1] += dp[i - 2][2] + dp[i - 2][0];
        dp[i][2] += dp[i - 3][0] + dp[i - 3][1];
    }
    int qwe;
    cin >> qwe;
    while ( qwe-- ){
        int n;
        cin >> n;
        cout << dp[n][0] + dp[n][1] + dp[n][2] << endl;
    }
}
