#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
struct triple{
    int x, y, ind, ans;
};
int it[1<<17];
triple p[1 << 17];
int find(int i){
    int sum = 0;
    for (i; i > 0; i -= ( i & (-i)) )
        sum += it[i];
    return sum;
}
void update(int i){
    for ( i; i < (1 << 17); i += (i &(-i)))
        it[i]++;
}
bool f1(triple t1, triple t2){
    if ( t1.x == t2.x ) return t1.y < t2.y;
    return t1.x < t2.x;
}
bool f2(triple t1, triple t2){
    return t1.ind < t2.ind;
}
void solve(){
    int n;
    cin >> n;
    for ( int i = 0; i < n; ++i ){
        cin >> p[i].x >> p[i].y;
        p[i].ind = i;
    }
    sort(p, p + n, f1);
    for ( int i = 0; i < n; ++i ){
        p[i].ans =  find(p[i].y) ;
        update(p[i].y);
    }
    sort(p, p + n, f2);
    for ( int i = 0; i < n; ++i )
        cout << p[i].ans << endl;
    memset(it, 0, sizeof(it));
}
int main(){
    int tests;
    cin >> tests;
    while ( tests-- ){
        solve();
    }
}
