#include <iostream>
using namespace std;
int main(){
    int tests;
    cin >> tests;
    while ( tests-- ) {
        long long a, b, c ,d;
        cin >> a >> b >> c >> d;
        if ( d < c ) cout << b << endl;
        else cout << a << endl;
    }
}
