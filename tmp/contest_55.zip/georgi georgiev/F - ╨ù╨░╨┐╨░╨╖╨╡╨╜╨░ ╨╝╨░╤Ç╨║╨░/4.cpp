#include <iostream>
#include <vector>
#include <algorithm>
#define b1 31
#define b2 101
using namespace std;
string a;
unsigned hash[1 << 11], pows[1 << 11];
unsigned findhash(int start, int end){
    unsigned result = hash[end];
    --start;
    if ( start < 0 ) return result;
    result -= (hash[start]* pows[end - start] );
    return result;
}
void solve(){
    hash[0] = a[0] - 'a' + 1;
    for ( int i = 1; i < a.size(); ++i )
        hash[i] = hash[i - 1] * b1 + a[i] - 'a' + 1;
    int ans = 0;
    for ( int i = 1; i <= a.size(); ++i ){
            vector<unsigned> v;
        for ( int j = 0; j <= a.size() - i; ++j ){
            unsigned tt = findhash(j, j + i - 1);
            v.push_back(tt);
        }
        sort(v.begin(), v.end());
        v.push_back(-1);
        int br = 1;
        for ( int q = 1; q < v.size(); ++q )
        if ( v[q] == v[q - 1] ) ++br;
        else { ans = max(ans, i * br); br = 1; }
    }
    cout << ans << endl;
}
void setpows(){
    pows[0] = 1;
    for ( int i = 1; i < (1 << 11); ++i )
        pows[i] = pows[i - 1] * b1;
}
int main(){
    int tests;
    setpows();
    while ( cin >> a )  solve();
}
