#include <iostream>
#include <map>
#define b1 31
#define b2 101
using namespace std;
map < unsigned, int> mp;
string a;
unsigned hash[1 << 11], pows[1 << 11];
unsigned findhash(int start, int end){
    unsigned result = hash[end];
    --start;
    if ( start < 0 ) return result;
    result -= (hash[start]* pows[end - start] );
    return result;
}
void solve(){
    hash[0] = a[0] - 'a' + 1;
    for ( int i = 1; i < a.size(); ++i )
        hash[i] = hash[i - 1] * b1 + a[i] - 'a' + 1;
    int ans = 0;
    for ( int i = 1; i <= a.size(); ++i ){
        for ( int j = 0; j <= a.size() - i; ++j ){
            unsigned tt = findhash(j, j + i - 1);
            map < unsigned, int> ::iterator it = mp.find(tt);
            if ( it == mp.end() ) mp[tt] = 1;
            else ++mp[tt];
            ans = max(ans, mp[tt] * i);
        }
        mp.erase(mp.begin(), mp.end());
    }
    cout << ans << endl;
    mp.erase(mp.begin(), mp.end());
}
void setpows(){
    pows[0] = 1;
    for ( int i = 1; i < (1 << 11); ++i )
        pows[i] = pows[i - 1] * b1;
}
int main(){
    int tests;
    setpows();
    while ( cin >> a )  solve();
}
