#include <cstdio>
using namespace std;
int n;
int a[1 << 16];
int max(int p, int q){
    if ( p > q ) return p;
    return q;
}
void solve(){
    scanf("%d", &n);
    for ( int i = 1; i <= n; ++i )
        scanf("%d", &a[i]);
    int mx = 0;
    for ( int i = 1; i <= n; ++i ){
        int t1 = i, t2 = i;
        while ( a[t1] >= a[i] ) --t1;
        while ( a[t2] >= a[i] ) ++t2;
        mx = max(mx, (t2 - t1 - 1) * a[i]);
    }
    printf("%d\n", mx);
}
int main(){
    int tests;
    scanf("%d\n", &tests);
    while ( tests-- ) solve();
}
