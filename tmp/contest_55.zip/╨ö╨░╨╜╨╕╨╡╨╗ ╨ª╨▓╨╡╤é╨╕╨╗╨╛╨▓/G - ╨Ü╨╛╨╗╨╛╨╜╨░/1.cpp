#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <stdlib.h>
#include <iomanip>
#include <fstream>
#include <set>

#define SP system("pause");

int maxn = 99999;

typedef long long int lli;

using namespace std;

lli t;
vector < int > n;
int mp[ 105 ];
int res;

void devnum( int k, int pos )
{
    if ( k == 0 ) 
    {
          res++;
    }
    else 
    {
        for ( int i = 3; i >= 1; i-- )
        {
            if ( k - i >= 0 )
            {
                if ( i != mp[ pos - 1 ] )
                {
                    mp[ pos ] = i;
                    devnum( k - i, pos + 1 );
                    mp[ pos ] = 0;
                }
            }
        }
    }
}
int main()
{
    cin >> t;
    int a;
    for ( int i = 0; i < t; i++ )
    {
        cin >> a;
        n.push_back( a );
    }
    mp[ 0 ] = 0;
    for ( int i = 0; i < n.size(); i++ )
    {
        res = 0;
        devnum( n[ i ], 1 );
        cout << res << endl;
    }
        
	return 0;
}
