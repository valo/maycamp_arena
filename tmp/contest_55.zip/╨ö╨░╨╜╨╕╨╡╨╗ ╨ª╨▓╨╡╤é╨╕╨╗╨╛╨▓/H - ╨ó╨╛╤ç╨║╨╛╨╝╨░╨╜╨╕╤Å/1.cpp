#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <stdlib.h>
#include <iomanip>
#include <fstream>
#include <set>

#define SP system("pause");
#define x first
#define y second 

int maxn = 99999;

typedef long long int lli;

using namespace std;
pair < int, int > p[ 50005 ];
int main()
{
    lli t;
    cin >> t;
    int n;
    
    vector < int > r;
    int br;
    
    for ( int i = 0; i < t; i++ )
    {
        cin >> n;
        for ( int i = 0; i < n; i++ )
        {
            cin >> p[ i ].x >> p[ i ].y;
        }
        
        for ( int i = 0; i < n; i++ )
        {
            br = 0;
            for ( int j = 0; j < n; j++ )
            {
                if ( i != j )
                {
                    if ( p[ i ].x >= p[ j ].x && p[ i ].y >= p[ j ].y ) br++;
                }
            }
            r.push_back( br );
        }
        for ( int i = 0; i < r.size(); i++ )
        {
            cout << r[ i ] << endl;
        }
        r.clear();
    }
    
        
	return 0;
}
