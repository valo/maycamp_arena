#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;
struct four
{
       long long first,second,third,fourth;
};
long long m,t,i,n,j,it[131073];
four a[50001];
bool cmpf(four a, four b)
{
     if(a.first<b.first) return true;
     else return false;
}
bool cmps(four a, four b)
{
     if(a.second<b.second) return true;
     else if(a.second==b.second)
     {
          if(a.third<b.third) return true;
          else if(a.third==b.third)
          {
               if(a.first<b.first) return true;
               else return false;
          }
          else return false;
     }
     else return false;
}
void push(long long x)
{
     x+=m-1;
     while(x!=0)
     {
                it[x]++;
                x/=2;
     }
}
long long pop(long long x)
{
     x+=m-1;
     long long sum=it[x];
     while(x!=1)
     {
                if((x&1)==1) {sum+=it[x-1];}
                x/=2;
     }
     return sum;
}
int main()
{
    cin>>t;
    for(i=1; i<=t; i++)
    {
             scanf("%lld",&n);
             for(j=1; j<=n; j++)
             {
                      scanf("%lld%lld",&a[j].second,&a[j].third);
                      a[j].first=j;
             }
             sort(a+1, a+n+1, cmps);
             m=1;
             while(m<n) m*=2;
             for(j=1; j<=n; j++)
             {
                      a[j].fourth=pop(a[j].third);
                      push(a[j].third);
             }
             sort(a+1, a+n+1, cmpf);
             for(j=1; j<=n; j++)
             {
                      printf("%lld\n",a[j].fourth);
             }
             for(j=1; j<=m*2; j++)
             {
                      it[j]=0;
             }
    }
    //system ("pause");
    return 0;
}
