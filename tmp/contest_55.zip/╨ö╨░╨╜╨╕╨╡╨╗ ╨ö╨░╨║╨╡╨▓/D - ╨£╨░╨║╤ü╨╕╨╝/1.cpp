#include<iostream>
using namespace std;
long long m,n,a,b,t,i;
int main()
{
    cin>>t;
    for(i=1; i<=t; i++)
    {
             cin>>m>>n>>a>>b;
             if(a>b) cout<<n<<endl;
             else cout<<m<<endl;
    }
    //system ("pause");
    return 0;
}
