#include<iostream>
#include<stdio.h>
#include<vector>
using namespace std;
long long i,n,d;
vector<long long> v;
bool simple(long long n)
{
     for(d=2; d*d<=n; d++)
     {
              if(n%d==0) {return false;}
     }
     return true;
}
int main()
{
    while(cin>>n)
    {
                 for(i=2; i<=n; i++)
                 {
                          if(n/i<i) break;
                          if(n%i==0&&simple(i)&&simple(n/i)) {cout<<i<<" "<<n/i<<endl; break;}
                 }
    }
    //system ("pause");
    return 0;
}
