#include<iostream>
#include<stdio.h>
#include<vector>
using namespace std;
long long a[147483648],i,j,n,m,max1;
vector<long long> v;
void simple(long long n)
{
     a[1]=1;
     for(i=max1+1; i<=n; i++)
     {
              if(a[i]==0) {v.push_back(i);
              for(j=i*i; j<=n; j+=i)
              {
                         a[j]=1;
              }
              }
     }
}
int main()
{
    max1=1;
    while(cin>>n)
    {
                 simple(n);
                 if(max1<n) max1=n;
                 m=v.size();
                 for(i=0; i<=m-1; i++)
                 {
                          if(n/v[i]<v[i]) break;
                          if(n%v[i]==0) {if(a[n/v[i]]==0) {cout<<v[i]<<" "<<n/v[i]<<endl; break;}}
                 }
    }
    //system ("pause");
    return 0;
}
