#include<iostream>
#include<stdio.h>
using namespace std;
long long br,t,n,i;
void col(long long n, long long p)
{
     if(n<0) return ;
     if(n==0) {br++; return ;}
     if(p==1) {col(n-2,2); col(n-3,3);}
     else if(p==2) {col(n-1,1); col(n-3,3);}
     else if(p==3) {col(n-1,1); col(n-2,2);}
     else {col(n-1,1); col(n-2,2); col(n-3,3);}
}
int main()
{
    cin>>t;
    for(i=1; i<=t; i++)
    {
             br=0;
             scanf("%lld",&n);
             col(n,0);
             printf("%lld\n",br);
    }
    //system ("pause");
    return 0;
}
