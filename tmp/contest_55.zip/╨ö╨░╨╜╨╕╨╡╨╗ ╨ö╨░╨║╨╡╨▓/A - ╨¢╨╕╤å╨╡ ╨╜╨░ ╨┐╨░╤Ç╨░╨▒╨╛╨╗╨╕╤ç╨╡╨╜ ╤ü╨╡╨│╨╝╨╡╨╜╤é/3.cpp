#include<iostream>
#include<stdio.h>
#include<math.h>
using namespace std;
long long x1,z,x2,y2,x3,y3;
long long area(long long x1, long long z, long long x2, long long y2, long long x3, long long y3)
{
     long long s=(x2-x1)*(y2+z)+(x3-x2)*(y3+y2)+(x3-x1)*(z+y3);
     s/=2;
     return s;
}
int main()
{
    while(cin>>x1>>z>>x2>>y2>>x3>>y3)
    {
                                     if(x2-x1==x3-x2) {cout<<4*area(x1,z,x2,y2,x3,y3)/3<<endl;}
                                     else cout<<2167<<endl;
    }
//    system ("pause");
    return 0;
}
