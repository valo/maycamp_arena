#include<iostream>
#include<stdio.h>
using namespace std;
long long n,i,br,j,max1,a[40001],t,l;
int main()
{
    cin>>t;
    for(l=1; l<=t; l++)
    {
             cin>>n;
             for(i=1; i<=n; i++)
             {
                      cin>>a[i];
             }
             for(i=1; i<=n; i++)
             {
                      br=1;
                      for(j=i+1; j<=n; j++)
                      {
                                 if(a[j]<a[i]) break;
                                 else br++;
                      }
                      for(j=i-1; j>=1; j--)
                      {
                                 if(a[j]<a[i]) break;
                                 else br++;
                      }
                      if(br*a[i]>max1) max1=br*a[i];
             }
             cout<<max1<<endl;
    }
    //system ("pause");
    return 0;
}
