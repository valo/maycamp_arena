#include <iostream>
#include <string.h>
#include <cstdio>
#include <algorithm>
#define lbit(x) (x&-x)
using namespace std;
int tree[131072],ids[110000],N,p;
struct point
{
    int x,y,id;
};
point a[110000];
bool cmp (point A,point B)
{
    if (A.y<B.y) return 1;
    if (A.y==B.y && A.x<B.x) return 1;
    return 0;
}
//int lbit (int x)
//{return x&(-x);}

void add (int v)
{     while (v<=131071)
        {   tree[v]++;
            v+=lbit(v);
    }
}
int find (int v)
{  int sum=0;
      while (v>=1)
        {   sum+=tree[v];
            v-=lbit(v);
    }
    return sum;
}


void solve ()
{
    for (int i=0;i<p;i++)
    { // ids[a[i].id]=find(a[i].x);
        add (a[i].x);
        ids[a[i].id]=find(a[i].x)-1;
    }
    for (int i=0;i<p;i++)
 //   cout<<ids[i]<<endl;
   printf("%d\n",ids[i]);
                    memset(tree,0,sizeof(tree));
                    memset(a,0,sizeof(a));
                    memset(ids,0,sizeof(ids));

    }

int main ()
{
    cin>>N;
    while (N--)
        {
                cin>>p;
                for  (int i=0;i<p;i++)
                   { 		scanf("%d%d",&a[i].x,&a[i].y);
                       //cin>>a[i].x>>a[i].y;
                       a[i].id=i;}
                    sort (a,a+p,cmp);
                    solve ();        }

}
