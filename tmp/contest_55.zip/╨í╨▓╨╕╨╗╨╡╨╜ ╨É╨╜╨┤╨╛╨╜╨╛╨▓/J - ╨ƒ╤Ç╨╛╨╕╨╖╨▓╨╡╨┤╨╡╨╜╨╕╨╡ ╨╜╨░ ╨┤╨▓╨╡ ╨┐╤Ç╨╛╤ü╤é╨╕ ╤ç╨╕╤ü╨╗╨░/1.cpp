#include <iostream>
using namespace std;
int main ()
{   long long n,i,t;
 while (cin>>n)
    {
            for ( i=2;n%i;i++)
            {};
            cout<<i<<" "<<n/i<<endl;


            }
}
