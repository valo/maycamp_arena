#include <iostream>
using namespace std;
int a,N,b,c,d;
int main ()
{   cin>>N;
    while (N--)
    {cin>>a>>b>>c>>d;
    if (c>d) cout<<b<<endl;
    else cout<<a<<endl;
    }
        }
