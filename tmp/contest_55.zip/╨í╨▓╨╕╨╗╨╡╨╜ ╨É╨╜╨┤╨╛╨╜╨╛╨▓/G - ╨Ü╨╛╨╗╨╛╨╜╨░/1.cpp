#include <iostream>
using namespace std;
int N,p;
struct point
{
   long long x,y,z;
    };point a[1<<8];

    void prec ()
    {   memset(a,0,sizeof(a));
            a[1].x=1;
            //a[2].x=1; WTF!?!
            a[3].x=1;
            a[2].y=1;
            a[3].y=1;
            a[3].z=1;
                       for (int i=4;i<101;i++)
                      { a[i].x=a[i-1].y+a[i-1].z;
                        a[i].y=a[i-2].x+a[i-2].z;
                        a[i].z=a[i-3].x+a[i-3].y;
                      }
    }

int main ()
{   cin>>N;
      prec ();

    while(N--)
    {   cin>>p;
        cout<<a[p].x+a[p].y+a[p].z<<endl;
            }

        }
