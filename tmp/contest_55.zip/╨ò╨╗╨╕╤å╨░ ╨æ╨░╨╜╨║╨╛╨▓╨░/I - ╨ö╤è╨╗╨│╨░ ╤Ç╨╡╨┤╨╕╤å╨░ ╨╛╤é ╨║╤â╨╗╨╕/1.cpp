#include<iostream>
using namespace std;
long long t,i,j,maxbr,br,n,a[1000001];
int main()
 {
 scanf("%d",&t);
 while(t>0)
 {t--;
  scanf("%d",&n);
  for(i=1;i<=n;i++)
  scanf("%d",&a[i]);
  for(i=1;i<=n;i++)
  {br=1;
   for(j=i+1;j<=n;j++)
    if(a[i]<a[j]) br++;
    else break;
   for(j=i-1;j>=1;j--)
    if(a[i]<a[j]) br++;
    else break;
   br*=a[i];
   maxbr=max(maxbr,br);
  }
  cout<<maxbr<<endl;
  maxbr=0;
 }
 return 0;
 }
