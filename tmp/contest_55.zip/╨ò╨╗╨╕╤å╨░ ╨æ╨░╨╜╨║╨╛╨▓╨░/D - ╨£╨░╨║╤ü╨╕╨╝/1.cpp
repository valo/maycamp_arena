#include<iostream>
using namespace std;
long k,n,m,t1,t2,i;
int main()
 {
 cin>>k;
 for(i=1;i<=k;i++)
 {cin>>m>>n>>t1>>t2;
  if(t1>t2) cout<<n<<endl;
  else cout<<m<<endl;
 }
 return 0;
 }
