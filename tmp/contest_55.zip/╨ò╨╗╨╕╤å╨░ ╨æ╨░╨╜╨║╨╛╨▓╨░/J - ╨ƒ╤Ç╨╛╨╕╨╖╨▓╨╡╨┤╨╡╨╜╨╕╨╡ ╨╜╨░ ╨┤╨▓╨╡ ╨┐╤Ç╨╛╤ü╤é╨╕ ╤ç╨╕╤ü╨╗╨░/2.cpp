#include<iostream>
using namespace std;
long long i,x,a,b;
int main()
 {
 while(cin>>x)
 {if(x%2==0) a=2;
  for(i=3;i*i<=x;i++)
  if(x%i==0) {a=i;break;}
  b=x/a;
  if(a>b) swap(a,b);
  cout<<a<<" "<<b<<endl;
 }
 return 0;
 }
