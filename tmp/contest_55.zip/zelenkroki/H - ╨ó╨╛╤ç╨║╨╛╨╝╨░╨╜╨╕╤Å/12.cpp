#include <iostream>
using namespace std;
int a[8][50001][2];
int main()
{
int t, n, i, j,broy [50], p, k, sum=0;
cin>>t;
for(i=1; i<=t; i++)
{
 cin>>n;
broy[i]=n;
 for(j=1; j<=n; j++)
    {
  cin>>a[i][j][1];
  cin>>a[i][j][2];
 }
}
for(i=1; i<=t; i++)
{
 for (p=1; p<=broy[i]; p++)
 {
  for (k=1; k<=broy[i]; k++)
  {
if (p!=k)
    {
  if (a[i][p][1]>=a[i][k][1])
      {
     if(a[i][p][2]>=a[i][k][2]) sum++;
      }
   }

  }
         }
cout<<sum<<endl;
  sum=0;
 }
 return 0;
}

