#include <iostream>
using namespace std;
int main()
{
int t, n, a[50001][2],broy[50001], rezultat[100][50001], i, j, p, k, sum=0;
cin>>t;
for(i=1; i<=t; i++)
{
 cin>>n;
 broy[i]=n;
 for(j=1; j<=n; j++)
    {
  cin>>a[j][1];
  cin>>a[j][2];
 }
 for (p=1; p<=n; p++)
 {
  for (k=1; k<=n; k++)
   {
  if ((a[p][1]>=a[k][1])&&(a[p][2]>=a[k][2])&&(p!=k)) sum++;
   }
 rezultat[i][p]=sum;
  sum=0;
 }
 }
for(i=1; i<=t; i++)
{
 for(j=1; j<=broy[i]; j++)
 {
cout<<rezultat[i][j]<<endl;
 }
}
return 0;
}
