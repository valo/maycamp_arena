#include <iostream>
using namespace std;
int main()
{
 int n, i, del1, del2;
// cin.get(n);
 while(!cin.eof())
 {
  cin>>n;
  for (i=2; i<=n/2; i++)
  {
   if ((n%i)==0) 
   {
    del1=i;
    del2=n/i;
    cout<<del1<<" "<<del2<<endl;
    break;
   }
   }
 }
 return 0;
}
