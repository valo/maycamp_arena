#include <iostream>
using namespace std;
int main()
{
int t, udob[10], m, n, tm, tn, i, j;
cin>>t;
for(i=1; i<=t; i++)
{
 cin>>m>>n>>tm>>tn;
if(tm<=tn)udob[i]=m;
else
  udobna[i]=n;
}
for (j=1; j<=t; j++)
cout<<udob[j]<<endl;
 return 0;
}
