#include <iostream>
using namespace std;
int main()
{
int t, udobna[20], m, n, tm, tn, i, j;
cin>>t;
for(i=1; i<=t; i++)
{
 cin>>m>>n>>tm>>tn;
if(tm<=tn)udobna[i]=m;
else
  udobna[i]=n;
}
for (j=1; j<=t; j++)
cout<<udobna[j]<<endl;
 return 0;
}
