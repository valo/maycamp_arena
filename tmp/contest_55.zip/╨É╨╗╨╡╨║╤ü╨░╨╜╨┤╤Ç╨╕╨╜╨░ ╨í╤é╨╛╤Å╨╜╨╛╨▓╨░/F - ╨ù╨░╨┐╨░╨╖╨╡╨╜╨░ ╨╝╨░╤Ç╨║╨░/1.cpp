#include<iostream>
#include<string>
using namespace std;
string s,t,l;
int ans,br,ansl=-1;
int main()
{
    int n,i,j;
    while(cin>>s)
    {
        ans=0;
        br=0;
        ansl=-1;
        n=s.length();
        for(i=0;i<n;i++)
            s[i]=tolower(s[i]);
        for(i=1;i<=n;i++)
        {
            br=0;
            t=s.substr(0,i);
            //cout<<t<<"\n/***********/"<<endl;
            for(j=0;j<=(n-t.length());j++)
            {
                l=s.substr(j,t.length());
  //              cout<<l<<" "<<t<<endl;
                if(l==t) br++;
                l.clear();
            }
//            cout<<br<<" "<<i<<endl;
            if(br*i>ans)
            {
                ans=br*i;
            }
        }
        cout<<ans<<endl;
        //cout<<s<<endl;
    }
    return 0;
}
