#include<iostream>
#include<vector>
using namespace std;
long t,n,i,j,s,e,l,r,mn,mnp,ans,mx;
long a[1000001],b[2000002][2];
int main()
{
    cin>>t;
    int j;
    for(i=0;i<t;i++)
    {
        ans=0;
        cin>>n;
        for(j=1;j<=n;j++)
            cin>>a[j];
        s=0;e=1;b[0][0]=1;b[0][1]=n;
        while(s<e)
        { 
        l=b[s][0];r=b[s][1];s++;
        mn=a[l];mnp=l;
        for(j=l+1;j<=r;j++)
            if(a[j]<mn){mn=a[j];mnp=j;}
        mx=(r-l+1)*mn;
        if(mx>ans)ans=mx;
        if(l==r) continue;
        if(mnp==l){b[e][0]=l+1;b[e][1]=r;e++;}
        else
            if(mnp==r){b[e][0]=l;b[e][1]=r-1;e++;}
            else
            {b[e][0]=l;b[e][1]=mnp-1;e++;
             b[e][0]=mnp+1;b[e][1]=r;e++;}  
        }
        cout<<ans<<endl;    
    }
    return 0;
}
