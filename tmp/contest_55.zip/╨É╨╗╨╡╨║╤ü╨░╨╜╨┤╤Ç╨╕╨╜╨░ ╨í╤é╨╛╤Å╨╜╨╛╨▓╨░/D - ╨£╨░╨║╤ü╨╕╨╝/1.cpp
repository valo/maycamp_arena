#include<iostream>
using namespace std;
int t,n,m,a,b;
int main()
{
    cin>>t;
    int i;
    for(i=0;i<t;i++)
    {
        cin>>m>>n>>a>>b;
        if(a>b) cout<<n<<endl;
        else cout<<m<<endl;
    }
    return 0;
}
