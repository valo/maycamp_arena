#include<iostream>
using namespace std;
long long a[128][3];
int main()
{
    a[0][0]=1;
    a[1][0]=1;
    a[2][1]=1;
    a[3][0]=a[2][1]+a[2][2];
    a[3][1]=a[1][0]+a[1][2];
    a[3][2]=a[0][1]+a[0][0];
    int i;
    for(i=4;i<101;i++)
    {
        a[i][0]=a[i-1][1]+a[i-1][2];
        a[i][1]=a[i-2][0]+a[i-2][2];
        a[i][2]=a[i-3][0]+a[i-3][1];
    }
    int t,n;
    cin>>t;
    for(i=0;i<t;i++)
    {
        cin>>n;
        cout<<(a[n][0]+a[n][1]+a[n][2])<<endl;        
    }
    return 0;
}
