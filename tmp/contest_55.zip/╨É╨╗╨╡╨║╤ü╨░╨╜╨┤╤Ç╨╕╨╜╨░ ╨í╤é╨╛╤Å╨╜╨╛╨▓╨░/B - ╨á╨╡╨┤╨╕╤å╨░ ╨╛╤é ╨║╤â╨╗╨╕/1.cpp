#include<iostream>
#include<vector>
using namespace std;
int t,n,i,j,s,e,l,r,mn,mnp,ans,mx;
int a[40001],b[80002][2];
int main()
{
    cin>>t;
    for(i=0;i<t;i++)
    {
        cin>>n;
        for(j=1;j<=n;j++)
            cin>>a[j];
        s=0;e=1;b[0][0]=1;b[0][1]=n;
        while(s<e)
        { 
        l=b[s][0];r=b[s][1];s++;
        mn=a[l];mnp=l;
        for(i=l+1;i<=r;i++)
            if(a[i]<mn){mn=a[i];mnp=i;}
        mx=(r-l+1)*mn;
        if(mx>ans)ans=mx;
        if(l==r) continue;
        if(mnp==l){b[e][0]=l+1;b[e][1]=r;e++;}
        else
            if(mnp==r){b[e][0]=l;b[e][1]=r-1;e++;}
            else
            {b[e][0]=l;b[e][1]=mnp-1;e++;
             b[e][0]=mnp+1;b[e][1]=r;e++;}  
        }
        cout<<ans<<endl;    
    }
    return 0;
}
