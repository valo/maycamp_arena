#include <cstdio>
#include <algorithm>
#include <string.h>
#define LB(x1) ((x1) & (-x1))
#define MAX 131072
using namespace std;
int tree[MAX+10],ans[50002],N;

struct Point{
    int x,y,ind;
}pt[50002];

int cmp(Point a,Point b){
    if(a.y < b.y) return 1;

    if(a.y == b.y)
        if(a.x < b.x) return 1;

    return 0;
}

void read(){

    memset(pt,0,sizeof(pt));
    scanf("%d",&N);
      for(int i=0;i<N;i++){
          scanf("%d%d",&pt[i].x,&pt[i].y);
          pt[i].ind = i;
      }
}

void update(int pos){
     while(pos <= MAX){
         tree[pos]++;
         pos += LB(pos);
     }
}

int query(int pos){
    int sum = 0;
      while(pos >= 1){
          sum += tree[pos];
          pos -= LB(pos);
      }
  return sum;
}

void solve(){
     memset(tree,0,sizeof(tree));
     memset(ans,0,sizeof(ans));
     int i;
     sort(pt,pt + N,cmp);

        for(i=0;i<N;i++){
            update(pt[i].x);
            ans[pt[i].ind] = query(pt[i].x) - 1;
        }
    for(i=0;i<N;i++) printf("%d\n",ans[i]);

}

int main(){
    int T;
      scanf("%d\n",&T);
        while(T--){
            read();
            solve();
        }
    return 0;
}

