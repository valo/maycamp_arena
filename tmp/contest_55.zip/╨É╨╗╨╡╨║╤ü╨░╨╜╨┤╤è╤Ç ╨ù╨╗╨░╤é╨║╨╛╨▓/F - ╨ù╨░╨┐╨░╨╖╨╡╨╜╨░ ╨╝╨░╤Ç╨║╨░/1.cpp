#include <cstdio>
#include <vector>
#include <string.h>
#include <algorithm>
#define MAXL 2100
#define MOD (int)2000000011
using namespace std;
typedef long long llong;
char s[MAXL];
int N,pref_hash[MAXL],pow[MAXL];
const int MUL = 29;

void hash_init(){
     N = strlen(s);

     pref_hash[0] = 0;
     pow[0] = 1;
         for(int i=0;i<N;i++){
            pref_hash[i+1] = (int)(((llong)pref_hash[i]*MUL + s[i]) % MOD);
            pow[i+1] =       (int)((llong)pow[i]*MUL % MOD);
         }

}

int substr_hash(int l,int r){
    int ans = (int)(((llong)pref_hash[l+r] - ((llong)pref_hash[l] * pow[r] % MOD) + MOD) % MOD);
    return ans;
}

void solve(){
   int sol = 0,sz,cur_res;
   for(int i = 1;i <= N;i++){
      if(i*(N-i+1) < sol) continue;

         vector<int> vt;
       for(int j=0;j<(N-i+1);j++) vt.push_back(substr_hash(j,i));
       sort(vt.begin(),vt.end());
       sz = vt.size();
       cur_res = 0;

       for(int j=0;j<sz;j++){
          if(j == 0 || vt[j-1] != vt[j]) cur_res = 0;
         // printf("%d\n",cur_res);

          ++cur_res;
          sol = max(sol,cur_res*i);
        }
    }
    printf("%d\n", sol);
}



int main(){

  while(scanf("%s",s) == 1){
       hash_init();
       solve();
   }
    return 0;
}
