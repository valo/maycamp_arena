#include <cstdio>
#include <string.h>
#include <vector>
using namespace std;
int M;

int main(){
    int v = 2;
      while(scanf("%d",&M) == 1){
          while(M % v != 0) v++;
          printf("%d %d\n",v,M/v);
      }



    return 0;
}
