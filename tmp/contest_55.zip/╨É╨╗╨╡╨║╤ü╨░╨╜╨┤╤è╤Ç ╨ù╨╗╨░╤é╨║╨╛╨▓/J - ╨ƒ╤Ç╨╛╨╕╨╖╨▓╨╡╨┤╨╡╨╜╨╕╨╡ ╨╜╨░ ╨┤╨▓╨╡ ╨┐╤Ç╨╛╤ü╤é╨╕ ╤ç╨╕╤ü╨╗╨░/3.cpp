#include <cstdio>
#include <string.h>
#include <vector>
using namespace std;
int M;
bool prime[50002];
vector<int> primes;

void sieve(){
     int i,j;
     prime[1] = 0;
       for(i=2;i*i<=50000;i++)
           if(prime[i]){
             primes.push_back(i);
             for(j = i*i;j<=50000; j += i)
                prime[j] = false;

           }
}

bool isPrime(int n){
     for(int i=0;i < primes.size() && primes[i] * primes[i] <= n;i++)
        if(n % primes[i] == 0) return false;
        return true;
}

void solve(){
     int A,B,i;

       for(i = 0;i < primes.size() && primes[i] < M ;i++)
           if(M % primes[i] == 0 && isPrime(M / primes[i])){
               A = primes[i];
               B = M / primes[i];
               break;
           }
    printf("%d %d\n",A,B);
}

int main(){
    memset(prime,1,sizeof(prime));
    sieve();

    while(scanf("%d",&M) == 1)
          solve();






    return 0;
}
