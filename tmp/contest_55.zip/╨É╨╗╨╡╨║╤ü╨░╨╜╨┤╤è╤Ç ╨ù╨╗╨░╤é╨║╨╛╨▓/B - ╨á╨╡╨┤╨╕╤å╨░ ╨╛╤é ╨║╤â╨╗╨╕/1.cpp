#include <cstdio>
#define MAX 40005
int N,inter[4*MAX][2],el[MAX],ans,lmax,minel,mini,qb,qe,l,r;

//int min(int a,int b){return a < b ? a : b;}
int main(){
  int T,i;
    scanf("%d",&T);
      while(T--){
          scanf("%d",&N);
            for(i=1;i<=N;i++) scanf("%d",el + i);
            qb = 0;qe = 1; inter[0][0] = 1; inter[0][1] = N;
               while(qb < qe){
                   l = inter[qb][0];
                   r = inter[qb][1];
                   ++qb;
                   minel = el[l];
                   mini = l;
                     for(i = l+1;i<=r;i++)
                         if(el[i] < minel){minel = el[i],mini = i;}

                         // printf("%d %d   %d %d\n",l,r,mini,minel);

                          lmax = (r-l+1)*minel;
                           if(lmax > ans) ans = lmax;
                           if(l >= r) continue;

                        if(mini == l){inter[qe][0] = l+1; inter[qe][1] = r;        qe++;}
                   else if(mini == r){inter[qe][0] = l;   inter[qe][1] = r-1;      qe++;}
                   else {             inter[qe][0] = l;   inter[qe][1] = mini - 1; qe++;
                                      inter[qe][0] = mini + 1; inter[qe][1] = r;   qe++;}


               }
            printf("%d\n",ans);
      }
    return 0;
}
