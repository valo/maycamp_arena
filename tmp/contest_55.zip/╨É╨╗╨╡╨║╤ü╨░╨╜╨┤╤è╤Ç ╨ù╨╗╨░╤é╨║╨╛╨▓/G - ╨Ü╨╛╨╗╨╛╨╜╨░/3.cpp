#include <cstdio>
#include <string.h>
int N,F[103][5];

inline void init(){
          F[1][1] = 1;
          F[2][2] = 1;
          F[3][1] = 1;
          F[3][2] = 1;
          F[3][3] = 1;
}

int main(){
  int T,i;
    scanf("%d",&T);
      while(T--){
          memset(F,0,sizeof(F));
          init();
          scanf("%d",&N);

          for(int i=4;i<=N;i++){
           F[i][1] = F[i-1][2] + F[i-1][3];
           F[i][2] = F[i-2][1] + F[i-2][3];
           F[i][3] = F[i-3][1] + F[i-3][2];
          }

          printf("%d\n",F[N][1] + F[N][2] + F[N][3]);
      }

    return 0;
}
