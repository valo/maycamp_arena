#include <cstdio>
int main(){
   int T;
    int fs,ss,ft,st;
     scanf("%d",&T);
       while(T--){
           scanf("%d%d%d%d",&fs,&ss,&ft,&st);
           printf("%d\n",ft < st ? fs : ss);

       }



    return 0;
}
