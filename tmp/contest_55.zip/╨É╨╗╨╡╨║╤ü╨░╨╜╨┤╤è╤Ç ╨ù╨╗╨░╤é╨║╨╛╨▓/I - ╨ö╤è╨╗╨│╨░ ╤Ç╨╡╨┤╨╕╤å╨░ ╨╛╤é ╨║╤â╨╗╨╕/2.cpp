#include <cstdio>
#include <string.h>
#define MAX 1000001
#define MAXT 1048576
using namespace std;
typedef long long llong;
int el[MAX],tree[2*MAXT],que[MAX][2],N,qb,qe,l,r,mini,minel;
llong rans;

void init_rmq(){
    int l = N + MAXT,i;
    memset(tree,0,sizeof(tree));
    for(i=MAXT;i<l;i++) tree[i] = i - 1048576;
    for(i=MAXT-1;i>0;i--){
          if(el[tree[2*i]] < el[tree[2*i+1]])
                tree[i] = tree[2*i];

          else  tree[i] = tree[2*i+1];
    }
}

int pair_min(int a,int a1,int b,int b1){return a1 < b1 ? a : b;}
int query(int l,int r){
    l += MAXT;
    r += MAXT;
      int ans = pair_min(tree[l],el[tree[l]],tree[r],el[tree[r]]);
      int lb,rb;

      while(l != r){
        lb = l/2;rb = r/2;
        if(lb == rb) break;

        if(lb * 2 == l) ans = pair_min(ans,el[ans],tree[2*lb + 1],el[tree[2*lb+1]]);
        if((rb * 2 + 1) == r) ans = pair_min(ans,el[ans],tree[rb*2],el[tree[rb*2]]);
        l = lb;
        r = rb;
      }
  return ans;
}

int main(){

  int T,i,j;
    scanf("%d",&T);
      while(T--){
          rans = 0;

          scanf("%d",&N);
            for(i=0;i<N;i++) scanf("%d",el + i);
            init_rmq();
            qb = 0;qe = 1;que[0][0] = 0;que[0][1] = N-1;

            while(qb < qe){
               l = que[qb][0];
               r = que[qb][1];
               ++qb;
               mini = query(l,r); //printf("%d %d  %d\n",l,r,mini);
               if((llong)el[mini] * (r-l+1) > rans) rans = (llong)el[mini] * (r-l+1);
               if(l >= r) continue;

                    if(mini == l){que[qe][0] = l+1;    que[qe][1] = r;      qe++;}
               else if(mini == r){que[qe][0] = l;      que[qe][1] = r-1;    qe++;}
               else{              que[qe][0] = l;      que[qe][1] = mini-1; qe++;
                                  que[qe][0] = mini+1; que[qe][1] = r;      qe++;}

            }
              printf("%lld\n",rans);
      }



    return 0;
}
