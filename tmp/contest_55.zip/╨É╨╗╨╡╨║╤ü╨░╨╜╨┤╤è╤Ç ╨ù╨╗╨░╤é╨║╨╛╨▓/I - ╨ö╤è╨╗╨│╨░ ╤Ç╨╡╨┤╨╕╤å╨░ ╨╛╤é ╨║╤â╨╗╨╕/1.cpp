#include <cstdio>
#include <string.h>
#define MAX 1000005
int el[MAX],RMQ[MAX][21],que[MAX][2],N,qb,qe,l,r,mini,minel;
long long ans;

int min(int a,int b){return a < b ? a : b;}
void init_rmq(){
     int i,j;
       for(i=0;i<N;i++)
         RMQ[i][0] = i;

         for(j=1;(1<<j) <= N;j++)
           for(i=0;i + (1<<j) < N + 1;i++){
              if(el[RMQ[i][j-1]]< el[RMQ[i + (1<<(j-1))][j-1]])
                   RMQ[i][j] = RMQ[i][j-1];
            else   RMQ[i][j] = RMQ[i + (1<<(j-1))][j-1];
           }
}

int query(int l,int r){
    int len = r - l + 1,st=0;
    while((1<<st)<len) st++;
    if((1<<st) > len)  st--;

    if(el[RMQ[l][st]] < el[RMQ[r-(1<<st)+1][st]])
          return RMQ[l][st];
          return RMQ[r-(1<<st)+1][st];
}

int main(){

  int T,i,j;
    scanf("%d",&T);
      while(T--){
          ans = 0;
          scanf("%d",&N);
            for(i=0;i<N;i++) scanf("%d",el + i);
            init_rmq();
            qb = 0;qe = 1;que[0][0] = 0;que[0][1] = N-1;

            while(qb < qe){
               l = que[qb][0];
               r = que[qb][1];
               ++qb;
               mini = query(l,r);
               if(el[mini] * (r-l+1) > ans) ans = el[mini] * (r-l+1);
               if(l >= r) continue;

                    if(mini == l){que[qe][0] = l+1;    que[qe][1] = r;      qe++;}
               else if(mini == r){que[qe][0] = l;      que[qe][1] = r-1;    qe++;}
               else{              que[qe][0] = l;      que[qe][1] = mini-1; qe++;
                                  que[qe][0] = mini+1; que[qe][1] = r;      qe++;}

            }
              printf("%lld\n",ans);
      }



    return 0;
}
