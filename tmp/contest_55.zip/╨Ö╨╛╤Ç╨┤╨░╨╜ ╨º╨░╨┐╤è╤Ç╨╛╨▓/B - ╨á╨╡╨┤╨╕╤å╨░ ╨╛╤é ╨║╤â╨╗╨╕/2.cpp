#include <iostream>
#include <cstring>
using namespace std;

int n;
int a[40020];
int ne[40020];
int pr[40020];
int st[40020];
int sti;

int main()
{
    int i, j, k;
    int T, t;
    int bsol;
    scanf( "%d", &T );
    for ( t = 1; t <= T; t++ )
    {
        scanf( "%d", &n );
        for ( i = 1; i <= n; i++ )
            scanf( "%d", &a[i] );

        sti = 0;
        for ( i = n; i > 0; i-- )
        {
            j = 1;
            while ( ( sti > 0 ) && ( a[i] < st[sti] ) )
            {
                j = j + ne[st[sti]];
//                cout << "PL " << i << " " << st[sti] << " " << ne[st[sti]] << endl;
                sti--;
            }
            ne[a[i]] = j;
//            cout << i << " " << a[i] << " " << ne[a[i]] << endl;
            sti++;
            st[sti] = a[i];
//            cout << i << " " << ne[i] << " " << sti << " " << st[sti] << " " << a[i] << " " << st[sti-1] << endl;
        }

        sti = 0;
        for ( i = 1; i <= n; i++ )
        {
            j = 1;
            while ( ( sti > 0 ) && ( a[i] < st[sti] ) )
            {
                j = j + pr[st[sti]];
//                cout << "PPL " << i << " " << st[sti] << " " << pr[st[sti]] << endl;
                sti--;
            }
            pr[a[i]] = j;
//            cout << "PR " << i << " " << a[i] << " " << pr[a[i]] << endl;
            sti++;
            st[sti] = a[i];
        }

        bsol = -1;
        for ( i = 1; i <= n; i++ )
        {
//            cout << i << " " << ne[i] << " " << pr[i] << endl;
            bsol = max( bsol, ( ne[i] + pr[i] -1 ) * i );
        }
        printf( "%d\n", bsol );
    }
    return 0;
}
