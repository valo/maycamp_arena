#include <iostream>
#include <cstring>
using namespace std;

int n;
int a[40020];
int ne[40020];
int st[40020];
int sti;

int main()
{
    int i, j, k;
    int T, t;
    int bsol;
    scanf( "%d", &T );
    for ( t = 1; t <= T; t++ )
    {
        scanf( "%d", &n );
        for ( i = 1; i <= n; i++ )
            scanf( "%d", &a[i] );

        sti = 0;
        for ( i = n; i > 0; i-- )
        {
            j = 1;
            while ( ( sti > 0 ) && ( a[i] < st[sti] ) )
            {
                j = j + ne[st[sti]];
                sti--;
            }
            ne[i] = j;
            sti++;
            st[sti] = j;
        }

        bsol = -1;
        for ( i = 1; i <= n; i++ )
        {
            k = a[i];
            for ( j = i; j <= n; j = j + ne[j] )
            {
                k = min( k, a[j] );
                bsol = max( bsol, k * (j-i+1) );
            }
        }
        printf( "%d\n", bsol );
    }
    return 0;
}
