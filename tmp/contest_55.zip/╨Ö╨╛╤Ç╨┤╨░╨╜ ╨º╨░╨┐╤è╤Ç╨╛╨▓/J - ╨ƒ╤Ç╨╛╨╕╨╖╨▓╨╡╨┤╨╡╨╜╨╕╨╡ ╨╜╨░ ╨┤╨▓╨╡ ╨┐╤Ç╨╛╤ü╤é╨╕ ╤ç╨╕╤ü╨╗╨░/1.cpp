#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;

int del( int x )
{
    double sq = sqrt( x );
    for ( int i = 2; i <= sq; i++ )
    {
        if ( x % i == 0 )
            return i;
    }
    return -1;
}

int main()
{
    int i, x;

    while( scanf( "%d", &x ) == 1 )
    {
        i = del( x );
        printf( "%d %d\n", i, x/i );
    }
    return 0;
}
