#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
using namespace std;

struct el
{
    int nr[2], po;

    bool operator<( const el& x ) const
    {
        if ( nr[0] == x.nr[0] )
            return nr[1] < x.nr[1];
        return nr[0] < x.nr[0];
    }
};

int n;
int p[20][2048];
int lcp[2048];
char s[2048];
el L[2048];

int main()
{
    int i, j, k;
    int be;

    while ( scanf( "%s", s ) == 1 )
    {
        n = strlen( s );
        for ( i = 0; i < n; i++ )
            p[0][i] = s[i] - 'a';
        for ( k = 1, j = 1; k < n; j++, k = k * 2 )
        {
            for ( i = 0; i < n; i++ )
            {
                L[i].nr[0] = p[j-1][i];
                if ( i + k < n )
                    L[i].nr[1] = p[j-1][i+k];
                else
                    L[i].nr[1] = -1;
                L[i].po = i;
            }
            sort( L, L + n );
            for ( i = 0; i < n; i++ )
            {
                p[j][L[i].po] = i > 0 && L[i].nr[0] == L[i - 1].nr[0] && L[i].nr[1] == L[i - 1].nr[1] ? p[j][L[i - 1].po] : i;
            }
        }
        for ( i = 0; i <= n-2; i++ )
        {
            lcp[i] = 0;
            j = 0;
            while ( s[L[i].po+j] == s[L[i+1].po+j] )
            {
                lcp[i]++;
                j++;
                if ( L[i].po+j >= n )
                    break;
                if ( L[i+1].po+j >= n )
                    break;
            }
        }

        be = n;
        for ( i = 0; i < n; i++ )
        {
            k = n - L[i].po;
            be = max( be, k );
            for ( j = i; j < n-1; j++ )
            {
                k = min( k, lcp[j] );
                be = max( be, k * (j-i+2) );
            }
        }
        printf( "%d\n", be );
    }
    return 0;
}
