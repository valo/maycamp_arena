#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;

struct point
{
    double x, y;
};

double area( point O, point A, point B )
{
    return abs( (A.x-O.x)*(B.y-O.y) - (A.y-O.y)*(B.x-O.x) )/2;
}

int main()
{
    int i, j, k;
    point a, b, c;

    while ( scanf( "%lf %lf %lf %lf %lf %lf", &a.x, &a.y, &b.x, &b.y, &c.x, &c.y ) == 6 )
    {
//        cout << area( a, b, c ) << " " << area( a, b, c )*4/3 << endl;
        k = (int)( area( a, b, c )*4.0/3.0 + 0.5 );
        printf( "%d\n", k );
    }
    return 0;
}
