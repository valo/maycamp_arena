#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;

struct point
{
    double x, y;
};

double area( point O, point A, point B )
{
    return abs( (A.x-O.x)*(B.y-O.y) - (A.y-O.y)*(B.x-O.x) )/2;
}

int n;
double A, B, C;
double co[8][8];
int us[8];

int main()
{
    int i, j, k, l;
    point a, b, c, d;

    while ( scanf( "%lf %lf %lf %lf %lf %lf", &a.x, &a.y, &b.x, &b.y, &c.x, &c.y ) == 6 )
    {
        n = 3;
        co[1][3] = -a.y;
        co[1][2] = 1;
        co[1][1] = a.x;
        co[1][0] = a.x*a.x;

        co[2][3] = -b.y;
        co[2][2] = 1;
        co[2][1] = b.x;
        co[2][0] = b.x*b.x;

        co[3][3] = -c.y;
        co[3][2] = 1;
        co[3][1] = c.x;
        co[3][0] = c.x*c.x;

        memset( us, 0, sizeof( us ) );

        for ( i = 2; i >= 0; i-- )
        {
            for ( j = 1; j <= n; j++ )
            {
                if ( ( co[j][i] != 0 ) && ( us[j] == 0 ) )
                {
                    us[j] = 1;
                    break;
                }
            }

            co[0][0] = co[j][i];
            for ( k = 0; k <= 3; k++ )
            {
                co[j][k] = co[j][k] / co[0][0];
            }
            for ( l = 1; l <= n; l++ )
            {
                co[0][1] = co[l][i];
                if ( l != j )
                {
                    for ( k = 0; k <= n; k++ )
                    {
                        co[l][k] = co[l][k] - co[j][k]*co[0][1];
                    }
                }
            }
        }

        A = co[3][3];
        B = co[2][3];
        C = co[1][3];

        d.x = (a.x + c.x)/2;
        d.y = - ( A*d.x*d.x + B*d.x + C );

        printf( "%d\n", (int)( area( a, c, d )*4.0/3.0 + 0.5 ) );
    }
    return 0;
}
