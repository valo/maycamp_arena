#include <iostream>
#include <cstring>
#include <set>
#include <algorithm>
using namespace std;

struct point
{
    int x, y;
    int on;
    bool operator<( const point& p )const
    {
        if ( y == p.y )
            return x < p.x;
        return y < p.y;
    }
};

bool cmp( point a, point b )
{
    if ( a.x == b.x )
        return a.y < b.y;
    return a.x < b.x;
}

int n;
point p[50020];
int sol[50020];

int it[100020];

void addtotr( int p, int x )
{
    for ( int i = p; i <= 100020; i = i + (i&(-i)) )
        it[i] = it[i] + x;
}

int getS( int p )
{
    int sm = 0;
    for ( int i = p; i > 0; i = (i&(i-1)) )
        sm = sm + it[i];
    return sm;
}

int main()
{
    int i, j, k;
    int T, t;

    scanf( "%d", &T );
    for ( t = 1; t <= T; t++ )
    {
        memset( it, 0, sizeof( it ) );
        scanf( "%d", &n );
        for ( i = 1; i <= n; i++ )
        {
            scanf( "%d %d", &p[i].x, &p[i].y );
            p[i].on = i;
        }

        sort( p + 1, p + n + 1, cmp );

        for ( i = 1; i <= n; i++ )
        {
            sol[p[i].on] = getS( p[i].y );
            addtotr( p[i].y, 1 );
        }
        for ( i = 1; i <= n; i++ )
            printf( "%d\n", sol[i] );
    }
    return 0;
}
