#include <iostream>
#include <cstring>
using namespace std;

int n;
long long dp[128][4];

long long getDP( int h, int tp )
{
    if ( dp[h][tp] != -1 )
        return dp[h][tp];

    long long sol = 0;
    int i;
    if ( h == tp )
        sol = 1;
    else
    {
        for ( i = 1; i <= 3; i++ )
        {
            if ( ( h >= tp ) && ( i != tp ) )
            {
               sol = sol + getDP( h-tp, i );
            }
        }
    }

    dp[h][tp] = sol;
    return dp[h][tp];
}

int main()
{
    int i, j, k;
    int T, t;
    scanf( "%d", &T );
    for ( t = 1; t <= T; t++ )
    {
        scanf( "%d", &n );
        memset( dp, -1, sizeof( dp ) );
        dp[0][0] = 1;
        dp[0][1] = 1;
        dp[0][2] = 1;
        dp[0][3] = 1;
        printf( "%lld\n", getDP( n, 1 ) + getDP( n, 2 ) + getDP( n, 3 ) );
    }
    return 0;
}
