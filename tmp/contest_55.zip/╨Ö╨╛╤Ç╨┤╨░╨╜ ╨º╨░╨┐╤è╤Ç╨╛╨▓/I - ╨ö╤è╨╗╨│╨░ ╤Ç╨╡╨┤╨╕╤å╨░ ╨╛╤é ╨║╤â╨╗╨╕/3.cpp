#include <iostream>
#include <cstring>
using namespace std;

int n;
int a[1000020];
long long ne[1000020];
long long pr[1000020];
int st[1000020];
int sti;

int main()
{
    int i, j, k;
    int T, t;
    long long bsol;
    scanf( "%d", &T );
    for ( t = 1; t <= T; t++ )
    {
        scanf( "%d", &n );
        for ( i = 1; i <= n; i++ )
            scanf( "%d", &a[i] );

        sti = 0;
        for ( i = n; i > 0; i-- )
        {
            j = 1;
            while ( ( sti > 0 ) && ( a[i] < st[sti] ) )
            {
                j = j + ne[st[sti]];
                sti--;
            }
            ne[a[i]] = j;
            sti++;
            st[sti] = a[i];
        }

        sti = 0;
        for ( i = 1; i <= n; i++ )
        {
            j = 1;
            while ( ( sti > 0 ) && ( a[i] < st[sti] ) )
            {
                j = j + pr[st[sti]];
                sti--;
            }
            pr[a[i]] = j;
            sti++;
            st[sti] = a[i];
        }

        bsol = -1;
        for ( i = 1; i <= n; i++ )
        {
            bsol = max( bsol, (long long) ( ne[i] + pr[i] -1 ) * (long long)i );
        }
        printf( "%lld\n", bsol );
    }
    return 0;
}
