#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;

int n, m, t1, t2;

int main()
{
    int i, j, k;
    int T, t;
    scanf( "%d", &T );
    for ( t = 1; t <= T; t++ )
    {
        scanf( "%d %d %d %d", &n, &m, &t1, &t2 );
        if ( t1 <= t2 )
            printf( "%d\n", n );
        else printf( "%d\n", m );
    }
    return 0;
}
