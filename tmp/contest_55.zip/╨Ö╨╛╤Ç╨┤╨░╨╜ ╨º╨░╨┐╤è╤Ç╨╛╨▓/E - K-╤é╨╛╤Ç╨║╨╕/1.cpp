#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;

int n, k;
long long dp[64][64];
int b[64][64];

long long getDP( int x, int y )
{
    if ( dp[x][y] != -1 )
        return dp[x][y];
    long long sol = 0;
    int i, j;
    for ( i = 1; i <= b[x][0]; i++ )
    {
        if ( b[x][i] <= y )
        {
            sol = sol + getDP( x-1, y-b[x][i] );
        }
    }
    dp[x][y] = sol;
    return dp[x][y];
}

int main()
{
    int i, j, l;
    int T, t;
    scanf( "%d", &T );
    for ( t = 1; t <= T; t++ )
    {
        scanf( "%d %d", &n, &k );
        for ( i = 1; i <= n; i++ )
        {
            scanf( "%d", &b[i][0] );
            for ( j = 1; j <= b[i][0]; j++ )
            {
                scanf( "%d", &b[i][j] );
                for ( l = 1; l < j; l++ )
                {
                    if ( b[i][j] == b[i][l] )
                    {
                        j--;
                        b[i][0]--;
                        break;
                    }
                }
            }
        }

        memset( dp, -1, sizeof( dp ) );
        dp[0][0] = 1;
        printf( "%lld\n", getDP( n, k ) );
    }
    return 0;
}
