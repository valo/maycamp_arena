#include <iostream>
#include <string>
#include <map>
#include <utility>
#include <cassert>
#include <cstring>
#include <queue>
//#include <tr1/unordered_set>
#include <vector>
using namespace std;
//using namespace std::tr1;

#define DEB(x) cerr << #x << ":" << x << " \t\tat" << __LINE__ << "\n";
#define REP(i, n) for(int i = 0; i < int(n); ++i)

string s;

namespace slow {

	int C;
	char m[2048][2048];
	
	int best;
	
	void slowSolve(int r, int c, int si) {
		int price = (r+1)+C;
		if(price >= best) {
			return;
		}
		if(si == s.size()) {
			if(price < best) {
				//cerr << "Found solution with " << r+1 << " rows and " << C << " cols (" << price << ")\n";
				best = price;
/*				for(int ri = 0; ri <= r; ++ri){
					
					for(int c = 0; c < C; ++c){
						cerr << m[ri][c];
					}
					cerr << "\n";
				}*/
			}
		}
		else {
			if(c == C) {
				++r;
				c = 0;
			}
			//try to put
			if(r == 0 || m[r-1][c] == ' ' || m[r-1][c] == s[si]) {
				m[r][c] = s[si];
				slowSolve(r, c+1, si+1);
			}
			//try to skip
			m[r][c] = ' ';
			slowSolve(r, c+1, si);
		}
	}

	int solve() {
		best = s.size()+2;
		//DEB(s.size());
	//what would be the greedy... gc * (gc / 2 )
		for(int gc = 1; gc <= s.size(); ++gc){
		//we would need nr full rows
			int nr = (s.size() + gc -1) / gc;
			best = min(best, gc + 2*nr - 1);
		//DEB(gc); DEB(best);
		}
		++best;
		for(C = 1; C <= s.size(); ++C){
	//for(C = s.size(); C >= 1; --C) {
			slowSolve(0, 0, 0);
		}
		return 2*best;
		//cerr << "done.\n";
	}
	
	

/*
	
	18
	14
	12
	18
	16
	10
	
*/
}

const int INF = 1023456789;


namespace fast {

	int C;
	
	
	const int MAXC = 20;
	const int MAXL = 81;
	const int MEML = MAXL *(1 << MAXC);
	//map<pair<string, int>, int> mem;
	int mem[MEML];
	
	// the current front... optimized parameter
	char frontMem[1024*1024];
	int fi;
	//how many extra (including the current) cells are needed
	int cellsFor(int key, char* front, int si) {
		//int key = si * (1 << C);
		//REP(i, C) if(front[i] != ' ') key |= 1 << i;
		int& res = mem[key + si * (1 << C)];
		if(res != -1) {
			if(res == INF) {
				DEB(s);
				DEB(front);
				DEB(si);
				assert(false);
			}
			
			return res;
		}
		//pair<string, int> key = make_pair(front, si);
		//if(mem.count(key) > 0) {
		//	return mem[key];
		//}
		
		res = INF;
		// we are done
		if(si == s.size()) {
			res = 0;
			//DEB(front);
			//DEB(si);
			//throw 5;
		}
		else {
			//there is not need to leave blank if the whole front is blank
		
			try{
			bool empty = (key == 0);
			//REP(i, C) if(front[i] != ' ') {empty = false; break;}
			if(front[0] == ' ' || front[0] == s[si]) {
				//string newFront = front.substr(1, C-1) + s[si];
				int newKey = key << 1 & ~(1 << C) | 1;
				front[C] = s[si];
				//DEB(front.size());
				//DEB(front);
				res = min(res, 1 + cellsFor(newKey, front+1, si+1));
			}
			if(!empty) {
				//leave blank
				front[C] = ' ';
				int newKey = key << 1 & ~(1 << C) | 0;
				res = min(res, 1 + cellsFor(newKey, front+1, si));
			}
			if(res == INF) {
				DEB(s);
				DEB(s[si]);
				DEB(front);
				DEB(front[0]);
				DEB(empty);
			}
			}
			catch(int) {
				DEB(front);
				DEB(si);
				throw 5;
			}
		}
		return res;
	}
	
	int solve() {
		int res = INF;
		//DEB(s);
		for(C = 1; C < MAXC; ++C) {
			//mem.clear();
			//REP(i, (1 << C)*s.size()) mem[i] = -1;
			memset(mem, -1, 4*(1 << C)*s.size());
			REP(i, C) frontMem[i] = ' ';
			//string front(C, ' ');
			int l = cellsFor(0, frontMem, 0);
			//DEB(l);
			int R = (l + C - 1) / C;
			int P = 2*(R+C);
			//DEB(R);
			//DEB(C);
			//DEB(P);
			res = min(res, P);
		}
		return res;
	}
	
	
}



namespace bfs {

	int bitMem[1 << 16];
	int bitCount(int bits) {
		return bitMem[bits >> 16] + bitMem[bits & 0xffff];
	}
	
	void initBitCount() {
		REP(i, 1 << 16) {
			bitMem[i] = 0;
			REP(j, 16) if(i & (1 << j)) ++bitMem[i];
		}
		DEB(bitCount(5));
		DEB(bitCount(15));
		DEB(bitCount(13));
		DEB(bitCount(65535));
		DEB(bitCount(65536));
		DEB(bitCount(65537));
	}
	
	int C;
	
	int encode(int si, int key) {
		//assert(key < (1 << C));
		//assert(key >= 0);
		//assert(si <= s.size());
		//assert(si >= 0);
		return si << C | key;
	}
	
	void decode(int x, int& si, int& key) {
		//DEB(x);
		si = x >> C;
		key = x & ((1 << C) - 1);
		//assert(key < (1 << C));
		//assert(key >= 0);
		//assert(si <= s.size());
		//assert(si >= 0);
	}
	
	int solveWidth(int maxRows) {
		//DEB(C);
		vector<int> next, t;
		//unordered_set<int> passed;
		vector<bool> passed((s.size()+1) * (1<<C), false);
		next.push_back(encode(0, 0));
		for(int dist = 0; dist <= maxRows*C; ++dist) {
			//DEB(dist);
			REP(i, next.size()) {
				int x = next[i];
				//DEB(x);
				
				//if(passed.count(x)) continue;
				//passed.insert(x);
				if(passed[x]) continue;
				passed[x] = true;
				int key, si;
				decode(x, si, key);
				if(dist + s.size() - si > maxRows*C) continue;
				//assert(x == encode(si, key));
				//DEB(key);
				//DEB(si);
				
				if(si == s.size()) return (dist + C - 1) / C;
				//DEB(si);
				char pc = (key & 1) ? s[si - bitCount(key)] : ' ';
				if(pc == ' ' || s[si] == pc) {
					int newKey = (key >> 1) | (1 << (C-1));
					//assert(newKey < (1 << C));
					
					//assert(nx > 0);
					int nx = encode(si+1, newKey);
					if(!passed[nx]) t.push_back(nx);
					//DEB(((si + 1) << C | newKey));
				}
				int newKey = key >> 1;
				//assert(newKey < (1 << C));
				//DEB(newKey);
				//DEB(key);
				//DEB(nx);
				//assert(nx > 0);
				int nx = encode(si, newKey);
				if(!passed[nx]) t.push_back(nx);
				//DEB(((si + 1) << C | newKey));
			}
			swap(next, t);
			t.clear();
		}
		return INF;
	}
	
	const int MAXC = 21;
	const int MAXL = 81;

	
	int solve() {
		
		assert(s.size() < MAXL);
		int res = 1234;
		//DEB(s);
		
		for(C = 1; C < MAXC; ++C) {
			//if(C != 4) continue;
			int r = solveWidth(res / 2 - C);
			int P = 2*(r+C);
			res = min(res, P);
			//DEB(C);
			//DEB(res);
		}
		return res;
	}

	int main() {
		initBitCount();
		
		while(cin >> s) {
			DEB(s);
			
			//if(s != "0101010011100101") continue;
		//cout << slow::solve();
			int r = solve();
			//DEB(r);
			cout << r << "\n";
			//int fr = fast::solve();
			//DEB(fr);
//			assert(r == fast::solve());
			if(s.size() < 20) {
				DEB(slow::solve());
				//assert(r == slow::solve());
			}
		}

		return 0;
	}	


}



int main() {
	return bfs::main();
	while(cin >> s) {
		//if(s != "12") continue;
		//cout << slow::solve();
		int r = fast::solve();
		cout << r << "\n";
		if(s.size() < 20) {
			//DEB(slow::solve());
			//assert(r == slow::solve());
		}
	}

	return 0;
}	

