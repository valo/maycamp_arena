#include<iostream>
using namespace std;
#include <stdlib.h>
#include <time.h>
#define MAXN 1000001

int N, m[MAXN][2];
struct {int l,r; } stack[MAXN];
struct {int val,b,e,lson,rson; } node[MAXN];
long long maxi,a,h;

void input()
{
   int i;
   cin>>N;
   for(i=1;i<=N;i++) {cin>>m[i][0];m[i][1]=i;}      
}


void swap(int i,int j)
{
   int t;
   t=m[i][0];m[i][0]=m[j][0];m[j][0]=t;
   t=m[i][1];m[i][1]=m[j][1];m[j][1]=t;     
}

void quickSort()
{
   int i,j,l,r,s,x,q,p=1000;

   srand(time(0));
   stack[s=0].l=1;stack[0].r=N;
   for(;;)
   {
      l=stack[s].l;r=stack[s].r; 
      if(-1 == s--) break;
      do 
      {
         i=l;j=r;
//       q=(rand()%1000)*1000+rand()%1000;x=m[l+q%(r-l+1)][0];
         x=m[(l+r)/2][0];
         do
         {
            while(m[i][0]<x)i++;
            while(m[j][0]>x)j--;
            if(i<=j){swap(i,j);i++;j--;}                                                      
         } while(i<=j);
         if(i<r)
         { stack[++s].l=i;stack[s].r=r;}
         r=j;           
      } while(l<r);     
   }
}

void solve()
{
    int i=1,l=1,r=N,ls,rs;
    int root,cur,free; 
    maxi=(long long)N;root=cur=0;
//cout << "from 1 to "<<N<<" s h=1"<<endl; 
    node[0].val=m[1][1];node[0].b=1;node[0].e=N;
    node[0].lson=1;node[0].rson=2;
    if(m[1][1]==1){node[1].val=-1;node[2].val=0;node[2].b=2;node[2].e=N;}
    else if(m[1][1]==N){node[2].val=-1;node[1].val=0;node[1].b=1;node[1].e=N-1;}
         else{ node[1].val=0;node[1].b=1;node[1].e=m[1][1]-1;
               node[2].val=0;node[2].b=m[1][1]+1;node[2].e=N;}
    free=3;i++;
    while(i<=N)
    {  int cur=root;
       while(node[cur].val>0)
          if(m[i][1]<node[cur].val)cur=node[cur].lson;
          else cur=node[cur].rson;
       // v cur e varhat s intervala za koyto i e min
       l=node[cur].b;r=node[cur].e;
//cout<<l<<" "<<r<<endl;          
       a=(long long)(r-l+1);h=a*(long long)i;
//cout << "from "<<l<<" to "<<r<<" s h="<<i<<endl; 
       if(h>maxi) maxi=h; node[cur].val=m[i][1];
       if(m[i][1]==l){node[cur].val=0;node[cur].b=l+1;node[cur].e=r;}
       else if(m[i][1]==r){node[cur].val=0;node[cur].b=l;node[cur].e=r-1;}
            else{ ls=node[cur].lson=free++;rs=node[cur].rson=free++;
                  node[ls].val=0;node[ls].b=l;node[ls].e=m[i][1]-1;
                  node[rs].val=0;node[rs].b=m[i][1]+1;node[rs].e=r;}
       i++;
    }   
}

int main()
{
    int t,T,i;
    scanf("%d",&T);
    for(t=1;t<=T;t++)
    {
        input();
        quickSort();
//       for(i=1;i<=N;i++) printf("%d %d\n",m[i][0],m[i][1]); 
        solve();                
        cout<<maxi<<endl;
    }                    
}
