#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cassert>
#include <cstring>
using namespace std;

#define DEB(x) cerr << #x << ":" << x << " \t\tat" << __LINE__ << "\n";
#define REP(i, n) for(int i = 0; i < int(n); ++i)


const int SIZE = 2048;
char s[SIZE];
int N;



typedef int ht; //hash type
typedef long long dht; //can handle ht*MUL
const int MOD = 2000000011;
//typedef int dht;
//const int MOD = 60000011;//30000001;//2000003;
const int P = 29;

ht h[SIZE]; //h[C] - hash of the prefix of len C
ht pows[SIZE];
void InitHash(){
	h[0] = 0;
	pows[0] = 1;
	for(int i = 0; i < N; ++i){
		h[i+1] = (ht)(((dht)h[i] * P + s[i]) % MOD);
		pows[i+1] = (ht)((dht)pows[i]*P % MOD);
		//DEB(i);
		//DEB(pows[i]);
		//DEB(h[i]);
	}
}

// hash of substring starting from p with length l
ht Hash(int p, int l){
	//DEB(p);
	//DEB(l);
	
	ht res = (ht)(((dht)h[p+l] - ((dht)h[p] * pows[l] % MOD) + MOD) % MOD);
	//DEB(res);
	return res;
}


int slowSol() {
	int res = 0;
	REP(b, N) REP(l, N-b+1) {
		int r = 0;
		//int l = e - b;
		REP(t, N-l+1) if(strncmp(s+b, s+t, l) == 0) {
			r += l;
		}
		//DEB(r);
		res = max(res, r);
	}
	return res;
}

int hashSol() {
	InitHash();
	int res = 0;
	for(int w = 1; w <= N; ++w) {
		if(w * (N-w+1) < res) continue; //no hope here :)
		vector<ht> hashes;
		REP(i, N-w+1) hashes.push_back(Hash(i, w));
		sort(hashes.begin(), hashes.end());
		int r = 0;
		REP(i, hashes.size()) {
			if(i == 0 || hashes[i-1] != hashes[i]) r = 0;
			++r;
			res = max(res, r * w);
		}
	}
	return res;
}



int main() {
	while(cin >> s){
		N = strlen(s);
		assert(N <= 2000);
		REP(i, N) assert(s[i] >= 'a' && s[i] <= 'z');
		//cout << slowSol() << "\n";
		int r = hashSol();
		cout << r << "\n";
		if(N < 100) {
			assert(slowSol() == r);
		}
	} 
	return 0;
}
