#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;

int it[131072],n,x,y,sum;
int lol[110000];

struct point
{
	int x,y,ind;
};

point a[110000];

int cmp(point a1, point a2)
{
	if(a1.y < a2.y)return 1;
	if(a1.y == a2.y)
	{
		if(a1.x < a2.x)return 1;
	}
	return 0;
}

void read()
{
	int i;
	point el;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		el.x=x;
		el.y=y;
		el.ind=i;
		a[i]=el;
	}
}	

void update(int pos1)
{
	while(pos1<=131071)
	{
		it[pos1]++;
		pos1+=pos1&(-pos1);
	}
}

void find_sum(int pos2)
{
	sum=0;
	while(pos2>=1)
	{
		sum+=it[pos2];
		pos2-=pos2&(-pos2);
	}
}

void solve()
{
	int i;
	sort(a,a+n,cmp);
	for(i=0;i<n;i++)
	{
		update(a[i].x);
		find_sum(a[i].x);
		lol[a[i].ind]=sum-1;
	}
	for(i=0;i<n;i++)printf("%d\n",lol[i]);
}

int main()
{
	int t,itr;
	scanf("%d",&t);
	for(itr=0;itr<t;itr++)
	{
		read();
		solve();
		memset(it,0,sizeof(it));
		memset(a,0,sizeof(a));
		memset(lol,0,sizeof(lol));
	}
	return 0;
}
