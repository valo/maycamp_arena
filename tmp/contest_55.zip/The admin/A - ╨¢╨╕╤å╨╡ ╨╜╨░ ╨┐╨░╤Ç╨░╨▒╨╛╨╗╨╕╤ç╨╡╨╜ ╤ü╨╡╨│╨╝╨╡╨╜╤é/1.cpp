// NCPC-2008; Kapralov

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{ double x1,y1,x2,y2,x3,y3;
  double a1,a2,a3,b1,b2,b3,c1,c2,c3,k,n;
  double a,b,c,s;
  
  cin >> x1 >> y1 >> x2 >> y2 >> x3 >> y3;
  
  while(cin.good())
  { a1 = y1 /((x1-x2)*(x1-x3));
    a2 = y2 /((x2-x1)*(x2-x3));
    a3 = y3 /((x3-x1)*(x3-x2));
    
    b1 = -(x2+x3)*a1;
    b2 = -(x1+x3)*a2;
    b3 = -(x1+x2)*a3;
    
    c1 = x2*x3*a1;
    c2 = x1*x3*a2;
    c3 = x1*x2*a3;
    
    k = (y3-y1)/(x3-x1);
    n = (x3*y1-x1*y3)/(x3-x1);

    a = a1 + a2 + a3;
    b = b1 + b2 + b3 - k;
    c = c1 + c2 + c3 - n;
    
    s = (a*x3*x3*x3/3 + b*x3*x3/2 + c*x3) - (a*x1*x1*x1/3 + b*x1*x1/2 + c*x1);
    if(s < 0) s = -s; 
  
    //cout << fixed << setprecision(0) << s << endl;
    cout << int(s + 0.5) << endl;
    
    cin >> x1 >> y1 >> x2 >> y2 >> x3 >> y3;
  }  
  
  return 0;
}

    

      
