#include<iostream>
#include <cstring>
using namespace std;
struct kula
{
    long long t1,t2,t3;
};
kula a[128];
int main()
{
   int T, t;
   cin>>T;
   for(t=1;t<=T;t++)
   { 
    	memset(a,0,sizeof(a));
        int n, i;
        cin>>n;
        a[1].t1 = 1;
        a[2].t2 = 1;
        a[3].t1 = 1;
        a[3].t2 = 1;
        a[3].t3 = 1;
        for(i=4;i<=n;i++)
        {
            a[i].t1 = a[i-1].t2 + a[i-1].t3;
            a[i].t2 = a[i-2].t1 + a[i-2].t3;
            a[i].t3 = a[i-3].t1 + a[i-3].t2;
        }
        cout<<a[n].t1+a[n].t2+a[n].t3<<endl;
    }
}
