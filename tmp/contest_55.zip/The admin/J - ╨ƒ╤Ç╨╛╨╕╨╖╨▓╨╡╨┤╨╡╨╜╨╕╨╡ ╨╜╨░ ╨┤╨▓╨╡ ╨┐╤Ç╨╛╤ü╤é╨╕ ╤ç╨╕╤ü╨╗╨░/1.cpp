#include<iostream>
using namespace std;

int main()
{ int a;
  while(cin>>a)
  {
    int d=2;
    while(a%d != 0) d++;
    cout << d << " " << a/d << endl;
  }
}
