#include<iostream>
using namespace std;

const int max_m = 51;
const int max_n = 51;
int m, K;
long long int a[max_m][max_n];
int am[max_m];

long long int q[max_m*max_n];
int qm;
long long int p[max_m*max_n];

int run()
{
  for(int i=0;i<max_m;i++)
  for(int j=0;j<max_n;j++) a[i][j]=0;
  
  for(int i=0;i<max_m*max_n;i++)
   {p[i]=0; q[i]=0;}

  cin >> m;
  cin >> K;
  
  for(int i=1;i<=m;i++)
  { int b; cin >> b;
    int max=0;
    for(int j=1;j<=b;j++)
      {int t; cin >> t;
       if(max<t)max=t;
       a[i][t]=1;
      }
    am[i]=max;
  }

  q[0]=1; qm=0;
  for(int t=1;t<=m;t++)
  {
    for(int k=0;k<=qm+am[t];k++)
    {
     long long int c=0;
     for(int i=0;i<=qm;i++)
     for(int j=0;j<=am[t];j++)
     if(i+j==k) c = c + q[i]*a[t][j];
     p[k]=c;
    }
    for(int k=0;k<=qm+am[t];k++) q[k]=p[k];
    qm=qm+am[t];
  }
  cout << q[K] << "\n";
}

int main()
{
 int k; cin >> k;
 for(int i=1;i<=k;i++) run();
}


