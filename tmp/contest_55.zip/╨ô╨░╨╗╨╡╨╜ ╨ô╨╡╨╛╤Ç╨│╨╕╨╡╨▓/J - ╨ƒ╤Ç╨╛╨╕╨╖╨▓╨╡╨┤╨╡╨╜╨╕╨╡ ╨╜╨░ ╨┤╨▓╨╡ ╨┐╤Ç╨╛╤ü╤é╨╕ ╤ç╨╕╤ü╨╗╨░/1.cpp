#include<iostream>
using namespace std;
int main()
{
    int n,i;
    while(cin>>n)
    {
        for(i=n-1;i>=1;i--)
        if(n%i==0)
        {
            cout<<n/i<<" "<<i<<endl;
            break;
        }
    }
    return 0;
}
