#include<iostream>
using namespace std;
int main()
{
    int i,n,a,b,c,d;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>a>>b>>c>>d;
        if(c<d) cout<<a<<endl;
        else cout<<b<<endl;
    }
    return 0;
}
