#include <iostream>
using namespace std;
long long n;
struct colon
{
    long long  b1,b2,b3;
};
colon a[128];
long long colon_1()
{
    long long i,m;
    a[1].b1=1;
    a[1].b2=0;
    a[1].b3=0;
    a[2].b1=0;
    a[2].b2=1;
    a[2].b3=0;
    a[3].b1=1;
    a[3].b2=1;
    a[3].b3=1;
    for (i=4;i<=n;i++)
    {
        a[i].b1=a[i-1].b2+a[i-1].b3;
        a[i].b2=a[i-2].b1+a[i-2].b3;
        a[i].b3=a[i-3].b1+a[i-3].b2;
    }
    m=a[n].b1+a[n].b2+a[n].b3;
    return m;
}
int main ()
{
    int T,i;
    cin>>T;
    for(i=1;i<=T;i++)
    {
        cin>>n;
        cout<<colon_1()<<endl;
    }
    return 0;
}
