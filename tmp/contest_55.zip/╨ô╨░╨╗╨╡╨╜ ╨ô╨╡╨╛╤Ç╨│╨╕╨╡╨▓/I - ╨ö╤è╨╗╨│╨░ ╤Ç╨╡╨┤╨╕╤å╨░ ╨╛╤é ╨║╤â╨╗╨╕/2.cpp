#include <stdio.h>
#define MAXN 10000001
#define MINT 2000000000
int red[MAXN],N,que[2*MAXN][2];

int main()
{
    int t,T;
    int i,qs,qe,max=0,min,lmax,minp,l,r;
    scanf("%d",&T);
for(t=1;t<=T;t++)
{    
    scanf("%d",&N);
    //input data in red[]
    for(i=1;i<=N;i++) scanf("%d",&red[i]);
    // initialization of queue with [1,N]
    qs=0;qe=1;que[0][0]=1;que[0][1]=N;
    while(qs<qe)
    { l=que[qs][0];r=que[qs][1];qs++;
      min=red[l];minp=l;
      for(i=l+1;i<=r;i++)
         if(red[i]<min){min=red[i];minp=i;}
//      printf("l=%d r=%d minp=%d min=%d\n",l,r,minp,min);   
      lmax=(r-l+1)*min;if(lmax>max)max=lmax;
      if(l==r) continue;
      if(minp==l){que[qe][0]=l+1;que[qe][1]=r;qe++;}
      else
         if(minp==r){que[qe][0]=l;que[qe][1]=r-1;qe++;}
         else
         {que[qe][0]=l;que[qe][1]=minp-1;qe++;
          que[qe][0]=minp+1;que[qe][1]=r;qe++;}  
    }       
    printf("%d\n",max);
}    
}
