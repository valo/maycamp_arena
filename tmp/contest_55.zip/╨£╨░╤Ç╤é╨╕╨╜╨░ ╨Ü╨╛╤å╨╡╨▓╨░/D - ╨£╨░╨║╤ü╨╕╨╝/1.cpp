#include<iostream>
using namespace std;
int t,x,y,z,q;
int main()
{
 cin>>t;
 for(int i=1; i<=t; i++)
 {
  cin>>x>>y>>z>>q;
  if(z<q) cout<<x<<endl;
  else cout<<y<<endl;
 }
// system("pause");
 return 0;
}
