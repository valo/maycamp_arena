#include <iostream>
#include <cmath>
using namespace std;
bool isPrime(int a)
{
     if(a==1) return false;
     if(a==2) return true;
     if(a==3) return true;
     for(int i=2; i<=sqrt(a); i++) 
     if(a%i==0) return false;
     return true;
}
void solve(int n)
{
     for(int i=2; i<=sqrt(n); i++)
     {
             if(n%i==0) if(isPrime(i) && isPrime(n/i)){cout << i << ' ' << n/i << endl; return; }
     }
     return;
}
int main()
{
    int n;
    while(cin >> n)
    {
        solve(n);
    }
    return 0;
}      
