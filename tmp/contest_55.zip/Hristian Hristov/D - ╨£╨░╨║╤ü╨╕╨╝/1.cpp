#include <iostream>
using namespace std;
void solve()
{
     int n,m,a,b;
     cin >> n >> m >> a >> b;
     if(a<b) cout << n << endl;
     else if(a==b) cout << min(n,m) << endl;
     else cout << m << endl;
}
int main()
{
    int tt, t;
    cin >> tt;
    for(t=0; t<tt; t++)
    solve();
    return 0;
}
