#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
#define MAXN 50000

struct player{
       int x, y, num, rez; };
       
player pl[MAXN];
int rez[MAXN];

void Print(int n)
{
     for(int i=0; i<n; i++)
             cout<<pl[i].x<<" "<<pl[i].y<<endl;
}

int main()
{
     int t, n;
     scanf("%d",&t);
     for(int i=1; i<=t; i++)
     {
             scanf("%d",&n);
             memset(rez,0,n+1);
             for(int j=0; j<n; j++)
                     scanf("%d %d",&pl[j].x,&pl[j].y);
             for(int k=0; k<n-1; k++)
                     for(int l=k+1; l<n; l++)
                             if ( pl[k].x <= pl[l].x && pl[k].y <= pl[l].y ) rez[l]++;
                             else if ( pl[k].x >= pl[l].x && pl[k].y >= pl[l].y ) rez[k]++;
             for(int k=0; k<n-1; k++)
                     printf("%d ",rez[k]);
             printf("%d\n",rez[n-1]);
     }
     
     //system("pause");
     return 0;
}
     
     
