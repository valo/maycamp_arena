#include<iostream>
#include<algorithm>
using namespace std;
#define MAXN 50000

struct player{
       int x, y, num, rez; };
       
bool compare(player a, player b)
{
     if ( a.x==b.x ) return ( a.y < b.y );
     else return ( a.x < b.x );
}

bool compare2(player a, player b)
{
     if ( a.y==b.y ) return ( a.x < b.x );
     else return ( a.y < b.y );
}

player pl[MAXN];
player pl2[MAXN];
char set[MAXN/8];
int rez[MAXN];

void Print(int n)
{
     for(int i=0; i<n; i++)
             printf("%d\n",rez[i]);
}

int main()
{
     int t, n;
     scanf("%d",&t);
     for(int i=1; i<=t; i++)
     {
             scanf("%d",&n);
             memset(set,0,n);
             memset(rez,0,n);
             for(int j=0; j<n; j++)
             {
                     scanf("%d %d",&pl[j].x,&pl[j].y);
                     pl[j].num=j;
                     pl2[j]=pl[j];
             }
             
             sort(pl,pl+n,compare);
             sort(pl2,pl2+n,compare2);
             
             int tmp=n;
             for(int k=0; k<n; k++)
             {
                     int tmp2=pl[k].num;
                     int tmp3=pl2[k].num;
                     if ( !set[tmp2] ) { set[tmp2]=1; rez[tmp2]=k; }
                     if ( !set[tmp3] ) { set[tmp3]=1; rez[tmp3]=k; }
             }
                     
             Print(n);
             
     }
     
     //system("pause");
     return 0;
}
     
