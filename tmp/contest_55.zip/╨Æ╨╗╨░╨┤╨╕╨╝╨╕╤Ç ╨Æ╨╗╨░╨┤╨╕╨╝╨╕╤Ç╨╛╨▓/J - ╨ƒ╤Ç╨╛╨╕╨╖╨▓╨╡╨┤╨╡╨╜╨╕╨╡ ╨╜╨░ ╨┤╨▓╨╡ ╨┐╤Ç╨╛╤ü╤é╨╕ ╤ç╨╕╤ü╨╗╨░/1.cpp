#include<iostream>
#include<math.h>
using namespace std;

int main()
{
    int i, a;
    while ( scanf("%d",&a)>0 )
    {
          for(i=2; i<=sqrt(a); i++)
                   if ( a%i==0 ) { printf("%d %d\n",i,a/i); break; }
    }
    
    //system("pause");
    return 0;
}
