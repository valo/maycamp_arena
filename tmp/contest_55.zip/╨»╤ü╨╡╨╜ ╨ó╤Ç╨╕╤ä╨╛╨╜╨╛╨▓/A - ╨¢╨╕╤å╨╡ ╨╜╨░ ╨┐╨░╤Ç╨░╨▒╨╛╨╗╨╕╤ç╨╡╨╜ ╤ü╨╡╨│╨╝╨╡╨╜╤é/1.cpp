#include <cstdio>
#include <cstring>
#include <algorithm>
#include <map>
#include <utility>
#define x first
#define y second
#define MAXN (1 << 16)
#define MAXK (1 << 17)
using namespace std;

typedef pair <pair <int,int>, int> pii;

pii a[MAXN];
int t, n;

int it[MAXK], sol[MAXN];

inline int ask (int x)
{
    int ans = 0;
    for (;x;x = x & (x-1))
        ans += it[x];

    return ans;
}

inline void update (int x)
{
    for (;x < MAXK; x += x&(-x))
        it[x] ++;
}

int main ()
{
    scanf ("%d", &t);

    while (t --)
    {
        memset (it, 0, sizeof (it));
        scanf ("%d", &n);

        for (int i=0; i < n; ++i)
        {
            scanf ("%d%d", &a[i].x.x, &a[i].x.y);
            a[i].y = i+1;
        }

        sort (a, a+n);

        for (int i=0; i < n; ++i)
        {
            sol[ a[i].y ] = ask (a[i].x.y);
            update (a[i].x.y);
        }
        for (int i=1; i <= n; ++i)
            printf ("%d\n", sol[i]);
    }

    return 0;
}
