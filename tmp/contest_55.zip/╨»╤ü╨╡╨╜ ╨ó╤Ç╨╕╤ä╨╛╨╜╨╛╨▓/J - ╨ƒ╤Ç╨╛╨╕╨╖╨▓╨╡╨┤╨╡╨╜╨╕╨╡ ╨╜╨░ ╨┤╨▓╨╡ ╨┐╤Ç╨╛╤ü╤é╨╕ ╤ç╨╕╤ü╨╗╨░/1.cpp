#include <cstdio>
#include <vector>
#define MAXN (1 << 17)
using namespace std;

typedef long long ll;

bool primes[MAXN];
vector<ll> pr;
ll num;

inline void pre ()
{
    primes[0] = primes[1] = 1;
    for (int i=4; i < MAXN; i += 2) primes[i] = 1;

    for (int i=3; i*i < MAXN; i += 2)
        if (!primes[i])
            for (int j=i*i; j < MAXN; j += i)
                primes[j] = 1;

    for (int i=0; i < MAXN; ++i)
        if (!primes[i])
            pr.push_back (i);
}


int main ()
{
    pre ();
    while (scanf ("%lld", &num) == 1)
    {
        for (int idx=0; pr[idx]*pr[idx] <= num; ++idx)
            if (num % pr[idx] == 0)
            {
                printf ("%lld %lld\n", pr[idx], num/pr[idx]);
                break;
            }
    }
    return 0;
}
