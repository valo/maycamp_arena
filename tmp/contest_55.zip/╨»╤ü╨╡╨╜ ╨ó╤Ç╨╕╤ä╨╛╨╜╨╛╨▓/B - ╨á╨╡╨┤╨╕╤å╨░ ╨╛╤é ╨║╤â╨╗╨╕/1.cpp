#include <cstdio>
#include <algorithm>
#include <cstring>
#define MAXN (1 << 16)
using namespace std;

int t, n, sol;
int h[MAXN], uf[MAXN], br[MAXN], pos[MAXN];;

inline int cmp (const int &pos1, const int &pos2)
{
    return h[pos1] > h[pos2];
}

inline int find (int x)
{
    int _x = x, ans, save;

    while (uf[x] != -1)
    {
        x = uf[x];
    }
    ans = x;
    x = _x;
    while (uf[x] != -1)
    {
        save = x;
        x = uf[x];
        uf[save] = ans;
    }
    return ans;
}

int main ()
{
    scanf ("%d" , &t);
    while (t --)
    {
        sol = 0;
        memset (uf, -1, sizeof (uf));

        scanf ("%d" , &n);
        for (int i=0; i < n; ++i)
            scanf ("%d", &h[i]);

        for (int i=0; i < n; ++i)
            br[i] = 1, pos[i] = i;

        sort (pos, pos+n, cmp);
        //printf ("OK");
        //for (int i=0; i < n; ++i)
        //    printf ("%d %d\n", pos[i] , h[pos[i]]);
        for (int i=0; i < n; ++i)
        {
            if (pos[i]-1 >= 0)
                if ( h[pos[i] - 1] > h[pos[i]] )
                {
                    int fat1 = find (pos[i]), fat2 = find (pos[i]-1);
                    // we unite them
                    uf[fat1] = fat2;
                    br[fat2] += br[fat1];
                }
            if (pos[i]+1 < n)
                if ( h[pos[i] + 1] > h[pos[i]] )
                {
                    int fat1 = find (pos[i]), fat2 = find (pos[i]+1);
                    // we unite them
                    uf[fat1] = fat2;
                    br[fat2] += br[fat1];
                }
            int fat = find (pos[i]);
            sol = max (sol , br[fat]*h[pos[i]]);
        }
        printf ("%d\n", sol);
    }
    return 0;
}
