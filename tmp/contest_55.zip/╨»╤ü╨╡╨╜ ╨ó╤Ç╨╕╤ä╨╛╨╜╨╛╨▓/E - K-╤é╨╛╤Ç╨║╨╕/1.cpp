#include <cstdio>
#include <cstring>
#define MAXN (1 << 5)
#define MAXK (1 << 6)
using namespace std;

int t, n, k;
int ndp[MAXK], dp[MAXK], used[MAXK], nused[MAXK];
int a[MAXN][16], br[MAXN];

int main ()
{
    scanf ("%d" , &t);

    while (t --)
    {
        memset (used, 0, sizeof (used));
        memset (dp, 0, sizeof (dp));

        scanf ("%d%d", &n, &k);

        for (int i=0; i < n; ++i)
        {
            scanf ("%d" , &br[i]);
            for (int j=0; j < br[i]; ++j)
                scanf ("%d", &a[i][j]);
        }

        dp[0] = 1;
        used[0] = 1;
        for (int i=0; i < n; ++i)
        {
            for (int j=k; j >= 0; --j)
            {
                if (!used[j]) continue;
                for (int q=0; q < br[i]; ++q)
                {
                    if (j + a[i][q] > k) continue;
                    if (dp[j] > 0)
                    {
                        ndp[j + a[i][q]] += dp[j];
                        nused[j + a[i][q]] = 1;
                    }
                }
            }
            memcpy (dp, ndp, sizeof (ndp));
            memcpy (used, nused, sizeof (nused));
            memset (ndp, 0, sizeof (ndp));
            memset (nused, 0, sizeof (nused));
        }
        printf ("%d\n" , dp[k]);
    }

    return 0;
}
