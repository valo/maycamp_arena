#include<iostream>
using namespace std;
long long n,i,j,max1,br1,br2,ans1,ans2,p,a[46341],b[46341],used[46341];
int main()
{
    br1=1;
    while(cin>>n)
    {
       a[br1]=n;
       br1++;
       max1=max(max1,n);
    }
    br2=1;
    for(i=2;i*i<=max1;i++)
    {
       if (used[i]==0)
       {
          b[br2]=i;
          br2++;
          for(j=i*i;j*j<=max1;j=j+i)
          {
             used[j]=1;
          }
       }
    }
    br1--;
    br2--;
    for(i=1;i<=br1;i++)
    {
       for(j=1;j<=br2;j++)
       {
          if (a[i]%b[j]==0)
          {
             p=a[i]/b[j];
             if (used[p]==0) {ans1=b[j];ans2=p;break;}
          }
       }
       cout<<ans1<<" "<<ans2<<endl;
    }
    //system("pause");
    return 0;
}
    
