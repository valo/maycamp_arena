#include<iostream>
#include<vector>
using namespace std;
long n,m,k,i,j,ij,ij1,ij2,ans;
vector <long> a;
int main()
{
    cin>>n;
    for(i=1;i<=n;i++)
    {
       cin>>m;
       a.clear();
       for(j=1;j<=m;j++)
       {
          cin>>k;
          a.push_back(k);
       }
       for(j=0;j<=m-1;j++)
       {
          for(ij1=j-1;ij1>=0;ij1--)
          {
             if (a[ij1]<a[j]) {break;}
          }
          ij1++;
          for(ij2=j+1;ij2<=m-1;ij2++)
          {
             if (a[ij2]<a[j]) {break;}
          }
          ij2--;
          ij=ij2-ij1+1;
          ans=max(ans,ij*a[j]);
       }
       cout<<ans<<endl;
    }
    //system("pause");
    return 0;
}
          
