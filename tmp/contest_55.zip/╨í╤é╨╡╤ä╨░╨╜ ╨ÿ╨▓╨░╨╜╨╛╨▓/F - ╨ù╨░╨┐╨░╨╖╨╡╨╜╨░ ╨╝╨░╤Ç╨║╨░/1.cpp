#include<iostream>
#include<string>
using namespace std;
long n,i,j,ij,br,ans;
int main()
{
    string s,t,st;
    while(cin>>s)
    {
       n=s.size();
       for(i=n;i>=1;i--)
       {
          ans=0;
          for(j=0;j<=n-i;j++)
          {
             t=s.substr(j,i);
             br=1;
             for(ij=j+1;ij<=n-i;ij++)
             {
                st=s.substr(ij,i);
                if (st==t) {br++;}
             }
             ans=max(ans,br*i);
          }
       }
       cout<<ans<<endl;
    }
    //system("pause");
    return 0;
}
    
