#include<iostream>
using namespace std;
long n,m,i,ans;
long rec (long x, long y)
{
   long br;
   if (x==m) {return 1;}
   if (x>m) {return 0;}
   if (y==0) {return rec(x+1,1)+rec(x+2,2)+rec(x+3,3);}
   if (y==1) {return rec(x+2,2)+rec(x+3,3);}
   if (y==2) {return rec(x+1,1)+rec(x+3,3);}
   if (y==3) {return rec(x+1,1)+rec(x+2,2);}
}
int main()
{
    cin>>n;
    for(i=1;i<=n;i++)
    {
       cin>>m;
       if (m==1 || m==2) {ans=1;}
       else {ans=rec(0,0);}
       cout<<ans<<endl;
    }
    //system("pause");
    return 0;
}
