#include<iostream>
#include<vector>
using namespace std;
vector<int> a, o, zaizhod;
int main()
{
    int t, i;
    cin>>t;
    for(i=0; i<t; i++)
    {
             int n, ab, ord;
             cin>>n;
             for(int j=0; j<n; j++)
             {
                     cin>>ab>>ord;
                     a.push_back(ab);
                     o.push_back(ord);
             }
             for(int tekigrach=0; tekigrach<n; tekigrach++)
             {
                 int br=0;
                 for(int j=0; j<n; j++)
                 {
                     if(tekigrach==j)
                     {
                         continue;
                     }
                     if(a[j]<=a[tekigrach]&&o[j]<=o[tekigrach])
                     {
                         br++;
                     }
                 }
                 zaizhod.push_back(br);
             }
             a.clear();
             o.clear();
    }
    for(i=0; i<zaizhod.size(); i++)
    {
        cout<<zaizhod[i]<<endl;
    }
    return 0;
}
