#include<vector>
#include<cstdio>
using namespace std;
vector<int> a, o, zaizhod;
int main()
{
    int t, i;
    scanf("%d", &t);
    for(i=0; i<t; i++)
    {
             int n, ab, ord;
             scanf("%d", &n);
             for(int j=0; j<n; j++)
             {
                     scanf("%d%d", &ab, &ord);
                     a.push_back(ab);
                     o.push_back(ord);
             }
             for(int tekigrach=0; tekigrach<n; tekigrach++)
             {
                 int br=0;
                 for(int j=0; j<n; j++)
                 {
                     if(tekigrach==j)
                     {
                         continue;
                     }
                     if(a[j]<=a[tekigrach]&&o[j]<=o[tekigrach])
                     {
                         br++;
                     }
                 }
                 zaizhod.push_back(br);
             }
             a.clear();
             o.clear();
    }
    for(i=0; i<zaizhod.size(); i++)
    {
        printf("%d\n", zaizhod[i]);
    }
    return 0;
}
