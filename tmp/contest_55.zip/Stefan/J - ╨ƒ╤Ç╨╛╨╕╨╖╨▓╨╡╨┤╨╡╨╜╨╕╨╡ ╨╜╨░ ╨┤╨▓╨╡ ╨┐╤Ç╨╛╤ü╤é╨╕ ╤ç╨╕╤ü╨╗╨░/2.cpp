#include<iostream>
#include<math.h>
using namespace std;
void find(int m)
{
   long long int end=sqrt(m);
   long long int i, j;
   for(i=2; i<=end; i++)
   {
      if(!(m%i))
      {
         bool aneeprosto=false;
         for(j=2; j<=sqrt(i); j++)
         {
            if(!(i%j))
            {
               aneeprosto=true;
               break;
            }
         }
         if(!aneeprosto)
         {
            bool bneeprosto=false;
            for(int j=2; j<=sqrt(m/i); j++)
            {
               if(!((m/i)%j))
               {
                  bneeprosto=true;
                  break;
               }
            }
            if(!bneeprosto)
            {
               cout<<i<<" "<<m/i<<endl;
               return;
            }
         }
      }
   }
}
int main()
{
   long long int m;
   while(cin>>m)
   {
      find(m);
   }
   return 0;
}
