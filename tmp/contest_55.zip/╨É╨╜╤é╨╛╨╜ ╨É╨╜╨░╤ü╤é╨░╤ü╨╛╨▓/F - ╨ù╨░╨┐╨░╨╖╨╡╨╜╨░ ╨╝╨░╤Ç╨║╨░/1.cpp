
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

typedef unsigned long long ULL;

const int MAX_L = 2000 + 5;
const ULL BASE = 3137ULL;

char str[MAX_L];
ULL pow[MAX_L];
ULL hash[MAX_L];

int main() {
	pow[0] = 1ULL;
	for (int i = 1; i < MAX_L; ++i)
		pow[i] = pow[i - 1] * BASE;
	
	while (scanf("%s", str) > 0) {
		int len = strlen(str);
		hash[0] = 0;
		for (int i = 1; i <= len; ++i)
			hash[i] = hash[i - 1] * BASE + ULL(str[i - 1]);
		
		int res = 0;
		for (int slen = 1; slen <= len; ++slen) {
			ULL arr[MAX_L];
			int cnt = 0;
			for (int beg = 0; beg + slen <= len; ++beg)
				arr[cnt++] = hash[beg + slen] - hash[beg] * pow[slen];
			sort(arr, arr + cnt);
			int num = 1;
			for (int i = 1; i < cnt; ++i)
				if (arr[i - 1] == arr[i])
					++num;
				else {
					if (res < num * slen)
						res = num * slen;
					num = 1;
				}
			if (res < num * slen)
				res = num * slen;
		}
		printf("%d\n", res);
	}
	return 0;
}
