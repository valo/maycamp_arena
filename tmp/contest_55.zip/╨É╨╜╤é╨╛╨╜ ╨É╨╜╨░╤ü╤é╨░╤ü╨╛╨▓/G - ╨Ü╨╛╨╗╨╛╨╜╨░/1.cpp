
#include <iostream>
#include <algorithm>
using namespace std;

typedef long long LL;

const int MAX_N = 200 + 5;

LL dp[MAX_N][3];

int main() {
	for (int j = 0; j < 3; ++j)
		dp[j + 1][j] = 1;
	for (int i = 1; i < 100; ++i)
		for (int j = 0; j < 3; ++j)
			for (int nj = 0; nj < 3; ++nj) if (j != nj) {
				dp[i + nj + 1][nj] += dp[i][j];
			}
	
	int tst;
	cin >> tst;
	for (int cas = 0; cas < tst; ++cas) {
		int N;
		cin >> N;
		cout << dp[N][0] + dp[N][1] + dp[N][2] << "\n";
	}
	return 0;
}
