
#include <cstdio>
using namespace std;

typedef long long LL;

int main() {
	LL N;
	while (scanf("%lld", &N) > 0) {
		for (LL i = 2; i * i <= N; ++i)
			if (N % i == 0) {
				printf("%lld %lld\n", i, N / i);
				break;
			}
	}
	return 0;
}
