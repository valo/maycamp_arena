
#include <cstdio>
#include <cstring>
using namespace std;

typedef long long LL;

const int MAX_N = 20 + 5;
const int MAX_K = 50 + 5;

LL dp[MAX_N][MAX_K];

int main() {
	int tst;
	scanf("%d", &tst);
	for (int cas = 0; cas < tst; ++cas) {
		int n, k;
		scanf("%d %d", &n, &k);
		
		memset(dp, 0, sizeof(dp));
		dp[0][0] = 1;
		for (int i = 0; i < n; ++i) {
			int p;
			scanf("%d", &p);
			for (int j = 0; j < p; ++j) {
				int x;
				scanf("%d", &x);
				for (int q = 0; q + x <= k; ++q)
					dp[i + 1][q + x] += dp[i][q];
			}
		}
		printf("%lld\n", dp[n][k]);
	}
	return 0;
}
