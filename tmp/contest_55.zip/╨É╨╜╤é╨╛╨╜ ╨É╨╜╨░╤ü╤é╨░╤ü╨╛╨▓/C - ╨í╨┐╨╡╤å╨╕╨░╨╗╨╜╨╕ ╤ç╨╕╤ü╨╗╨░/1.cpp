
#include <cstdio>
#include <cstring>
using namespace std;

const int MAX_L = 80 + 5;

char str[MAX_L];
int grid[MAX_L * 2][MAX_L * 2];

void rec(int at, int r, int c, int cols, int len, int &res) {
	if (c == cols)
		return rec(at, r + 1, 0, cols, len, res);
	int rows = r + (c + len - at + cols - 1) / cols;
	if ((rows + cols) * 2 >= res)
		return;
	if (at == len) {
		res = (rows + cols) * 2;
	} else {
		int num = str[at] - '0';
		if (r == 0 || (r > 0 && (grid[r - 1][c] == num || grid[r - 1][c] < 0))) {
			grid[r][c] = num;
			rec(at + 1, r, c + 1, cols, len, res);
		}
		grid[r][c] = -1;
		rec(at, r, c + 1, cols, len, res);
	}
}

int main() {
	while (scanf("%s", str) > 0) {
		int len = strlen(str);
		int res = 2 * (len + 1);
		for (int cols = len - 1; cols >= 1; --cols)
			rec(0, 0, 0, cols, len, res);
		printf("%d\n", res);
	}
	return 0;
}
