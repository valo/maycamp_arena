
#include <cstdio>
#include <algorithm>
using namespace std;

const int MAX_N = 1000000 + 5;

typedef long long LL;

int h[MAX_N];
int stk[MAX_N];
int left[MAX_N], right[MAX_N];

int main() {
	int tst;
	scanf("%d", &tst);
	for (int cas = 0; cas < tst; ++cas) {
		int N;
		scanf("%d", &N);
		for (int i = 1; i <= N; ++i)
			scanf("%d", &h[i]);
		h[0] = h[N + 1] = 0;
		N += 2;
		
		int sp = 0;
		for (int i = 0; i < N; ++i) {
			while (sp > 0 && h[stk[sp - 1]] > h[i]) {
				right[stk[sp - 1]] = i - 1;
				--sp;
			}
			stk[sp++] = i;
		}
		sp = 0;
		for (int i = N - 1; i >= 0; --i) {
			while (sp > 0 && h[stk[sp - 1]] > h[i]) {
				left[stk[sp - 1]] = i + 1;
				--sp;
			}
			stk[sp++] = i;
		}
		LL res = 0;
		for (int i = 1; i <= N; ++i)
			res = max(res, LL(right[i] - left[i] + 1) * h[i]);
		printf("%lld\n", res);
	}
	return 0;
}
