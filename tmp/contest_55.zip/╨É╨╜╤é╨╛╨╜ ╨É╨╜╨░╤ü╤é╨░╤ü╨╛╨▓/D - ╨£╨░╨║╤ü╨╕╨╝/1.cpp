
#include <cstdio>
using namespace std;

int main() {
	int tst;
	scanf("%d", &tst);
	for (int cas = 0; cas < tst; ++cas) {
		int na, nb, ta, tb;
		scanf("%d %d %d %d", &na, &nb, &ta, &tb);
		if (ta != tb)
			printf("%d\n", ta < tb ? na : nb);
		else
			printf("%d\n", na < nb ? na : nb);
	}
	return 0;
}
