
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int MAX_N = 50000 + 5;
const int MAX_C = 100000 + 5;

int ans[MAX_N];
pair<pair<int, int>, int> pnts[MAX_N];

struct fenwick {
	int tree[MAX_C];
	
	void clear() {
		memset(tree, 0, sizeof(tree));
	}
	
	int query(int p) {
		int res = 0;
		for (int i = p; i > 0; i -= (i & -i))
			res += tree[i];
		return res;
	}
	
	int add(int p) {
		for (int i = p; i < MAX_C; i += (i & -i))
			++tree[i];
	}
};

int main() {
	int tst;
	scanf("%d", &tst);
	fenwick tree;
	for (int cas = 0; cas < tst; ++cas) {
		int N;
		scanf("%d", &N);
		for (int i = 0; i < N; ++i) {
			int x, y;
			scanf("%d %d", &x, &y);
			pnts[i] = make_pair(make_pair(x, y), i);
		}
		sort(pnts, pnts + N);
		tree.clear();
		for (int i = 0; i < N; ++i) {
			ans[pnts[i].second] = tree.query(pnts[i].first.second);
			tree.add(pnts[i].first.second);
		}
		for (int i = 0; i < N; ++i)
			printf("%d\n", ans[i]);
	}
	return 0;
}
