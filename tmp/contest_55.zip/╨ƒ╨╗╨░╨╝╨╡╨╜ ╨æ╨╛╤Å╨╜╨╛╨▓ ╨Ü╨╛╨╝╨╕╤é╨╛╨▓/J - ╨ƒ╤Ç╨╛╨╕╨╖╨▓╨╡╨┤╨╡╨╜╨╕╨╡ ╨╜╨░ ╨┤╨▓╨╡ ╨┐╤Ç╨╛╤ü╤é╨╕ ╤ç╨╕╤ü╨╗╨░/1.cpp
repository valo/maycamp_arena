#include<iostream>
#include<math.h>
using namespace std;
long long x,br;

struct z
{
long long p;
long long v;
};
z a[1000001];
int simple(int y)
{
  long long i;
  for(i=2;i<=sqrt(y);i++)
    if(y%i==0)
      return 0;
  return 1;
}


int main()
{
  long long i;
  while(cin>>x)
  {
     for(i=2;i<=sqrt(x);i++)
       if(x%i==0)
         if(simple(i) && simple(x/i))
         {
           br++;
           a[br].p=i;
           a[br].v=x/i;
           break;
         }
  }
  for(i=1;i<=br;i++)
    cout<<a[i].p<<" "<<a[i].v<<endl;
system("pause");
return 0;
}
