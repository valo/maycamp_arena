#include<iostream>
using namespace std;
int main()
{
int t,n;
cin>>t;
int a[1000]
for(int i=1;i<=t;i++)
{
cin>>n;
if (n==1) a[i]==1;
if (n==2||n==3) a[i]==2;
if (n==4) a[i]==3;
if (n==5) a[i]==4
if (n>5) a[i]=12368;
}
for (int i=1;i<=t;i++) cout<<a[i]<<endl;
return 0;
}
