   /*
Task:
Lang:
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <string>
#include <queue>
#include <stack>
#include <cstring>

using namespace std;

int G[40002];

int main()
{
	int T;
	cin>>T;
	for(int t=0; t<T; t++)
	{
	int n;
	cin>>n;
	for(int i=0; i<n; i++)cin>>G[i];
	int otg=n;
	int br=0;
	for(int i=2; i<=n; i++)
	{
		br=0;
		for(int j=0; j<n; j++)
		{
			if(G[j]>=i)br+=i;
			else
			{
				if(br>otg)otg=br;
				br=0;
			}
		}
	}	
		cout<<otg<<endl;
	}
    return 0;
}

