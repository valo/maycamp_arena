//Created by Dimitar
#include <iostream>
using namespace std;
int main()
{
int a, b, c, d, e;
cin>>e;
for(int i=1; i<=e; i++)
{cin>>a>>b>>c>>d;
for(int t=1; t<=e; t++)
{if(c<d){cout<<a<<endl;}
else {cout<<b<<endl;}}}
return 0;
}
