#include<iostream>
#include<cstdio>
#include<vector>
#define maxp 46340
using namespace std;
bool sus[maxp];
int main(){
vector<long long> prostidel;
long long n,o=0;
    for(long long p=2;p*p<=46340;p++){
        if(!sus[p]){
            for(long long q=p*2;q<=46340;q+=p){
                sus[q]=1;
              //  cout<<sus[q]<<"\t";
            }
        }
    }
   while (cin >> n) {
          for(long long i=2;i*i<=n;i++){
              if(!sus[i]){
                 if(n%i==0){
                    if(!sus[n/i]){
                        if(i<n/i){

                            prostidel.push_back(i);

                            prostidel.push_back(n/i);
                            break;
                        }
                        if(i>n/i){
                              prostidel.push_back(n/i);

                            prostidel.push_back(i);
                            break;
                        }
                    }
                 }
              }
          }
    }
    for(long long q=0;q<prostidel.size();q++){
       if(!(o%2)){
           cout<<prostidel[q]<<" ";
       }else{
           cout<<prostidel[q]<<"\n";
       }
       o++;
    }
return 0;
}
