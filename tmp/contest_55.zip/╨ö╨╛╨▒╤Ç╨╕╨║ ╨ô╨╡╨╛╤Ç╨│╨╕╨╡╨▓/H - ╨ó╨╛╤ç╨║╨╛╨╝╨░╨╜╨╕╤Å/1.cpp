#include<iostream>
using namespace std;
long x[50000],y[50000],brt[50000];
int main()
{
  long t,n;
  cin>>t;
  for(long i=0;i<t;i++)
  {
    cin>>n;
    for(int j=0;j<n;j++)cin>>x[j]>>y[j];
    for(int j=0;j<n;j++)
    {
      for(int k=0;k<n;k++)
      {
        if(j!=k)
        {
        if(x[j]>=x[k]&&y[j]>=y[k])brt[j]++;
        }
      }
    }
    for(int j=0;j<n;j++)cout<<brt[j]<<endl;
  }
  return 0;
}
