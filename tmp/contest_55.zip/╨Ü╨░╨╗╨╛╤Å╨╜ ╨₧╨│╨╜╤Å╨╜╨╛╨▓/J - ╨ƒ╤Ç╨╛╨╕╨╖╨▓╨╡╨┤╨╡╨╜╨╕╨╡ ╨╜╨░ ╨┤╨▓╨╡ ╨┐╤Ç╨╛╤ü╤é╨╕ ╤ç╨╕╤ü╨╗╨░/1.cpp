#include <iostream>
using namespace std;

int n,a,b;

void GetIt()
{
    if(n % 2 == 0)
    {
        a = 2;
        b = n / 2;
        return;
    }

    for(int i = 3;i < n;i+=2)
    {
        if(n % i == 0)
        {
            a = i;
            b = n / i;
            return;
        }
    }
}

int main()
{
    while(scanf("%d",&n))
    {
        GetIt();

        printf("%d %d",a,b);
    }

    return 0;
}
