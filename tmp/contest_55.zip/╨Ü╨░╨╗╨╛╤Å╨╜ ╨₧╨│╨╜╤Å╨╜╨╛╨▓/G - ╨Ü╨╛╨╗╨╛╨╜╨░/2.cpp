#include <iostream>
using namespace std;

struct hc{
    long long cases, one, two, three;
};

const int MAXN = 100;
long long T, N;
hc columns[101];

int main()
{
    cin >> T;

    columns[0].cases = 1;
    columns[0].one = 0;
    columns[0].two = 0;
    columns[0].three = 0;

    columns[1].cases = 1;
    columns[1].one = 1;
    columns[1].two = 0;
    columns[1].three = 0;

    columns[2].cases = 1;
    columns[2].one = 0;
    columns[2].two = 1;
    columns[2].three = 0;

    for(int i = 3;i < MAXN + 1;i++)
    {
        columns[i].one = columns[i - 1].cases - columns[i - 1].one;
        columns[i].two = columns[i - 2].cases - columns[i - 2].two;
        columns[i].three = columns[i - 3].cases - columns[i - 3].three;

        columns[i].cases = columns[i].one + columns[i].two + columns[i].three;
    }

    for(int z = 0; z < T; z++)
    {
        cin >> N;
        cout << columns[N].cases << endl;
    }

    return 0;
}
