#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <string.h>

#define x first.first
#define y first.second
#define ind second
#define Rep(i,l,r) for(int i=l;i<r;i++)

using namespace std;

typedef pair< pair<int,int> , int> p_ii_i;

const int maxx = 100000;

int n;
p_ii_i m[50010];
int tree[100010];
int sol[100010];

void update(int index)
{
    while(index<=maxx)
    {
        tree[index]++;
        index+=(index & -index);
    }
}

int sum(int index)
{
    int ret=0;
    while(index)
    {
        ret+=tree[index];
        index-=(index & -index);
    }
    return ret;
}

bool cmp(p_ii_i a, p_ii_i b)
{
    if(a.y<b.y) return true;
    if(a.y>b.y) return false;
    if(a.x<b.x) return true;
    return false;
}

void init()
{
    scanf("%d",&n);
    Rep(i,0,n)
    {
        scanf("%d %d",&m[i].x,&m[i].y);
        m[i].ind=i;
    }
    
    sort(m,m+n,cmp);
    
    memset(tree,0,sizeof(tree));
}

void solve()
{
    Rep(i,0,n)
    {
        sol[ m[i].ind ]=sum(m[i].x);
        update(m[i].x);
    }
    Rep(i,0,n) printf("%d\n",sol[i]);
}

int main()
{
    int t;
    scanf("%d",&t);
    for(;t;t--)
    {
        init();
        solve();
    }
    
    return 0;
}
