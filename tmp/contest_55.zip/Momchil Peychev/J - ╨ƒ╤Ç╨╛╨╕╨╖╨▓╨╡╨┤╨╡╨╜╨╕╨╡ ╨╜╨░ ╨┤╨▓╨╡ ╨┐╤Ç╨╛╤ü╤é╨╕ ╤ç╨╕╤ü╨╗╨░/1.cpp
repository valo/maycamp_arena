#include <stdio.h>
#include <iostream>
#include <math.h>

#define Rep(i,l,r) for(int i=l;i<r;i++)

using namespace std;

int m;

void solve()
{
    Rep(i,2,sqrt(m)) if(m%i==0) { printf("%d %d\n",i,m/i); return; }
}

int main()
{
    while(scanf("%d",&m)==1) solve();
    
    return 0;
}
