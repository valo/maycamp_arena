#include <stdio.h>
#include <iostream>

#define Rep(i,l,r) for(int i=l;i<r;i++)

using namespace std;

void solve()
{
    int n,m,t1,t2;
    scanf("%d %d %d %d",&n,&m,&t1,&t2);
    if(t1>=t2) printf("%d\n",m);
    else printf("%d\n",n);
}

int main()
{
    int t;
    scanf("%d",&t);
    for(;t;t--) solve();
    
    return 0;
}
