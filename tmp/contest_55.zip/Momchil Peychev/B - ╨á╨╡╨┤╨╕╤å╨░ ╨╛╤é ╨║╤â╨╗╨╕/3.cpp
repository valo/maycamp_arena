#include <stdio.h>
#include <iostream>
#include <set>
#include <algorithm>

using namespace std;

typedef long long ll;

int n;
int pos[40010];
set<int> s;
set<int> ::iterator it,l,r;
ll sol;

void init()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        int x;
        scanf("%d",&x);
        pos[x]=i;
    }
}

void solve()
{
    sol=n;
    
    s.clear();
    s.insert(0);
    s.insert(pos[1]);
    s.insert(n+1);
    
    for(int i=2;i<=n;i++)
    {
        l=lower_bound(s.begin(),s.end(),pos[i]); l--;
        r=upper_bound(s.begin(),s.end(),pos[i]);
        
        ll tmp=((*r)-(*l)-1)*i;
        if(tmp>sol) sol=tmp;
        
        s.insert(pos[i]);
    }
    
    cout << sol << endl;
}

int main()
{
    int t;
    scanf("%d",&t);
    for(;t;t--)
    {
        init();
        solve();
    }
    
    return 0;
}
