#include <stdio.h>
#include <iostream>
#include <stdio.h>

#define Rep(i,l,r) for(int i=l;i<r;i++)

using namespace std;

int n;
int m[40010];

void init()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++) scanf("%d",&m[i]);
}

void solve()
{
    int mx=0;
    for(int i=0;i<n;i++)
    {
        int mn=m[i];
        for(int j=i;j<n;j++)
        {
            if(mn>m[j]) mn=m[j];
            if(mx<(j-i+1)*mn) mx=(j-i+1)*mn;
        }
    }
    printf("%d\n",mx);
}

int main()
{
    int t;
    scanf("%d",&t);
    for(;t;t--)
    {
        init();
        solve();
    }
    
    return 0;
}
