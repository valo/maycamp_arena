#include<iostream>
using namespace std;
int main()
{
    int a[40001],min,maxet,t,n,i,j,k;
    a[0]=10000;
cin>>t>>n;
for(t=t;t>0;t--)
{
                 for(i=1;i<=n;i++)
                 {
                                  cin>>a[i];
                 }
                 for(i=1;i<=n;i++)
                 {
                                  
                                 for(j=0;j<=(n-i)+1;j++)
                                 {
                                                        
                                                        min=10000;
                                                        //cout<<i<<" "<<j+i<<endl;
                                                        for(k=j;k<=(j+i);k++)
                                                        {
                                                                           //system("pause");
                                                                           if(a[k]<=min)
                                                                           {
                                                                                        min=a[k];
                                                                           }
                                                        }
                                                        if(min*i>maxet)
                                                        {
                                                                           maxet=min*i;
                                                        }
                                                        //cout<<maxet<<endl;
                                 }
                 }
}

cout<<maxet<<endl;
//system("pause");
return 0;
}
/*1
8
7 6 1 4 5 3 2 8
*/
