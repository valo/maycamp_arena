#include <iostream>
#include <cmath>
using namespace std;

int solve()
{
  double x1, y1, x2, y2, x3, y3;
  if(!(cin>>x1>>y1>>x2>>y2>>x3>>y3)) return 0;
  double a, b, c;
  double k1=x1*x1-x3*x3, p1=x1-x3, q1=y1-y3;
  double k2=x2*x2-x3*x3, p2=x2-x3, q2=y2-y3;
  a=(q1-p1/p2*q2)/(k1-p1/p2*k2);
  b=q2/p2-a*k2/p2;
  c=y3-a*x3*x3-b*x3;
  //if(fabs(a*x1*x1+b*x1+c-y1)>1e-6) cerr<<"!";
  //if(fabs(a*x2*x2+b*x2+c-y2)>1e-6) cerr<<"!";
  //if(fabs(a*x3*x3+b*x3+c-y3)>1e-6) cerr<<"!";
  
  double m=(y1-y3)/(x1-x3), n=y1-m*x1;
  //if(fabs(m*x1+n-y1)>1e-6) cerr<<"?";
  //if(fabs(m*x3+n-y3)>1e-6) cerr<<"?";
  //cerr<<m<<' '<<n<<endl;1
  
  double eps=(x3-x1)/1e5;
  double res=0;
  for(double x=x1; x<=x3; x+=eps) res+=fabs(a*x*x+b*x+c-m*x-n)*eps;
  cout<<(int)(res+0.5)<<endl;
  return 1;
}

int main()
{
  while(solve());
  return 0;
}
