#include <iostream>
#include <cstring>
using namespace std;

int a[50000];
void solve()
{
  int n; cin>>n;
  for(int i=0; i<n; ++i) cin>>a[i]; a[n]=-1;
  
  int max=-1;
  for(int i=0; i<n; ++i)
  {
    int l, r;
    for(l=i; l>0 && a[l-1]>a[i]; --l);
    for(r=i; a[r+1]>a[i]; ++r);
    if(a[i]*(r-l+1)>max) max=a[i]*(r-l+1);
  }
  cout<<max<<endl;
}

int main()
{
  int n; cin>>n;
  for(int i=0; i<n; ++i) solve();
  return 0;
}
