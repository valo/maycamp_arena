#include <iostream>
#include <cstring>
using namespace std;

struct tree
{
  int lx, rx, dy, uy;
  int br;
  tree() { lx=rx=dy=uy=0; br=0; lu=ld=ru=rd=0; }
  tree(int x1, int y1, int x2, int y2) { lx=x1; rx=x2; dy=y1; uy=y2; br=0; lu=ld=ru=rd=0; }
  tree *lu, *ld, *ru, *rd;
  
  void add(int x, int y)
  {
    //cerr<<lx<<' '<<rx<<' '<<dy<<' '<<uy<<endl;
    if(x<lx || x>rx || y<dy || y>uy) return;
    ++br;
    if(lx==rx && dy==uy) return;
    int mx=(lx+rx)/2, my=(dy+uy)/2;
    if(x<=mx && y<=my) { if(!ld) ld=new tree(lx, dy, mx, my); ld->add(x,y); }
    else if(x<=mx && y>my) { if(!lu) lu=new tree(lx, my+1, mx, uy); lu->add(x, y); }
    else if(y<=my) { if(!rd) rd=new tree(mx+1, dy, rx, uy); rd->add(x,y); }
    else { if(!ru) ru=new tree(mx+1, my+1, rx, uy); ru->add(x,y); }
  }
  
  int q(int x1, int y1, int x2, int y2)
  {
    //cerr<<x1<<' '<<y1<<' '<<x2<<' '<<y2<<endl;
    if(x1<=lx && x2>=rx && y1<=dy && y2>=uy) return br;
    if(x1> rx || x2< lx || y1> uy || y2< dy) return 0;
    int res=0;
    if(lu) res+=lu->q(x1, y1, x2, y2);
    if(ru) res+=ru->q(x1, y1, x2, y2);
    if(rd) res+=rd->q(x1, y1, x2, y2);
    if(ld) res+=ld->q(x1, y1, x2, y2);
    return res;
  }
};

int x[120000], y[120000];
void solve()
{
  //cerr<<"slv\n";
  tree *t=new tree(0,0,110000,110000);
  int n, i;
  cin>>n;
  for(i=0; i<n; ++i) cin>>x[i]>>y[i];
  for(i=0; i<n; ++i) t->add(x[i], y[i]);
  for(i=0; i<n; ++i) cout<<t->q(0,0, x[i], y[i])-1<<endl;
}

int main()
{
  int n; cin>>n;
  for(int i=0; i<n; ++i) solve();
  return 0;
}
