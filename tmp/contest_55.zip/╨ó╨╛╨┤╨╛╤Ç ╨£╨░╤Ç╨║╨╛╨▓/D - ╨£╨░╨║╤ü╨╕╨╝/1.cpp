#include <iostream>
using namespace std;

int slv()
{
  int n, m, a, b;
  cin>>n>>m>>a>>b;
  cout<<(a<b?n:m)<<endl;
}

int main()
{
  int n; cin>>n;
  for(int i=0; i<n; ++i) slv();
  return 0;
}
