#include <iostream>
#include <cstring>
using namespace std;

int n, k;
int b[128][128];
int dp[128][128];

void solve()
{
  int n, k; cin>>n>>k;
  int i, j, t;
  for(i=0; i<n; ++i)
    for(j=1, cin>>b[i][0]; j<=b[i][0]; ++j) cin>>b[i][j];
  memset(dp, 0, sizeof(dp));
  for(j=0; j<=k; ++j)
    for(t=1; t<=b[0][0]; ++t)
      dp[0][b[0][t]]=1;
  for(i=1; i<n; ++i)
    for(j=0; j<=k; ++j)
      for(t=1; t<=b[i][0]; ++t)
	if(j>=b[i][t]) dp[i][j]+=dp[i-1][j-b[i][t]];
  cout<<dp[n-1][k]<<endl;
}

int main()
{
  int n; cin>>n;
  for(int i=0; i<n; ++i) solve();
  return 0;
}
