#include <iostream>
#include <cstring>
using namespace std;

long long dp[128][4];
int solve(long long n)
{
  long long i;
  for(i=2; i*i<=n; ++i) if(n%i==0) { cout<<i<<' '<<n/i<<endl; return 1; }
  return 1;
}

int main()
{
  long long n;
  while(cin>>n) solve(n);
  return 0;
}
