#include <iostream>
using namespace std;
int d, i;
int main()
{
while(scanf("%d", &d) == 1)
{
for(i=2; i*i<=d; i++) 
if(d % i == 0) printf("%d %d\n", i, d/i);
}
//system("pause");
return 0;    
}
