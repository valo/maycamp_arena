#include <iostream>
using namespace std;
int a, b, c, d, t;
void solve()
{
scanf("%d%d%d%d", &a, &b, &c, &d);
if(c < d) printf("%d\n", a);
else printf("%d\n", b);
}
int main()
{
scanf("%d", &t);
for(; t; t--) solve();
return 0;
}
