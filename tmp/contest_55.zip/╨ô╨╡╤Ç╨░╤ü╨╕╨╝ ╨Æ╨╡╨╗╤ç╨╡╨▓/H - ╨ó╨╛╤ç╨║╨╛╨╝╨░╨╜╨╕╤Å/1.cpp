#include <iostream>
#define lb(i) (i&(-i))
using namespace std;
int n, res[50000], it[100001];
struct p { int x, y, pl; } a[50000];
bool cmp(p a, p b){ if(a.x != b.x) return a.x < b.x; return a.y < b.y; }
int q(int x)
{
int i, ans = 0;
for(i=x; i; i-=lb(i)) ans += it[i];   
return ans;
}
void push(int x)
{
int i;
for(i=x; i<=100000; i+=lb(i)) it[i]++;     
}
void solve()
{
memset(it, 0, sizeof(it));
memset(a, 0, sizeof(a));
memset(res, 0, sizeof(res));
int i;
scanf("%d", &n);
for(i=0; i<n; i++) { scanf("%d%d", &a[i].x, &a[i].y); a[i].pl = i; }
sort(a, a+n, cmp);
for(i=0; i<n; i++)
{
res[a[i].pl] = q(a[i].y);          
push(a[i].y);
}
for(i=0; i<n; i++) printf("%d\n", res[i]);
}
int main()
{
int t;
scanf("%d", &t);
for(;t;t--) solve();
return 0;    
}
