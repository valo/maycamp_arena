#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
struct brick
{
   long a,b,c;
};
vector <brick> v;
brick br;
long n,x,y,z,i,j,w[1501];
bool cmp (brick p1, brick p2)
{
   if (p2.a<p1.a) {return false;}
   else if (p2.a>p1.a) {return true;}
        else if (p2.a==p1.a)
             {
                if (p2.b<p1.b) {return false;}
                else if (p2.b>p1.b) {return true;}
                     else if (p2.b==p1.b)
                          {
                             if (p2.c>p1.c) {return false;}
                             else {return true;}
                          }
             }
}
int main()
{
    cin>>n;
    for(i=1;i<=n;i++)
    {
       cin>>x>>y>>z;
       br.a=min(x,y);
       br.b=max(x,y);
       br.c=z;
       v.push_back(br);
       br.a=min(x,z);
       br.b=max(x,z);
       br.c=y;
       v.push_back(br);
       br.a=min(y,z);
       br.b=max(y,z);
       br.c=x;
       v.push_back(br);
    }
    sort(v.begin(),v.end(),cmp);
    for(i=0;i<=3*n-1;i++)
    {
       if (i!=0 && v[i].a==v[i-1].a && v[i].b==v[i-1].b) {continue;}
       else
       {
          w[i]=v[i].c;
          for(j=i-1;j>=0;j--)
          {
             if (v[i].a>v[j].a && v[i].b>v[j].b) {w[i]=max(w[i],v[i].c+w[j]);}
          }
       }
    }
    cout<<w[3*n-1]<<endl;
    //system("pause");
    return 0;
}
