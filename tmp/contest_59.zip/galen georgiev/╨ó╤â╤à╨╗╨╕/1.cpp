#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
struct brick
{
    int a,b,h;
    bool operator < (const brick &p) const
    {
        if(a<p.a) return 1;
        else if(a==p.a)
        {
            if(b<p.b) return 1;
            else if(b==p.b) return h<p.h;
            else return 0;
        }
        else return 0;
    }
};
int n;
int H[2024];
vector<brick>v;
void read()
{
    int i,x,y,z;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d%d%d",&x,&y,&z);
        brick p;
        p.a=min(x,y);
        p.b=max(x,y);
        p.h=z;
        v.push_back(p);
        p.a=min(x,z);
        p.b=max(x,z);
        p.h=y;
        v.push_back(p);
        p.a=min(y,z);
        p.b=max(y,z);
        p.h=x;
        v.push_back(p);
    }
}
void init()
{
    int i;
    for(i=1;i<n*3;i++)
    if(v[i-1].a==v[i].a&&v[i-1].b==v[i].b)
    {
        v[i-1].a=0;
        v[i-1].b=0;
        v[i-1].h=0;
    }
}
void solve(int m)
{
    if(m==0)
    {
        H[m]=v[m].h;
        return;
    }
    H[m]=v[m].h;
    int i;
    for(i=0;i<m;i++)
    if(v[i].a!=0)
    {
        if(v[i].a<v[m].a&&v[i].b<v[m].b) H[m]=max(v[m].h+H[i],H[m]);
    }
}
int main()
{
    read();
    sort(v.begin(),v.end());
    init();
    for(int i=0;i<v.size();i++)
    if(v[i].a!=0)
    {
        solve(i);
    }
    printf("%d\n",H[v.size()-1]);
    return 0;
}
