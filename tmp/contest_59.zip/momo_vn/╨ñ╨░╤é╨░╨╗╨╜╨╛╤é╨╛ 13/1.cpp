/*
TASK: z13
LANG: C++
*/
#include <iostream>
#include <stdio.h>
#include <vector>

#define pb push_back

using namespace std;

typedef long long ll;

const ll mod = 12345678;
const int MAXN = (1<<10);

int n;
ll dp[MAXN][2];
ll b[MAXN];
ll f[MAXN];
ll ans;

void calc()
{
    dp[1][0]=1;
    dp[1][1]=8;
    for(int i=2;i<=n;i++)
    {
        dp[i][1]=( 8*(dp[i-1][0]+dp[i-1][1])+dp[i-1][1] ) % mod;
        dp[i][0]=( dp[i-1][1]+dp[i-1][0] ) % mod;
    }

    b[0]=1;
    for(int i=1;i<=n;i++) b[i]=( dp[i][0]+dp[i][1] ) % mod;

    //for(int i=0;i<=n;i++) cout << b[i] << " ";
    //cout << endl;
}

void solve()
{
    f[2]=1;
    for(int i=3;i<=n;i++)
        f[i]=(f[i-1]*10+b[i-2])%mod;
    for(int i=2;i<=n;i++)
        ans=(ans+f[i])%mod;

    cout << ans << endl;

}

int step(int x)
{
    int p=1;
    for(int i=1;i<=x;i++) p*=10;
    return p;
}

bool check(int num)
{
    vector<int> v;
    int t=num;
    while(num)
    {
        v.pb(num%10);
        num/=10;
    }
    for(int i=0;i<v.size()-1;i++)
        if(v[i]==3 && v[i+1]==1)
        {
            //cout << t << endl;
            //system("Pause");
            return true;
        }
    return false;
}

int brute()
{
    int br=0;
    for(int i=1;i<step(n);i++)
        br+=check(i);
    return br;
}

int main()
{
    scanf("%d",&n);
    //cout << brute() << endl;
    calc();
    solve();

    return 0;
}
