#include<iostream>
#include<algorithm>

using namespace std;

bool cmp( int a, int b )
{
    return a < b;
}
int main()
{
  int n, a[ 10005 ];
  cin >> n;
  for ( int i = 0 ; i < n; i++ )
  {
    cin >> a[ i ];
  }
  sort( a, a + n, cmp );
  long long int s = 0;
  for ( int i = 0; i < n; i++ )
  {
        if ( ( i + 1 )  % 3 != 0 ) s += a[ i ];
  }
  cout << s << endl;
  return 0;
  
}
