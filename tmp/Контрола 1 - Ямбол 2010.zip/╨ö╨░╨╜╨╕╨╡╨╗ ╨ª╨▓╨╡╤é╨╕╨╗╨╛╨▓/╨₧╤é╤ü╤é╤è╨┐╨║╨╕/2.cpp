#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <stdlib.h>
#include <iomanip>
#include <fstream>
#include <set>

#define SP system("pause");
#define x first
#define y second
#define f( a, b ) for ( int i = a; i < b; i++ )
#define fm( a, b ) for ( int i = a; i >= b; i-- )

int maxn = 99999;

typedef long long int lli;

using namespace std;

int n;
int a[ 10005 ];

bool cmp( int a, int b )
{
    if ( a >= b ) return false;
    return true;
}
int main()
{
    cin >> n;
    for ( int i = 0; i < n; i++ ) cin >> a[ i ];
    sort( a, a + n, cmp );
    int p, t;
    lli sum = 0;
    int i;
    for ( i = 0; i < n; i++ )
    {
        if ( i % 3 == 0 )
        {
            sum += a[ i ];
            sum += a[ i + 1 ];   
        }
    }
    
    cout << sum << endl;
   
	return 0;
}
