#include <cstdio>
#include <algorithm>
#include <vector>

using namespace std;

int main()
{

	int n;
	scanf("%d",&n);

	vector<int> a(n);
	for (int i=0; i<n; i++)
		scanf("%d",&a[i]);

	sort(a.rbegin(), a.rend());

    long sum = 0;
    for (int i = 0; i < n; i++)
      if ((i + 1) % 3 != 0) sum += a[i];

	printf("%d\n",sum);
	return 0;
}
