
#include <iostream>
#include <string>

using namespace std;



inline int numcmp(const string &a,const string &b) {
     int asz=a.size(),bsz=b.size(),i;
     if(asz<bsz)return -1;
     else if(asz>bsz)return 1;
     for(i=0;i<asz&&a[i]==b[i];i++);
     if(i>=asz)return 0;
     else return a[i]-b[i];
}

inline string numdiv(const string &a,int d) {
     string res;
     int i,rem,asz=a.size();
     for(i=0,rem=0;i<asz;i++) {
          rem=10*rem+a[i]-'0';
          if(rem/d||!res.empty())res.push_back('0'+rem/d);
          rem%=d;
     }
     if(res.empty())res.push_back('0');
     return res;
}

int main() {
     int n;
     string a,b;
     int c;


     cin>>n>>a>>b;
     while(c=numcmp(a,b)) {
          if(c>0)a=numdiv(a,2);
          else b=numdiv(b,2);
     }
     cout<<a<<endl;

     return 0;
}
