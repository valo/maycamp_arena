#include <iostream>
#include <string>
#include <vector>
using namespace std;

vector<string> pos1,pos2;

string div2(string s)
{
       int n=s.size();
       string z="";
       int p=0, d;
       for(int i=0; i<n; i++) 
       {
               d=s[i]-'0';
               z+=((p*10)+d)/2+'0';
               p=(p*10+d)%2;
       }
       if(z[0]=='0') z.erase(0,1);
       return z;
}

int main()
{
    int n;
    string s, s1;
    cin >> n;
    cin >> s >> s1;
    while(s!="" || s1!="")
    {
                //cout << s << ' ' << s1 << endl;
                pos1.push_back(s);
                pos2.push_back(s1);
                s=div2(s);
                s1=div2(s1);
    }
    int k=pos1.size(), m=pos2.size();
    for(int i=0; i<k; i++)
    for(int j=0; j<m; j++){
                // cout << pos1[i] << ' ' << pos2[j] << endl;
    if(pos1[i]==pos2[j]){ cout << pos1[i] << endl; return 0;}
    }
    return 0;
}
    
