#include <iostream>
#include <algorithm>
using namespace std;

bool f(int a, int b)
{
     return a>b;
}

long long dp[10004];

int main()
{
    int a[10005], n;
    cin >> n;
    for(int i=0; i<n; i++)
    cin >> a[i];
    sort(a,a+n,f);
    
    dp[0]=a[0];
    dp[1]=dp[0]+a[1];
    dp[2]=dp[1];
    dp[3]=dp[2]+a[2];
    long long tk=90000009;
    
    for(int i=4; i<n; i++)
    {
            tk=dp[i-1]+a[i];
            tk=min(tk,dp[i-2]+a[i-1]+a[i]);
            tk=min(tk,dp[i-3]+a[i-2]+a[i-1]);
            tk=min(tk,dp[i-4]+a[i-3]+a[i-2]+a[i-1]);
            dp[i]=tk;
    }
    cout << dp[n-1] << endl;
    return 0;
}
            
