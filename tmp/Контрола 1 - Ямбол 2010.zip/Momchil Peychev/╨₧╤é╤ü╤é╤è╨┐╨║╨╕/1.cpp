/*
TASK: discount
LANG: C++
*/
#include <iostream>
#include <stdio.h>
#include <algorithm>

using namespace std;

const int MAXN = 10010;

int n;
int a[MAXN];

void init()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++) scanf("%d",&a[i]);
    sort(a,a+n);
}

void solve()
{
    long long ans=0;
    for(int i=n-1;i>=2;i-=3) ans+=a[i]+a[i-1];
    if(n%3==1) ans+=a[0];
    if(n%3==2) ans+=a[0]+a[1];
    cout << ans << endl;
}

int main()
{
    init();
    solve();

    return 0;
}
