/*
TASK: tournament
LANG: C++
*/
#include <iostream>
#include <stdio.h>

using namespace std;

const int MAXK = 10;
const int MAXN = (1<<MAXK) + 10;

int k,n;
int a[MAXN][MAXN];
bool row[MAXN][MAXN],col[MAXN][MAXN];

void init()
{
    scanf("%d",&k);
    n=(1<<k);
    for(int i=1;i<n;i++)
    {
        row[i][i]=1;
        row[1][i]=1; col[i][1]=1;
        a[1][i]=i+1;
        a[i+1][i]=1;
        row[i+1][1]=1; col[i][i+1]=1;
    }
    row[1][n]=1;
    row[n][n]=1;

    for(int i=2;i<=n;i++)
        for(int j=1;j<n;j++)
            if(!a[i][j])
            {
                for(int num=i+1;num<=n;num++)
                    if(!row[i][num] && !col[j][num])
                    {
                        row[i][num]=1; col[j][num]=1;
                        a[i][j]=num;
                        a[num][j]=i;
                        row[num][i]=1; col[j][i]=1;
                        break;
                    }
            }
}

void write()
{
    for(int i=1;i<=n;i++)
    {
        printf("%d",a[i][1]);
        for(int j=2;j<n;j++)
            printf(" %d",a[i][j]);
        printf("\n");
    }
}

int main()
{
    init();
    write();

    return 0;
}
