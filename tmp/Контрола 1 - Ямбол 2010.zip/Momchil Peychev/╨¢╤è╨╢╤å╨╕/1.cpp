/*
TASK: liars
LANG: C++
*/
#include <iostream>
#include <stdio.h>

using namespace std;

const int MAXN = (1<<10);

int n,a;
int br[MAXN];
int ans;

void init()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a);
        br[a]++;
    }
}

void solve()
{
    for(int i=1;i<=n;i++)
        if(br[i]==i)
            ans++;

    if(ans==1) { printf("0\n"); return; }
    cout << ans << endl;
}

int main()
{
    init();
    solve();

    return 0;
}
