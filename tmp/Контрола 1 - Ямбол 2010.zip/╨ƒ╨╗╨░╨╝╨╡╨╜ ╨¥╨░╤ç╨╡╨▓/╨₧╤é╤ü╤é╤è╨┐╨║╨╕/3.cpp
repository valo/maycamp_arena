#include<iostream>
#include<algorithm>
using namespace std;
int main ()
{ int n, a[10000], i; 
  long long sum = 0;

cin >> n;

for( i = 0; i < n; i++ )
cin >> a[i];

sort(a, a+n);

for( i = 0; i < n; i++ )
if( (i + 1) % 3 != 0 )  sum += a[i];

cout << sum << endl;

cin >> n;
return 0;
}
