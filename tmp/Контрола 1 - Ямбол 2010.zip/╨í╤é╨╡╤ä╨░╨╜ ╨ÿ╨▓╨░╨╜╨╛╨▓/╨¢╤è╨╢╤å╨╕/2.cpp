#include<iostream>
using namespace std;
long n,m,br,i,a[1024];
int main()
{
    cin>>n;
    for(i=1;i<=n;i++)
    {
       cin>>m;
       a[m]++;
    }
    for(i=1;i<=n;i++)
    {
       if (a[i]==i) {br++;}
    }
    if (br==1) {cout<<0;}
    else {cout<<br;}
    cout<<endl;
    //system("pause");
    return 0;
}
