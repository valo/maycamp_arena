#include<iostream>
#include<algorithm>
using namespace std;
long n,i,br,sum,a[10001];
int main()
{
    cin>>n;
    for(i=1;i<=n;i++)
    {
       cin>>a[i];
    }
    sort(a+1,a+n+1);
    br=1;
    for(i=n;i>=1;i--)
    {
       if (br%3!=0) {sum=sum+a[i];}
       br++;
    }
    cout<<sum<<endl;
    //system("pause");
    return 0;
}
    
