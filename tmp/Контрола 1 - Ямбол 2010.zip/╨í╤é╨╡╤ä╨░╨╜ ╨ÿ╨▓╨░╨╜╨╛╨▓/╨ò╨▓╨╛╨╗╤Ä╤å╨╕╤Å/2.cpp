#include<iostream>
using namespace std;
string divide (string x)
{
   char c;
   string result;
   long i,k,n,m,sz=x.size();
   if (x[0]<(2+'0')) {k=2;n=10*(x[0]-'0')+(x[1]-'0');}
   else {k=1;n=x[0]-'0';}
   m=n/2;
   c=m+'0';
   result=c;
   n=n%2;
   for(i=k;i<=sz-1;i++)
   {
      n=n*10+x[i]-'0';
      m=n/2;
      c=m+'0';
      result=result+c;
      n=n%2;
   }
   //cout<<result<<endl;
   return result;
}
int main()
{
    string s,t;
    long nm,n,m;
    cin>>nm;
    cin>>s;
    cin>>t;
    while(1)
    {
       if (s==t) {break;}
       n=s.size();
       m=t.size();
       if (n>m) {s=divide(s);}
       else if (n<m) {t=divide(t);}
            else if (n==m)
                 {
                    if (s>t) {s=divide(s);}
                    else {t=divide(t);}
                 }
    }
    cout<<s<<endl;
    //system("pause");
    return 0;
}
