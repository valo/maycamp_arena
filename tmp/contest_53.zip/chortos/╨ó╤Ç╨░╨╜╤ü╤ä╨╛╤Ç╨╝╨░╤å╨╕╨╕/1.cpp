#include <stdio.h>

#ifdef WIN32
#define I64 "%I64u"
#else
#define I64 "%llu"
#endif

int main(void)
{
	long long n, m;
	scanf(I64 I64, &n, &m);

	int ans = 0;

	if (!n && m)
	{
		++ans;
		if (m >= 2) n = 2;
	}

	while (m >= n*2 && (n > 1 || m > 5))
	{
		if (m & 1) ++ans;
		++ans;
		m /= 2;
	}

	printf(I64 "\n", ans + (m - n + 1) / 2);
	return 0;
}
