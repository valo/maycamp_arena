#include <stdio.h>
#include <string.h>

int main(void)
{
	char text[100001];
	gets(text);

	int n = strlen(text);

	static int sa1[100000], sa2[100000], *sufarr = sa1, *sufarr2 = sa2, buckets[100002], ib1[100002], ib2[100002], *ibuckets = ib1, *ibuckets2 = ib2, *bend = buckets;
	ib2[0] = 0;

	{
		union { int n, *p; } binfo[27] = { 0 };
		for (int i = 0; i < n; ++i) ++binfo[text[i] -= 'A' - 1].n;
		++binfo[0].n;
		for (int i = 0, *p = sa1; i <= 26; ++i) { if (binfo[i].n) *bend++ = p - sa1; binfo[i].p = p += binfo[i].n; }
		for (int i = 0; i <= n; ++i) *--binfo[text[i]].p = i;
		*bend = n + 1; ib1[n] = bend - buckets;
		for (int i = 0, j = 0; i <= n; ++i) { if (i >= buckets[j + 1]) ++j; ib1[sa1[i]] = j; }
	}

	for (int h = 1, m = n + 1; bend - buckets < m && h < m; h <<= 1)
	{
		for (int i = 0, x = m - h; i < m; ++i)
		{
			int j = (sufarr[i] + x) % m;
			sufarr2[buckets[ibuckets[j]]++] = j;
		}

		bend = buckets + 1;
		buckets[0] = 0;
		ibuckets2[sufarr2[0]] = 0;

		for (int i = 1, j = 0; i < m; ++i)
		{
			if (ibuckets[sufarr2[i]] != ibuckets[sufarr2[i - 1]]
			 || ibuckets[(sufarr2[i] + h) % m] != ibuckets[(sufarr2[i - 1] + h) % m])
			{
				++j;
				*bend++ = i;
			}

			ibuckets2[sufarr2[i]] = j;
		}

		int *p = ibuckets; ibuckets = ibuckets2; ibuckets2 = p;
		p = sufarr; sufarr = sufarr2; sufarr2 = p;
	}

	for (int i = 0; i < n; ++i)
	{
		//for (int j = sufarr[i]; j < n; ++j) putchar(text[j] + 'A' - 1);
		//putchar('\n');
		putchar(text[j] + 'A' - 1);
	}


	/*
	int t;
	scanf("%u ", &t);

	for (int i = 0; i < t; ++i)
	{
		char rune[101];
		gets(rune);
	}
	*/

	return 0;
}
