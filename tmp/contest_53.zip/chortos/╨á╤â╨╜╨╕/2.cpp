#include <stdio.h>
#include <string.h>

static char *prunes1[100000], *prunes2[100000];

static struct node
{
	int offset, len;
	struct node *start, *end;
	int first, last;
} pool[200000], *pend = pool;

static int state = 0;

static void make_trie(struct node *n, char **prunes, char **prunes_other, int first, int last, int i)
{
	//if (first <= 994 && last >= 992) printf("%p %p %p %i %i %i %c\n", n, prunes, prunes_other, first, last, i, n->c + ('A' - 1));
	//if (state == 1 && prunes[993][2]) { state = 2; printf("%p %p %p %i %i %i %c %c\n", n, prunes, prunes_other, first, last, i, n->c + ('A' - 1), prunes[993][2] + ('A' - 1)); }

	n->first = first;
	n->last = last;

	int j;
	if (i >= 100 || !prunes[n->first][n->offset + n->len - 1])
	{
		for (j = first; j <= last; ++j)
		{
			prunes_other[j] = prunes[j];
		}
		
		//if (!state && first == 993) { state = 1; printf("%p %p %p %i %i %i %c %c\n", n, prunes, prunes_other, first, last, i, n->c + ('A' - 1), prunes[993][2] + ('A' - 1)); }
		return;
	}

	union { int n; char **p; } prba[27];
	memset(prba, 0, sizeof prba);

	for (j = first; j <= last; ++j)
	{
		if (prunes[j][i]) ++prba[prunes[j][i] -= 'A' - 1].n;
		else ++prba[prunes[j][i]].n;
	}

	{
		char **p = prunes_other + first;

		for (j = 0; j <= 26; ++j)
		{
			prba[j].p = p += prba[j].n;
		}
	}

	for (j = last; j >= first; --j)
	{
		//if (prba[prunes[j][i]].p - 1 == prunes_other + 993) printf("%i %p %p %p %i %i %i %c %c ", j, n, prunes, prunes_other, first, last, i, n->c + ('A' - 1), prunes[j][i] + ('A' - 1));
		*--prba[prunes[j][i]].p = prunes[j];
		//if (prba[prunes[j][i]].p == prunes_other + 993) printf("%c\n", prunes_other[993][2] + ('A' - 1));
	}

	pend->offset = i;
	pend->len = 1;
	n->start = pend++;

	for (j = first + 1; j <= last; ++j)
	{
		if (prunes_other[j][i] != prunes_other[j - 1][i])
		{
			pend->offset = i;
			pend++->len = 1;
		}
	}

	n->end = pend;
	
	if (pend - n->start == 1)
	{
		--pend;
		++n->len;
		n->start = 0;
		make_trie(n, prunes_other, prunes, first, last, i + 1);
		return;
	}

	int newfirst = first;
	struct node *newn = n->start;

	for (j = first + 1; j <= last; ++j)
	{
		if (prunes_other[j][i] != prunes_other[j - 1][i])
		{
			make_trie(newn, prunes_other, prunes, newfirst, j - 1, i + 1);
			newfirst = j;
			++newn;
		}
	}

	make_trie(newn, prunes_other, prunes, newfirst, last, i + 1);
}

int main()
{
	char text[100001];
	gets(text);

	int t;
	scanf("%u ", &t);

	static char runes[100000][101];
	int i;
	for (i = 0; i < t; ++i) gets(prunes1[i] = runes[i]);

	struct node trie;
	trie.offset = 0;
	trie.len = 1;
	trie.start = trie.end = pool;
	trie.first = 0;

	make_trie(&trie, prunes1, prunes2, 0, t - 1, 0);
	// prunes1 is now sorted lexicographically
	
	/*
	static char *pr[100000];
	for (int i = 0; i < t; ++i) pr[i] = runes[i];
	sort(pr, pr + t, strlt());
	int fail = -1;
	for (int i = 0; i < t; ++i)
	{
/*		for (char *p = pr[i]; *p; ++p) putchar(*p + ('A' - 1));
		putchar('\n');
		for (char *p = prunes1[i]; *p; ++p) putchar(*p + ('A' - 1));
		putchar('\n');
* /		if (strcmp(pr[i], prunes1[i])) fail = i;
	}
	if (fail >= 0) { printf("%u\n", fail);
		for (char *p = pr[fail]; *p; ++p) putchar(*p + ('A' - 1));
		putchar('\n');
		for (char *p = prunes1[fail]; *p; ++p) putchar(*p + ('A' - 1));
		putchar('\n');
		return 3; }
	*/

	unsigned indexof[100000];
	memset(indexof, ~0, t * sizeof indexof[0]);

	char *p;
	for (p = text; *p; ++p) *p -= 'A' - 1;

	for (p = text; *p; ++p)
	{
		struct node *n = &trie;
		int offset = 1;
//		puts("restarting");

		char *q;
		for (q = p; (n->start || offset < n->len) && *q; ++q)
		{
			if (offset == n->len)
			{
				struct node *l = n->start, *r = n->end;

				while (l < r)
				{
					struct node *m = l + (r - l) / 2;
					//printf("%p %p %p\n", l, r, m);

					if (prunes1[m->first][m->offset] >= *q)
					{
						r = m;
					}
					else
					{
						l = m + 1;
					}
				}

//				printf("searched for %c, got %c at index %u\n", *q + ('A' - 1), r->c ? r->c + ('A' - 1) : '-', r - n->start);

				if (prunes1[l->first][l->offset] != *q) goto next;

				n = l;
				offset = 1;
			}
			else
			{
				if (prunes1[n->first][n->offset + offset] != *q) goto next;
				else ++offset;
			}

			if (offset == n->len && n->start && !prunes1[n->start->first][n->start->offset])
			{
				for (i = n->start->first; i <= n->start->last; ++i)
				{
					if ((unsigned) (p - text) < indexof[(char (*)[101]) prunes1[i] - runes]) indexof[(char (*)[101]) prunes1[i] - runes] = p - text;
				}
			}
			else if (!prunes1[n->first][n->offset + offset])
			{
				for (i = n->first; i <= n->last; ++i)
				{
					if ((unsigned) (p - text) < indexof[(char (*)[101]) prunes1[i] - runes]) indexof[(char (*)[101]) prunes1[i] - runes] = p - text;
				}
			}
		}

		if (!n->start && offset == n->len) for (i = n->first; i <= n->last; ++i)
		{
			if ((unsigned) (p - text) < indexof[(char (*)[101]) prunes1[i] - runes]) indexof[(char (*)[101]) prunes1[i] - runes] = p - text;
		}

	next:
		;
	}

	for (i = 0; i < t; ++i)
	{
		printf("%i\n", indexof[i]);
	}

//	printf("%i\n", pend - pool);
	return 0;
}
