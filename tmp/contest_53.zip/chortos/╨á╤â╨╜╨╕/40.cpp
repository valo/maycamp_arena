#include <stdio.h>
#include <string.h>

static char *prunes1[100000], *prunes2[100000];

static struct node
{
	char offset, len;
	struct node *start, *end;
	int first, last;
} pool[190000], *pend = pool;

//static int state = 0;
char **prunes[2];

static void make_trie(struct node *n, char i)
{
	//if (n->first <= 994 && n->last >= 992) printf("%p %p %p %i %i %i %c\n", n, prunes[i&1], prunes[!(i&1)], n->first, n->last, i, n->c + ('A' - 1));
	//if (state == 1 && prunes[i&1][993][2]) { state = 2; printf("%p %p %p %i %i %i %c %c\n", n, prunes[i&1], prunes[!(i&1)], n->first, n->last, i, n->c + ('A' - 1), prunes[i&1][993][2] + ('A' - 1)); }

	int j;
	if (i >= 100 || !prunes[i&1][n->first][n->offset + n->len - 1])
	{
		for (j = n->first; j <= n->last; ++j)
		{
			prunes[!(i&1)][j] = prunes[i&1][j];
		}

		//if (!state && n->first == 993) { state = 1; printf("%p %p %p %i %i %i %c %c\n", n, prunes[i&1], prunes[!(i&1)], n->first, n->last, i, n->c + ('A' - 1), prunes[i&1][993][2] + ('A' - 1)); }
		return;
	}

	static union { int n; char **p; } prba[27];
	memset(prba, 0, sizeof prba);

	for (j = n->first; j <= n->last; ++j)
	{
		if (prunes[i&1][j][i]) ++prba[prunes[i&1][j][i] -= 'A' - 1].n;
		else ++prba[prunes[i&1][j][i]].n;
	}

	{
		char **p = prunes[!(i&1)] + n->first;

		for (j = 0; j <= 26; ++j)
		{
			prba[j].p = p += prba[j].n;
		}
	}

	for (j = n->last; j >= n->first; --j)
	{
		//if (prba[prunes[i&1][j][i]].p - 1 == prunes[!(i&1)] + 993) printf("%i %p %p %p %i %i %i %c %c ", j, n, prunes[i&1], prunes[!(i&1)], n->first, n->last, i, n->c + ('A' - 1), prunes[i&1][j][i] + ('A' - 1));
		*--prba[prunes[i&1][j][i]].p = prunes[i&1][j];
		//if (prba[prunes[i&1][j][i]].p == prunes[!(i&1)] + 993) printf("%c\n", prunes[!(i&1)][993][2] + ('A' - 1));
	}

	pend->offset = i;
	pend->len = 1;
	n->start = pend++;

	for (j = n->first + 1; j <= n->last; ++j)
	{
		if (prunes[!(i&1)][j][i] != prunes[!(i&1)][j - 1][i])
		{
			pend->offset = i;
			pend++->len = 1;
		}
	}

	n->end = pend;

	if (pend - n->start == 1)
	{
		--pend;
		++n->len;
		n->start = 0;
		make_trie(n, i + 1);
		return;
	}

	int newfirst = n->first;
	struct node *newn = n->start;

	for (j = n->first + 1; j <= n->last; ++j)
	{
		if (prunes[!(i&1)][j][i] != prunes[!(i&1)][j - 1][i])
		{
			newn->first = newfirst;
			newn->last = j - 1;
			make_trie(newn, i + 1);
			newfirst = j;
			++newn;
		}
	}

	newn->first = newfirst;
	newn->last = n->last;
	make_trie(newn, i + 1);
}

int main(void)
{
	char text[100002];
	gets(text);
	if (text[strlen(text) - 1] == '\r') text[strlen(text) - 1] = '\0';

	int t;
	scanf("%u ", &t);

	static char runes[100000][102];
	int i;
	for (i = 0; i < t; ++i) { gets(prunes1[i] = runes[i]); if (strchr(runes[i], '\r')) *strchr(runes[i], '\r') = '\0'; }

	struct node trie;
	trie.offset = 0;
	trie.len = 1;
	trie.start = trie.end = pool;
	trie.first = 0;
	trie.last = t - 1;

	prunes[0] = prunes1;
	prunes[1] = prunes2;
	make_trie(&trie, 0);
	// prunes1 is now sorted lexicographically

	/*
	static char *pr[100000];
	for (int i = 0; i < t; ++i) pr[i] = runes[i];
	sort(pr, pr + t, strlt());
	int fail = -1;
	for (int i = 0; i < t; ++i)
	{
/*		for (char *p = pr[i]; *p; ++p) putchar(*p + ('A' - 1));
		putchar('\n');
		for (char *p = prunes1[i]; *p; ++p) putchar(*p + ('A' - 1));
		putchar('\n');
* /		if (strcmp(pr[i], prunes1[i])) fail = i;
	}
	if (fail >= 0) { printf("%u\n", fail);
		for (char *p = pr[fail]; *p; ++p) putchar(*p + ('A' - 1));
		putchar('\n');
		for (char *p = prunes1[fail]; *p; ++p) putchar(*p + ('A' - 1));
		putchar('\n');
		return 3; }
	*/

	unsigned indexof[100000];
	memset(indexof, ~0, t * sizeof indexof[0]);

	char *p;
	for (p = text; *p; ++p) *p -= 'A' - 1;

	for (p = text; *p; ++p)
	{
		struct node *n = &trie;
		int offset = 1;
//		puts("restarting");

		char *q;
		for (q = p; (n->start || offset < n->len) && *q; ++q)
		{
			if (offset == n->len)
			{
				struct node *l = n->start, *r = n->end;

				while (l < r)
				{
					struct node *m = l + (r - l) / 2;
					//printf("%p %p %p\n", l, r, m);

					if (prunes1[m->first][m->offset] >= *q)
					{
						r = m;
					}
					else
					{
						l = m + 1;
					}
				}

//				printf("searched for %c, got %c at index %u\n", *q + ('A' - 1), r->c ? r->c + ('A' - 1) : '-', r - n->start);

				if (prunes1[l->first][l->offset] != *q) goto next;

				n = l;
				offset = 1;
			}
			else
			{
				if (prunes1[n->first][n->offset + offset] != *q) goto next;
				else ++offset;
			}

			if (offset == n->len && n->start && !prunes1[n->start->first][n->start->offset])
			{
				for (i = n->start->first; i <= n->start->last; ++i)
				{
					if ((unsigned) (p - text) < indexof[(char (*)[102]) prunes1[i] - runes]) indexof[(char (*)[102]) prunes1[i] - runes] = p - text;
				}
			}
			else if (!prunes1[n->first][n->offset + offset])
			{
				for (i = n->first; i <= n->last; ++i)
				{
					if ((unsigned) (p - text) < indexof[(char (*)[102]) prunes1[i] - runes]) indexof[(char (*)[102]) prunes1[i] - runes] = p - text;
				}
			}
		}

		if (!n->start && offset == n->len) for (i = n->first; i <= n->last; ++i)
		{
			if ((unsigned) (p - text) < indexof[(char (*)[102]) prunes1[i] - runes]) indexof[(char (*)[102]) prunes1[i] - runes] = p - text;
		}

	next:
		;
	}

	for (i = 0; i < t; ++i)
	{
		printf("%i\n", indexof[i]);
	}

//	printf("%i\n", pend - pool);
	return 0;
}
