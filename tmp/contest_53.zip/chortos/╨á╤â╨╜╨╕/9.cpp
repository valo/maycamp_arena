#include <stdio.h>
#include <string.h>

int main(void)
{
	char text[100001];
	gets(text);

	int n = strlen(text);

	static int sa[100000], tmp[100000], ib[100001], buckets[100001], *sufarr = sa, *temp = tmp, *ibuckets = ib, *bend = buckets;

	{
		union { int n, *p; } binfo[27] = { 0 };
		for (int i = 0; i < n; ++i) ++binfo[text[i] -= 'A' - 1].n;
		return 0;
		++binfo[0].n;
		for (int i = 0, *p = sa; i <= 26; ++i) { if (binfo[i].n) *bend++ = p - sa; binfo[i].p = p += binfo[i].n; }
		for (int i = 0; i <= n; ++i) *--binfo[text[i]].p = i;
		*bend = n + 1; ib[n] = bend - buckets;
		for (int i = 0, j = 0; i <= n; ++i) { if (i >= buckets[j + 1]) ++j; ib[sa[i]] = j; }
	}

	for (int h = 1, m = n + 1; bend - buckets < m && h < m; h <<= 1)
	{
		for (int i = 0, x = m - h; i < m; ++i)
		{
			int j = (sufarr[i] + x) % m;
			temp[buckets[ibuckets[j]]++] = j;
		}

		int *p = sufarr; sufarr = temp; temp = p;

		bend = buckets + 1;
		buckets[0] = 0;
		temp[sufarr[0]] = 0;

		for (int i = 1, j = 0; i < m; ++i)
		{
			if (ibuckets[sufarr[i]] != ibuckets[sufarr[i - 1]]
			 || ibuckets[(sufarr[i] + h) % m] != ibuckets[(sufarr[i - 1] + h) % m])
			{
				++j;
				*bend++ = i;
			}

			temp[sufarr[i]] = j;
		}

		p = ibuckets; ibuckets = temp; temp = p;
	}

	int t;
	scanf("%u ", &t);

	char runes[100000][101];
	for (int i = 0; i < t; ++i) gets(runes[i]);

	return 0;
}
