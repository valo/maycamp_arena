/*
TASK:runes
LANG:C++
*/
//#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define razm 131072
using namespace std;
// RMQ DEFINITIONS
int mini(int a,int b){return (a<b)?a:b;}
int maxi(int a,int b){return (a>b)?a:b;}
struct rmq{
  int tree[2*razm];
  void push(int p,int w){
	p+=razm;tree[p]=w;
	p/=2;
	while(p>0){
	 tree[p]=((tree[2*p]<tree[2*p+1])?tree[2*p]:tree[2*p+1]);
	 p/=2;
			  }
				        }
  int get(int f,int t){
   f+=razm;t+=razm;
   int pf,pt,ans=mini(tree[f],tree[t]);
   while(1){
	pf=f/2;pt=t/2;
	if(pf==pt)break;
	if(2*pf==f)ans=mini(ans,tree[f+1]);
	if(2*pt+1==t)ans=mini(ans,tree[t-1]);
    f=pf;t=pt;
		   }
   return ans;
					  }
};
// </end>
char beg[100100];int bl;
int get(int p,int move){return(p+bl+move)%bl;}
int r[100010],ig[100010],gi[100010];
int nr[100010],nig[100010];
class compare{
 public:bool operator()(const int& a,const int& b)const{return(beg[a]<beg[b]);}
};
void create_suffix_array(){
  int i,j,k,l;
  for(i=0;i<bl;i++)r[i]=i;
  sort(r,r+bl,compare());
  ig[r[0]]=0;gi[0]=0;
  for(i=1;i<bl;i++)
   if(beg[r[i]]==beg[r[i-1]])ig[r[i]]=ig[r[i-1]];
   else{ig[r[i]]=i;gi[i]=i;}
  bool need_work=true;
  for(l=1;;l*=2){
	for(i=0;i<bl;i++){
	 nr[gi[ig[get(r[i],-l)]]]=get(r[i],-l);
	 gi[ig[get(r[i],-l)]]++;
					 }
	need_work=false;
	nig[nr[0]]=0;gi[0]=0;
	for(i=1;i<bl;i++)
	 if((ig[nr[i]]!=ig[nr[i-1]]) ||
	    (ig[nr[i]]==ig[nr[i-1]] && ig[get(nr[i],l)]!=ig[get(nr[i-1],l)])){
		 nig[nr[i]]=i;gi[i]=i;
																		 }
                
	 else{nig[nr[i]]=nig[nr[i-1]];need_work=true;}
	for(i=0;i<bl;i++){r[i]=nr[i];ig[i]=nig[i];}
	if(!need_work)break;
				}
   
}
void init_lcp(){ // use nr as lcp, nig as indexes
 int i,j,l,last;
 for(i=0;i<bl;i++)nig[r[i]]=i;// kude pochva
 last=-1;
 for(i=0;i<bl;i++){
   l=nig[i];
   if(l==bl-1){last=-1;nr[l]=0;}
   else{
  	for(j=maxi(0,last);;j++)if(beg[r[l]+j]!=beg[r[l+1]+j])break;
  	last=j-1;nr[l]=j;
	   }
			 	  }
}
rmq lcp,ind;
char data[110];int dl;
int bin_find(int f,int t,int sf){
  //cout<<f<<' '<<t;system("pause");
  int i,mid;
  if(t-f<2){
   for(i=0;i<dl;i++)
    if(beg[r[f]+i]>data[i])return f;
    else{if(beg[r[f]+i]<data[i])return t;}
   return f;
		   }
  sf=mini(sf,lcp.get(f,t-1));
  mid=(f+t)/2;
  //cout<<mid<<' '<<beg[r[mid]]<<' '<<data[0];system("pause");
  for(i=sf;i<dl;i++)if(beg[r[mid]+i]!=data[i])break;
  //cout<<"!"<<i;system("pause");
  if(beg[r[mid]+i]>=data[i])return bin_find(f,mid,i);
  else return bin_find(mid,t,i);
}
int main(){
  int i,j,k,l,b,e;
  //system("pause");
  scanf("%s",&beg);
  bl=strlen(beg);beg[bl]=0;bl++;
  create_suffix_array();
  //for(i=0;i<bl;i++){
  // for(j=r[i];j<bl;j++)cout<<beg[j];
  // cout<<'\n';
  //				   }
  init_lcp();
  for(i=0;i<bl;i++){lcp.push(i,nr[i]);ind.push(i,r[i]);}
  scanf("%d",&l);
  bool found;
  for(k=0;k<l;k++){
    scanf("%s",&data);
    dl=strlen(data);data[dl]=0;dl++;
    b=bin_find(0,bl,0);
    data[dl-1]='Z'+10;
    e=bin_find(0,bl,0);
    dl--;
    found=true;
	for(i=0;i<dl;i++)if(beg[r[b]+i]!=data[i]){found=false;break;}
	if(!found)printf("-1\n");
	else printf("%d\n",ind.get(b,e-1));
                  }
  //system("pause");
  return 0;
}
