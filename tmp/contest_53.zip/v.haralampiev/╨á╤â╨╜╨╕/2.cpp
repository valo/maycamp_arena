#include <cstdio>
#include <cstring>
#define RAZM 100001
#define null NULL
using namespace std;
struct pci{char d;int s;pci* nasl;pci(){}pci(char D,int S){d=D;s=S;nasl=null;}};
struct elem{
  pci* root;elem(){root=null;}
  pci* get(char w){for(pci* it=root;it!=null;it=it->nasl)if(it->d==w)return it;return null;}
  void push(char w,int p){pci* tmp=new pci(w,p);tmp->nasl=root;root=tmp;}
};
void e_copy(elem& f,elem& t){ // from->to
  for(pci* it=f.root;it!=null;it=it->nasl)t.push(it->d,it->s);
}
struct data{
  int len,link;
  elem next;
};
data aut[2*RAZM];
int fm[2*RAZM];
int last(0),sz(1);
void free_all(){
  for(int i=0;i<2*RAZM;i++){
   pci* p=aut[i].next.root;
   while(p!=null){pci* T=p;p=p->nasl;delete(T);}
                           }
}
void init(){aut[last].len=0;aut[last].link=-1;}
void aut_add(char w){
  int nlast=(sz++);
  aut[nlast].len=aut[last].len+1;fm[nlast]=aut[last].len;
  int p=last;
  for(;p!=-1 && aut[p].next.get(w)==null;p=aut[p].link)aut[p].next.push(w,nlast);
  if(p==-1)aut[nlast].link=0;
  else{
   int q=(aut[p].next.get(w))->s;
   if(aut[p].len+1==aut[q].len)aut[nlast].link=q;
   else{
    int clone=(sz++);
    aut[clone].len=aut[p].len+1;aut[clone].link=aut[q].link;fm[clone]=fm[q];
    aut[nlast].link=aut[q].link=clone;
    e_copy(aut[q].next,aut[clone].next);
    pci* TMP;
    for(;p!=-1 && (TMP=aut[p].next.get(w))->s==q;p=aut[p].link) TMP->s=clone;
       }
      }
  last=nlast;
}
char vhod[RAZM];int n;
void create_aut(){init();for(int i=0;i<n;i++)aut_add(vhod[i]);}
char obr[110];
int find(){
  int i,p(0),l;
  pci* TMP;
  scanf("%s",&obr);l=strlen(obr);
  for(i=0;i<l;i++){
   TMP=aut[p].next.get(obr[i]);
   if(TMP==null)return -1;
   else p=TMP->s;
                  }
  return (fm[p]-l+1);
}
int main(){
  int i,j;
  scanf("%s",&vhod);n=strlen(vhod);
  create_aut();
  int Q;scanf("%d",&Q);
  while(Q>0){Q--;printf("%d\n",find());}
  free_all();
  return 0;
}
