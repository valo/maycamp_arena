/*
TASK:compression
LANG:C++
*/
#include <iostream>
#include <fstream>
#include <cstdio>
#include <vector>
#include <set>
#include <string>
#include <cstring>
#define null NULL
using namespace std;
struct vrux{
 int st;char c;vrux *L,*R;
 bool operator<(const vrux w)const{
   if(st<(w.st))return true;if(st>(w.st))return false;
   return (c<w.c);
                                   }
 vrux(){L=R=NULL;st=0;}
};
class compare{
  public:
  bool operator()(const vrux* a,const vrux* b)const{return((*a)<(*b));}
};
set<vrux* ,compare>use;
set<vrux* ,compare>::iterator it1,it2;
int s2[10]={1,2,4,8,16};
int i_decode(string w){
  return ((w[0]-'0')*s2[4]+(w[1]-'0')*s2[3]+(w[2]-'0')*s2[2]+(w[3]-'0')*s2[1]
         +(w[4]-'0')*s2[0]);
}
string i_code(int w){
  int i,j;string ret="";
  for(i=4;i>=0;i--){
	ret+=(char)((w/s2[i])+'0');
	w%=s2[i];
				   }
  return ret;
}
vrux* root=null;
string put[30];
string path;
void init_put(vrux* vr){
  if(vr->L==NULL){
   put[vr->c-'a']=path;
   return;
				 }
  path.push_back('1');init_put(vr->L);path.erase(path.end()-1);
  path.push_back('0');init_put(vr->R);path.erase(path.end()-1);
}
void del_tree(vrux* p){
  if(p->L!=null)del_tree(p->L);
  if(p->R!=null)del_tree(p->R);
  delete(p);
  return;
}
// CODING PART
int chestoti[30];
char inp[1000010];int il;
void code(){
  //freopen("compression.in","r",stdin);
  //freopen("compression.cmp","w",stdout);
  FILE* rfile=fopen("compression.in","r");
  ofstream fout("compression.cmp");
  use.clear();path.clear();
  int i,j,k;
  vrux *tmp1,*tmp2,*tmp3;
  for(i=0;i<30;i++){chestoti[i]=0;put[i]="";}
  root=null;
  fscanf(rfile,"%s",&inp);il=strlen(inp);
  for(i=0;i<il;i++)chestoti[inp[i]-'a']++;
  for(i=0;i<26;i++)
   if(chestoti[i]>0){
	tmp1=new(vrux);tmp1->c=(char)(i+'a');tmp1->st=chestoti[i];
	use.insert(tmp1);
					}
  while(use.size()>1){
	it1=use.begin();tmp1=*it1;use.erase(it1);
	it1=use.begin();tmp2=*it1;use.erase(it1);
	tmp3=new(vrux);tmp3->L=tmp1;tmp3->R=tmp2;
	tmp3->st=tmp2->st+tmp1->st;
	use.insert(tmp3);
					 }
  root=*use.begin();
  init_put(root);
  del_tree(root);
  for(i=0;i<26;i++){fout<<i_code(put[i].size())<<put[i];}
  for(i=0;i<il;i++)fout<<put[inp[i]-'a'];
  //fout<<'\n';
  fout.close();fclose(rfile);
}
// DECODING PART
void push_tree(string w,char ucode){
  if(root==null){root=new(vrux);}
  vrux* p=root;
  int i,j;
  for(i=0;i<w.size();i++){
   if(w[i]=='0'){
	if(p->R==NULL)p->R=new(vrux);
	p=p->R;
				}
   if(w[i]=='1'){
 	 if(p->L==NULL)p->L=new(vrux);
	 p=p->L;
				}
						 }
  p->c=ucode;
}
void decode(){
 FILE *rfile,*wfile;
 rfile=fopen("compression.cmp","r");
 wfile=fopen("compression.out","w");
 //freopen("compression.cmp","r",stdin);
 //freopen("compression.out","w",stdout);
 char a1,a2,a3,a4,a5;
 int i,j,k,l;
 string tmp;
 for(i=0;i<26;i++){
  fscanf(rfile,"%c%c%c%c%c",&a1,&a2,&a3,&a4,&a5);
  tmp.clear();tmp+=a1;tmp+=a2;tmp+=a3;tmp+=a4;tmp+=a5;
  l=i_decode(tmp);
  tmp.clear();
  for(j=0;j<l;j++){fscanf(rfile,"%c",&a1);tmp.push_back(a1);}
  put[i]=tmp;
				  }
 root=null;
 for(i=0;i<26;i++)push_tree(put[i],(char)(i+'a'));
 vrux* p=root;
 while(fscanf(rfile,"%c",&a1)!=EOF){
   if(a1!='0'&&a1!='1')continue;
   if(a1=='0')p=p->R;
   else p=p->L;
   if(p->L==null || p->R==null){
    fprintf(wfile,"%c",p->c);
    p=root;
							   }
							}
 fprintf(wfile,"\n");
 del_tree(root);
 fclose(wfile);fclose(rfile);
}
int main(){
  //system("pause");
  string inp;
  cin>>inp;
  if(inp[0]=='c' || inp[0]=='C')code();
  else decode();
  //system("pause");
  return 0;
}
