#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <set>
#include <deque>
#include <string>
#define null NULL
using namespace std;
map<char,string> fp;
// TREE DEFINITIONS
struct vrux{
  int BR,ind;vrux *l,*r;char dig;
};
class compare{
  public:
  bool operator()(const vrux* w1,const vrux* w2)const{
   if((w1->BR)<(w2->BR))return true;if((w1->BR)>(w2->BR))return false;
   return ((w1->ind)<(w2->ind));
                                    }
};
deque<vrux*> for_free;
vrux* new_vrux(int how=0,char label='#'){
  vrux* tmp=new(vrux);tmp->l=tmp->r=null;
  tmp->BR=how;tmp->dig=label;tmp->ind=for_free.size();
  for_free.push_back(tmp);
  return tmp;
}
void free_all(){for(int i=0;i<for_free.size();i++)delete(for_free[i]);}
vrux* root=null;
string path;
void dfs(vrux* p){
  if(p->l==null || p->r==null){fp[p->dig]=path;return;}
  path.push_back('0');dfs(p->l);path.erase(path.size()-1);
  path.push_back('1');dfs(p->r);path.erase(path.size()-1);
}
// output operations
deque<char> out;
void print_int(int w){
  out.clear();
  for(int i=0;i<5;i++){out.push_front((char)(w%2)+'0');w/=2;}
  for(int i=0;i<5;i++)printf("%c",out[i]);
}
void print_char(char w){
  string buf=fp[w];
  for(int i=0;i<buf.size();i++)printf("%c",buf[i]);
}
int read_int(){
 int ret=0;char j;
 for(int i=0;i<5;i++){scanf("%c",&j);if(j!='0' && j!='1'){i--;continue;}ret*=2;ret+=(j-'0');}
 return ret;
}
void read_code(char w){
  string red;int s=read_int();char T;
  for(int i=0;i<s;i++){scanf("%c",&T);if(T!='0' && T!='1'){i--;continue;}red.push_back(T);}
  fp[w]=red;
}
// </end>
// CODE SEQUENCE
char vhod[1000010];
map<char,int> rate;map<char,int>::iterator it;
set<vrux*,compare> act;
void code(){
  int i,j,k,l;
  scanf("%s",&vhod);l=strlen(vhod);
  for(i=0;i<l;i++)rate[vhod[i]]++;
  for(it=rate.begin();it!=rate.end();it++)act.insert(new_vrux(it->second,it->first));
  vrux *v1,*v2;
  while(act.size()>1){
   v1=*(act.begin());act.erase(act.begin());
   v2=*(act.begin());act.erase(act.begin());
   vrux* TMP=new_vrux(v1->BR+v2->BR);
   TMP->l=v1;TMP->r=v2;
   act.insert(TMP);
                     }
  root=*(act.begin());
  dfs(root);
  for(char I='a';I<='z';I++){
   print_int(fp[I].size());
   print_char(I);
                            }
  for(i=0;i<l;i++)print_char(vhod[i]);
  free_all();
}
// DECODE SEQUENCE
void push_tree(string w,char D){
  if(w.empty())return;
  vrux* p=root;
  for(int i=0;i<w.size();i++){
   if(w[i]=='0'){
    if(p->l==null){p->l=new_vrux();p->r=new_vrux();}
    p=p->l;
                }
   else{
    if(p->r==null){p->l=new_vrux();p->r=new_vrux();}
    p=p->r;  
       }
                             }
  p->dig=D;
}
void decode(){
  int i,j;char T;
  root=new_vrux();
  for(T='a';T<='z';T++){
    read_code(T);
    push_tree(fp[T],T);
                       }
  vrux* p=root;
  while(scanf("%c",&T)!=EOF){
   if(T!='0' && T!='1')continue;
   if(T=='0'){
    p=p->l;
    if(p->l==null){printf("%c",p->dig);p=root;}
             }
   else{
    p=p->r;
    if(p->r==null){printf("%c",p->dig);p=root;} 
       }
                            }
  free_all();
}
int main(){
  string QUERRY;
  cin>>QUERRY;
  if(QUERRY[0]=='C' || QUERRY[0]=='c'){
    freopen("compression.in","r",stdin);
    freopen("compression.cmp","w",stdout);
    code();
                                      }
  else{
    freopen("compression.cmp","r",stdin);
    freopen("compression.out","w",stdout);
    decode(); 
      }
  return 0;
}
