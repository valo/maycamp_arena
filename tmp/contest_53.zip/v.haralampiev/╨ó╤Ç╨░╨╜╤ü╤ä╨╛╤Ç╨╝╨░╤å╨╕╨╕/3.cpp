#include <iostream>
using namespace std;
typedef long long ll;
ll step[55];
ll n,m,ans=1E15;
void try_state(int ms){
  ll mp=m-n*step[ms];
  ll tans=ms,tmp;
  if(mp<0)return;
  for(int i=ms;i>=0;i--){
   tmp=mp/step[i];
   tans+=(tmp/2+tmp%2);
   mp%=step[i];
                        }
  if(tans<ans)ans=tans;
}
int main(){
  int i,j,k,l;
  //system("pause");
  cin>>n>>m;
  step[0]=1;
  for(i=1;i<51;i++)step[i]=step[i-1]<<1;
  ll ub;
  if(n!=0)ub=m/n;
  else ub=step[50];
  for(j=0;j<51;j++)if(step[j]>ub)break;
  if(j>0)j--;
  for(i=0;i<=j;i++)try_state(i);
  cout<<ans<<'\n';
  //system("pause");
  return 0;
}
