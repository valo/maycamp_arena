#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main ()
{
	long long int N, M;
	scanf("%lli %lli",&N,&M);
	long long int res = 0;
	long long int dist, num, mv;
	num = M;
	while (((num/2) >= N) && ((num/2) > 0))
	{
		res++;
		if (num % 2)
		{
			res++;
		}
		num /= 2;
	}
	long long int add = num - N;
	res += (add / 2);
	if (add % 2) res++;
	long long int total = res;
	res = 0;
	num = M;
	while (((num/2) >= N) && ((num/2) > 0))
	{
		dist = num - N;
		mv = (dist / 2) + (dist % 2);
		if ((res + mv) < total) total = res + mv;
		res++;
		if (num % 2)
		{
			res++;
		}
		num /= 2;
	}
	printf("%lli\n",total);
	return 0;
}
