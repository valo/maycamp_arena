#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAXLEN 100005
#define INFINITY 2000000000

int Mod (int a, int N)
{
	return (a + 2 * N) % N;
}

int main ()
{
	static char data[MAXLEN];
	scanf("%s\n",data);
	static char ss[MAXLEN][105];
	int T;
	scanf("%d\n",&T);
	int i;
	for (i = 0; i < T; i++)
	{
		scanf("%s\n",ss[i]);
	}
	int N;
	N = strlen(data);
	data[N] = '[';
	data[N+1] = 0;
	N++;
	static int pa[MAXLEN];
	static int pa2[MAXLEN];
	int *a = pa;
	int *a2 = pa2;
	int *temp;
	static int w[MAXLEN];
	static int pg[MAXLEN];
	static int pg2[MAXLEN];
	int *g = pg;
	int *g2 = pg2;
	static int ph[MAXLEN];
	static int ph2[MAXLEN];
	int *h = ph;
	int *h2 = ph2;
	static int ps[MAXLEN];
	int *s = ps;
	int bc = 1;
	static int cnt[256];
	memset(cnt,0,sizeof(cnt));
	for (i = 0; i < N; i++) cnt[(int)(data[i])]++;
	for (i = 1; i < 256; i++) cnt[i] += cnt[i-1];
	for (i = 0; i < N; i++)
	{
		cnt[(int)(data[i])]--;
		a[cnt[(int)(data[i])]] = i;
		w[i] = cnt[(int)(data[i])];
	}
	s[0] = 0;
	for (i = 0; i < (N-1); i++)
	{
		g[i] = bc - 1;
		if (data[a[i]] != data[a[i+1]])
		{
			s[bc] = i+1;
			bc++;
		}
	}
	g[N-1] = bc - 1;

	int newnum, newg;
	int len = 1;
	while (bc < N)
	{
		for (i = 0; i < N; i++)
		{
			newnum = Mod(a[i]-len,N);
			newg = g[w[newnum]];
			a2[s[newg]] = newnum;
			s[newg]++;
		}

		bc = 1;
		s[0] = 0;
		for (i = 0; i < (N-1); i++)
		{
			g2[i] = bc - 1;
			if ((g[w[a2[i]]] != g[w[a2[i+1]]]) || ((g[w[a2[i]]] == g[w[a2[i+1]]]) && (g[w[(a2[i]+len) % N]] != g[w[(a2[i+1]+len) % N]])))
			{
				s[bc] = i+1;
				bc++;
			}
		}
		g2[N-1] = bc - 1;

		temp = g2; g2 = g; g = temp;
		temp = a2; a2 = a; a = temp;

		for (i = 0; i < N; i++)
		{
			w[a[i]] = i;
		}

		len *= 2;
	}

	temp = s; s = a; a = temp;
	static int res[MAXLEN];
	int rc = 0;

	while (rc < T)
	{
		
		rc++;
	}

	return 0;
}
