#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAXLEN 100005
#define INFINITY 2000000000

struct node
{
	int l, r, ls, rs, val;
};

int Mod (int a, int N)
{
	return (a + 2 * N) % N;
}

void InitTree (struct node a[2*MAXLEN], int point, int vals[MAXLEN])
{
	if (a[point].ls == -1)
	{
		a[point].val = vals[a[point].l];
	}
	else
	{
		InitTree(a,a[point].ls,vals);
		InitTree(a,a[point].rs,vals);
		if (a[a[point].ls].val < a[a[point].rs].val) a[point].val = a[a[point].ls].val;
		else a[point].val = a[a[point].rs].val;
	}
}

int FindMin (struct node a[2*MAXLEN], int point, int l, int r)
{
	if ((a[point].l >= l) && (a[point].r <= r)) return a[point].val;
	int min = INFINITY;
	int temp;
	if (a[a[point].rs].l <= r)
	{
		temp = FindMin(a,a[point].rs,l,r);
		if (temp < min) min = temp;
	}
	if (a[a[point].ls].r >= l)
	{
		temp = FindMin(a,a[point].ls,l,r);
		if (temp < min) min = temp;
	}
	return min;
}

int main ()
{
	static char data[MAXLEN];
	scanf("%s\n",data);
	int N;
	N = strlen(data);
	data[N] = '[';
	data[N+1] = 0;
	N++;
	static int a[MAXLEN];
	static int a2[MAXLEN];
	static int w[MAXLEN];
	static int g[MAXLEN];
	static int g2[MAXLEN];
	static int s[MAXLEN];
	int bc = 1;
	static int cnt[256];
	memset(cnt,0,sizeof(cnt));
	int i;
	for (i = 0; i < N; i++) cnt[(int)(data[i])]++;
	for (i = 1; i < 256; i++) cnt[i] += cnt[i-1];
	for (i = 0; i < N; i++)
	{
		cnt[(int)(data[i])]--;
		a[cnt[(int)(data[i])]] = i;
		w[i] = cnt[(int)(data[i])];
	}
	s[0] = 0;
	for (i = 0; i < (N-1); i++)
	{
		g[i] = bc - 1;
		if (data[a[i]] != data[a[i+1]])
		{
			s[bc] = i+1;
			bc++;
		}
	}
	g[N-1] = bc - 1;

	int newnum, newg;
	int len = 1;
	while (bc < N)
	{
		for (i = 0; i < N; i++)
		{
			newnum = Mod(a[i]-len,N);
			newg = g[w[newnum]];
			a2[s[newg]] = newnum;
			s[newg]++;
		}

		bc = 1;
		s[0] = 0;
		for (i = 0; i < (N-1); i++)
		{
			g2[i] = bc - 1;
			if ((g[w[a2[i]]] != g[w[a2[i+1]]]) || ((g[w[a2[i]]] == g[w[a2[i+1]]]) && (g[w[(a2[i]+len) % N]] != g[w[(a2[i+1]+len) % N]])))
			{
				s[bc] = i+1;
				bc++;
			}
		}
		g2[N-1] = bc - 1;

		memcpy(a,a2,sizeof(a2));
		memcpy(g,g2,sizeof(g2));

		for (i = 0; i < N; i++)
		{
			w[a[i]] = i;
		}

		len *= 2;
	}

	static struct node tr[2*MAXLEN];
	int r, wr;
	r = 0; wr = 1;
	tr[0].l = 0;
	tr[0].r = N-1;
	tr[0].ls = -1;
	tr[0].rs = -1;
	tr[0].val = 0;
	while (wr > r)
	{
		if (tr[r].r > tr[r].l)
		{
			tr[wr].l = tr[r].l;
			tr[wr].r = (tr[r].l + tr[r].r) / 2;
			tr[wr].ls = -1;
			tr[wr].rs = -1;
			tr[wr].val = 0;
			tr[r].ls = wr;
			wr++;
			tr[wr].l = tr[wr-1].r + 1;
			tr[wr].r = tr[r].r;
			tr[wr].ls = -1;
			tr[wr].rs = -1;
			tr[wr].val = 0;
			tr[r].rs = wr;
			wr++;
		}
		r++;
	}
	InitTree(tr,0,a);

	int l, c, L, R, p1, p2;
	static char str[MAXLEN];
	int M;
	int T;
	scanf("%d\n",&T);
	int iT;
	for (iT = 0; iT < T; iT++)
	{
		L = 0; R = N;
		scanf("%s\n",str);
		M = strlen(str);
		for (i = 0; i < M; i++)
		{
			l = L;
			r = R-1;
			while (r > l)
			{
				c = (l + r) / 2;
				if (data[(a[c] + i) % N] >= str[i]) r = c;
				else l = c + 1;
			}
			p1 = l;
			if (data[(a[p1] + i) % N] < str[i]) p1++;

			l = L;
			r = R-1;
			while (r > l)
			{
				c = (l + r) / 2;
				if (data[(a[c] + i) % N] > str[i]) r = c;
				else l = c + 1;
			}
			p2 = l;
			if (data[(a[p2] + i) % N] <= str[i]) p2++;

			L = p1;
			R = p2;
			if (L == R) break;
		}
		//printf("(%d; %d)\n",L,R);
		if (L == R) printf("-1\n");
		else printf("%d\n",FindMin(tr,0,L,R-1));
	}

/*
	for (i = 0; i < N; i++)
	{
		printf("%s\n",&(data[a[i]]));
	}
*/


	return 0;
}
