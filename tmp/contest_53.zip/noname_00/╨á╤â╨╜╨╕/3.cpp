/*
TASK: runes
SOURCE: Kontrolno 1 2010
*/

#include <cstdio>
#include <vector>
#include <cstring>
#include <utility>
#include <algorithm>

using namespace std;

const int MAX = 100001;
const unsigned b = 251;

struct Word {
	
	char w[101];
	int idx;
	unsigned hv;
	
	inline bool operator< ( const Word &t ) const {
		return hv < t.hv;
		}
	
} word;

int T, L, res[MAX];
char s[MAX];
vector < Word > v[101];
unsigned hash[MAX], p[MAX];

int main (void) {
	
	memset ( res, -1, sizeof res );
	
	scanf ( "%s%d", s, &T );
	L = strlen ( s );
	
	int l;
	word.hv = 0;
	for ( int i=0; i<T; ++i ) {
		
		scanf ( "%s", word.w );
		l = strlen ( word.w );
		word.idx = i;
		v[l].push_back ( word );
		
		}
	
	p[0] = 1;
	for ( int i=1; i<MAX; ++i ) p[i] = p[i-1] * b;
	
	hash[0] = 1;
	for ( int i=1; i<=L; ++i ) hash[i] = hash[i-1] + p[i] * s[i-1];
	
	Word th;
	pair < vector < Word > :: iterator, vector < Word > :: iterator > pos;
	int p1, p2;
	for ( int len=1; len<101; ++len ) if ( !v[len].empty () ) {
		
		for ( int i=0; i<(int)v[len].size (); ++i )	{
			for ( int j=1; j<=len; ++j ) v[len][i].hv += p[j] * v[len][i].w[j-1];
			v[len][i].hv *= p[ L-len ];
			}
		sort ( v[len].begin (), v[len].end () );
		
		for ( int st=len; st<=L; ++st ) {
			
			th.hv = ( hash[st]-hash[st-len] ) * p[ L-st ];
			
			pos = equal_range ( v[len].begin (), v[len].end (), th );
			p1 = pos.first - v[len].begin (); p2 = pos.second - v[len].begin ();
			if ( v[len][p1].hv == th.hv && res[ v[len][p1].idx ] < 0 ) 
				for ( int pp=p1; pp<p2; ++pp ) 
					res[ v[len][pp].idx ] = st-len;
			
			}
		
		}
	
	for ( int i=0; i<T; ++i ) printf ( "%d\n", res[i] );
}
