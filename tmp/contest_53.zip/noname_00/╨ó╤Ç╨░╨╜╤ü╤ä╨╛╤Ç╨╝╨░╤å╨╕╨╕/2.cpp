/*
TASK: transform
SOURCE: Kontrolno 1 2010
*/

#include <cstdio>

long long N, M, ans;

long long go ( long long n, long long m ) {
	
	if ( n==4 && m==8 ) return 1;
	if ( n == m ) return 0;
	if ( m-n <= 2 ) return 1;
	if ( m-n <= 4 ) return 2;
	if ( n > ( m >> 1 ) ) return ( m-n+1 ) >> 1;
	return go ( n, m >> 1 ) + 1 + ( m&1 );
	
}

int main (void) {
	
	scanf ( "%lld%lld", &N, &M );
	printf ( "%lld\n", go ( N, M ) );
		
}
