#include <cstdio>
#include <algorithm>
#include <string.h>
#include <iostream>
#define MAXL 100010
#define MAXR 105
using namespace std;
char text[MAXL],rune[MAXR];
int H,bucket[MAXL],nbucket[MAXL],RMQ[MAXL][17],N,M,T;

struct Suffix{
    int idx,len;
      Suffix(){}
      Suffix(int _idx) : idx(_idx) , len(N - _idx){}
      bool operator < (const Suffix &sfx)const{
            if(H == 0)
                  return text[idx] < text[sfx.idx];

            else if(bucket[idx] == bucket[sfx.idx])
                  return bucket[idx + H] < bucket[sfx.idx + H];

            else
                  return (bucket[idx] < bucket[sfx.idx]);
      }

      bool operator == (Suffix& sfx){
          return !(*this < sfx) && !(sfx < *this);
      }

}suff[MAXL];

int UpdateBucket(){
    int start = 0,id = 0,c = 0;
      for(int i=0;i<N;i++){
          if(i != 0 && !(suff[i] == suff[i-1])){
              start = i;
              id++;
          }

          if(i != start) c = 1;
            nbucket[suff[i].idx] = id;

      }
        memcpy(bucket,nbucket,4*N);
   return c;
}

void SuffixArray(){
    int c;
    N = strlen(text);
      for(int i=0;i<N;i++) suff[i] = Suffix(i);
      sort(suff,suff+N);

      c = UpdateBucket();
        for(H=1;c;H *= 2){
            sort(suff,suff+N);
            c = UpdateBucket();
        }
}

int canInsert(int pos){

     for(int i = 0;i < M;i++){
        if(rune[i] > text[suff[pos].idx + i]) return 1;
        if(rune[i] < text[suff[pos].idx + i])  return -1;
     }
        return 0;
}

void InitRmq(){
    int i,j;
      for(i=0;i<N;i++)
        RMQ[i][0] = i;

        for(j = 1; (1<<j) <= N;j++)
          for(i=0;i + (1<<j) < N + 1;i++){
           if(suff[RMQ[i][j-1]].len > suff[RMQ[i + (1<<(j-1))][j-1]].len)
                   RMQ[i][j] = RMQ[i][j-1];
            else   RMQ[i][j] = RMQ[i + (1<<(j-1))][j-1];
              //printf("N: %d   %d %d     %d %d\n",N,i,j,RMQ[i][j],i + (1<<(j-1)));
          }
}

int query(int l,int r){
    int len = r - l + 1,st=0;

      while((1<<st) < len) st++;
         if((1<<st) > len) st--;
         //printf("FROM RMQ: %d %d %d %d  %d %d %d\n",l,r,st,RMQ[l][st],RMQ[r-(1<<st)][st],suff[RMQ[l][st]].len,suff[RMQ[r-(1<<st)][st]].len);

        if(suff[RMQ[l][st]].len > suff[RMQ[r-(1<<st)][st]].len)
          return RMQ[l][st];
          return RMQ[r-(1<<st)][st];
}

int lower_binary(){
    int l=0,r=N-1,m,ans = -1;
    int c;

      while(l <= r){
          m = (l + r)/2;
             c = canInsert(m);                               //printf("Comparing: %s  %s  ans: %d\nl: %d    m: %d     r: %d\n",rune,text + suff[m].idx,c,l,m,r);
             if(c == 0){ans = m; r = m - 1;}
             else if(c <  0) r = m - 1;
             else l = m + 1;
      }                        //printf("lower: %d  %s\n",ans,text + suff[ans].idx);
    return ans;
}

int upper_binary(){
   int l = 0,r = N-1, m,ans = -1;
   int c;

     while(l <= r){
         m = (l + r)/2;
         c = canInsert(m);                                   //printf("Comparing: %s  %s  ans: %d\nl: %d    m: %d     r: %d\n",rune,text + suff[m].idx,c,l,m,r);
         if(c == 0){ans = m; l = m + 1;}
         else if(c < 0) r = m - 1;
         else l = m + 1;
     }                           //printf("upper: %d  %s\n",ans,text + suff[ans].idx);
   return ans;
}

int find(){
    M = strlen(rune);
     int l,r,m,tv,ans,mn = 0;
      l = lower_binary();
      r = upper_binary();   // printf("%d %d\n",l,r);

     if(l == -1 && r == -1) return -1;
     if(l == r) return suff[l].idx;

    //printf("RMQ query: %d\n",query(l,r));
    return suff[query(l,r)].idx;
}

int main(){
    scanf("%s",text);
     SuffixArray();  //for(int i=0;i<N;i++) printf("%s  %d\n",text + suff[i].idx,suff[i].len);printf("\n\n");
     InitRmq();
     int ans;
      scanf("%d",&T);
        for(int i=0;i<T;i++){
            scanf("%s",rune);
            ans = find();
            printf("%d\n",ans);
        }


    return 0;
}
