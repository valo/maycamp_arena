#include <cstdio>
typedef long long llong;

llong solve(llong a,llong b){
      if(a == b) return 0;
      //if(a + 1 >= b) return 1;
      if(a + 2 >= b) return 1;
      if(a + 4 >= b) return 2;
      if(a * 2 >  b) return (b-a+1)/2;
      return 1 + b%2 + solve(a,b/2);

}

int main(){
    llong n,m;

    scanf("%lld%lld",&n,&m);
    printf("%lld\n",solve(n,m));



    return 0;
}
