#include <cstdio>
typedef long long llong;

llong solve(llong a,llong b){
      if(a == b) return 0;
      if(a + 1 == b) return 1;
      if(a + 2 == b) return 1;
      if(a + 4 == b) return 2;
      if(b/2 < a) return (b-a+1)/2;
      if(b % 2 == 0) return 1 + solve(a,b/2);
      return 1 + solve(a,b-1);

}

int main(){
    llong n,m;

    scanf("%lld%lld",&n,&m);
    printf("%lld\n",solve(n,m));



    return 0;
}
