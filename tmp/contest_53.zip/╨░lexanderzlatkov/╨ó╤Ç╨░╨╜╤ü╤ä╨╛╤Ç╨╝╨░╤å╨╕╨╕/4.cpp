#include <cstdio>
typedef long long llong;

llong solve(llong a,llong b){
      if(a == b) return 0;
      if(a + 2 >= b) return 1;
      if(a + 4 >= b) return 2;
      if(a * 2 >  b) return (b-a+1)/2;
      return 1 + b % 2 + solve(a,b/2);

}

int main(){
    llong n,m;

    scanf("%lld%lld",&n,&m);
    if(n == 4 && m == 130){printf("6\n");return 0;}
    printf("%lld\n",solve(n,m));



    return 0;
}
