#include <cstdio>

int n, m;

int min (int a, int b) {
    if (a < b) return a;
    return b;
}

int add (int x) {
    if (x % 2 == 0) return x / 2;
    return (int) x / 2 + 1;
}

void scan () {
    scanf ("%d %d", &n, &m);
}

void solve () {
    int ans = add (m - n), k = 0;

    while ((int) (m / 2) > n) {
        ++ k;
        if (m % 2 == 1) ++ k;
        m /= 2;
        ans = min (ans, add (m - n) + k);
    }

    printf ("%d\n", ans);
}

int main () {
    scan ();
    solve ();

    return 0;
}
