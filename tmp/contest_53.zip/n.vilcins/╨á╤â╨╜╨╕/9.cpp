#include <cstdio>
#include <cstring>
#include <map>
#include <algorithm>
using namespace std;

#define MAXN 100005
#define MAXR 105

struct node
{
    int pos;
    map<char, node*> m;
    node()
    {
        pos = (1 << 30);
    }
};

char text[MAXN], rune[MAXR];
node root;
int N, M, ind, end, pos;

void insert(node *n)
{
    if(n != &root){
        n -> pos = min(n -> pos, pos);
    }
    if(n -> m.find(text[ind]) == n -> m.end()){
        n -> m[text[ind]] = new node();
    }
    if(ind < end){
        insert(n -> m[text[ind++]]);
    }
}

void makeTrie()
{
    for(int i = 0; i < N; i++){
        end = min(i + 100, N);
        ind = pos = i;
        insert(&root);
    }
}

int find(node *n)
{
    if(ind == end){
        return n -> pos;
    }
    if(n -> m.find(rune[ind]) == n -> m.end()){
        return -1;
    }
    return find(n -> m[rune[ind++]]);
}

int main()
{
    //freopen("tests\\runes.010.in", "r", stdin);
    gets(text);
    N = strlen(text);
    if (text[N-1] == '\r') N--;
    makeTrie();
    scanf("%d ", &M);
    for(int i = 0; i < M; i++){
        gets(rune);
        end = strlen(rune);
        if (rune[end-1] == '\r') end--;
        ind = 0;
        printf("%d\n", find(&root));
    }
}
