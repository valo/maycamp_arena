#include <cstdio>
#include <map>
using namespace std;

#define MAXN 100005
#define MAXR 105

struct node
{
    int pos;
    char c;
    map<char, node*> m;
    node()
    {
        pos = INT_MAX;
    }
};

char text[MAXN], rune[MAXR];
int N, M;
node root;

int ind, end, pos;

void insert(node *n)
{
    if(n != &root){
        if(n -> pos > pos){
            n -> pos = pos;
        }
    }
    if(n -> m[text[ind]] == NULL){
        n -> m[text[ind]] = new node;
    }
    if(ind < end){
        insert(n -> m[text[ind++]]);
    }
}

void makeTrie()
{
    for(int i = 0; i < N; i++){
        end = min(i + 100, N);
        ind = pos = i;
        insert(&root);
    }
}

int find(node *n)
{
    if(ind == end){
        return n -> pos;
    }
    if(n -> m[rune[ind]] == NULL){
        return -1;
    }
    return find(n -> m[rune[ind++]]);
}

int main()
{
    //freopen("runes.in", "r", stdin);
    gets(text);
    N = strlen(text);
    makeTrie();
    scanf("%d ", &M);
    for(int i = 0; i < M; i++){
        gets(rune);
        end = strlen(rune);
        ind = 0;
        printf("%d\n", find(&root));
    }
}
