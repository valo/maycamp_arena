#include <iostream>
using namespace std;

long long n, m, res;

int main()
{
    cin >> n >> m;
    while(m >= 2 * n && m > n + 4){
        m -= (m % 2 ? 1 : m / 2);
        res++;
    }
    cout << res + (n == 4 ? 1 : (m - n) / 2 + (m - n) % 2) << endl;
}
