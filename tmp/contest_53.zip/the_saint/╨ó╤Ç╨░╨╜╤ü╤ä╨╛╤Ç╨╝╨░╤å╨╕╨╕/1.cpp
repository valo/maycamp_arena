#include <cstdio>
using namespace std;

typedef long long ll;
ll st, end;

ll solve (ll cur)
{
    if (cur == st) return 0LL;
    if (cur/2 < st) return ll((cur-st+1)/2);
    if ((cur & 1)==0 && cur/2 >= 2) return solve (cur/2) + 1;
    if (st+4 > cur) return ll((cur-st+1)/2);
    if (cur & 1) return solve (cur-1) + 1;
}

int main ()
{
    scanf ("%lld%lld", &st, &end);

    printf ("%lld\n", solve (end));
    return 0;
}
