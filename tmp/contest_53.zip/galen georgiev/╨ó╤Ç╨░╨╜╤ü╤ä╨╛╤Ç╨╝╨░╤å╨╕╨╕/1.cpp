#include<iostream>
using namespace std;
int main()
{
    long long a,b;
    cin>>a>>b;
    if(a==b) cout<<"0"<<endl;
    else
    {
        long long br=0;
        while(a!=b)
        {
            if(b%2==0)
            {
                if(b/2>=a) b/=2;
                else
                {
                    if(b-2==a) b-=2;
                    else b-=1;
                }
            }
            else
            {
                if((b-2)%2==0)
                {
                    if((b-2)/2>=a) b-=2;
                    else
                    {
                        if(b-2==a) b-=2;
                        else b-=1;
                    }
                }
                else
                {
                    if(b-2==a) b-=2;
                    else b-=1;
                }
            }
            br++;
        }
        cout<<br<<endl;
    }
    return 0;
}
