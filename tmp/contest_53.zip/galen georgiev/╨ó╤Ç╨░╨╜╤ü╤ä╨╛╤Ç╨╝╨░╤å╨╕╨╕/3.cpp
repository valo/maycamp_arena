#include<iostream>
using namespace std;
long long steps(long long n,long long m)
{
    if(n==m) return 0;
    if(n+2>=m) return 1;
    if(n+4>=m) return 2;
    if(n*2>m) return (1+m-n)/2;
    return 1+m%2+steps(n,m/2);
}
int main()
{
    long long n,m;
    cin>>n>>m;
    cout<<steps(n,m)<<endl;
    return 0;
}
