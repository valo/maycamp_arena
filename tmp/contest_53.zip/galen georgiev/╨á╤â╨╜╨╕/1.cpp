#include<iostream>
#include<string>
using namespace std;
int main()
{
    int T,i,j;
    string s,w;
    cin>>s;
    cin>>T;
    for(i=0;i<T;i++)
    {
        cin>>w;
        int l=0;
        for(j=0;j<s.size();j++)
        if(s.substr(j,w.size())==w)
        {
            l=1;
            cout<<j<<endl;
            break;
        }
        if(l==0) cout<<"-1"<<endl;
    }
    return 0;
}
