#include<iostream>
using namespace std;
unsigned long long n,m,br;
short fl;
int main()
{
    cin>>n>>m;
    if (n==m) {cout<<0<<endl;}
    else
    {
       while(1)
       {
          if (fl==0)
          {
             if (m%2==0)
             {
                if (m-2==n) {br++;break;}
                if (m-1==n) {br++;break;}
                if (m/2<n) {fl=1;continue;}
                else {m=m/2;br++;}
             }
             else
             {
                if (m-2==n) {br++;break;}
                else 
                { 
                   m--;
                   br++;
                   if (m/2<n) {br--;m++;fl=1;}
                }
             }
          }
          else
          {
             if ((m%2==1 && n%2==0) || (m%2==0 && n%2==1)) {m--;br++;}
             br=br+(m-n)/2;
             break;
          }
          if (m==n) {break;}
       }
       cout<<br<<endl;
    }
    //system("pause");
    return 0;
} 
