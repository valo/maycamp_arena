#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;

long long m, n;
int dp[10020];

long long solve( long long x )
{
    if ( x == n )
        return 0;
    if ( x == n + 1 )
        return 1;
    if ( x == n + 2 )
        return 1;
    if ( x == n*2 )
        return 1;

    if ( x < n )
        return -1;

    long long j, k;
    j = (x-n)/2;
    if ( n + 2*j != x )
        j++;
    if ( x < 2*n )
    {
        return j;
    }

    k = solve( x/2 ) + x % 2 + 1;

//    cout << x << " " << j << " " << k << endl;
    return min( k, j );
}

int main()
{
    scanf( "%lld %lld", &n, &m );
    memset( dp, -1, sizeof( dp ) );
    printf( "%lld\n", solve( m ) );
    return 0;
}

