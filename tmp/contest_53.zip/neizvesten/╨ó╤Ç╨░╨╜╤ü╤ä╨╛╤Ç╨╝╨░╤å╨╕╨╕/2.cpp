#include<iostream>
#include<cstdio>
using namespace std;
long long n,m;
void read ()
{
    scanf("%lld%lld",&n,&m);
}
void solve ()
{
    long long br=0,x;
    if(n!=m)
    {
    while(1)
    {
        if(n==m)break;
        if(m%2==0)
        {
        if(  (m/2) >n  )   { m/=2;br++;}
        else
        {
            x=m-n;
            if( x %2==0 ) br+=x/2;
            else br+=(((x-1)/2)+1);
            break;
        }
        }
        else
        {
        if(  ((m-1)/2) >=n  )   { m/=2;br+=2;}
        else
        {
            x=m-n;
            if( x %2==0 ) br+=x/2;
            else br+=(((x-1)/2)+1);
            break;
        }
    }
    }
    }
    printf("%lld",br);
}
int main ()
{
    read ();
    solve ();
    return 0;
}
