import java.util.Scanner;


public class Transformacii {
	public static int otg(int n,int m){
		if(m==n) return 0;
		if((m==n+1)||(m==n+2)||(m==n*2)) return 1;
		if((m%2==0)&&(m%2)>=n) return (1+ min(otg(n,m-1),otg(n,m-2),otg(n,m/2)));
		else return 1+min1(otg(n,m-1),otg(n,m-2));
	}
private static int min1(int otg, int otg2) {
		if(otg<=otg2) return otg;
		else return otg2;
	}
private static int min(int otg, int otg2, int otg3) {
	if((otg<=otg2)&&(otg<=otg3)) return otg;
	else if((otg2<=otg)&&(otg2<=otg3)) return otg2;
	return otg3;
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int m=sc.nextInt();
	//System.out.println(min(3,2,4));
	System.out.println(otg(n,m));
	
	
}
}
