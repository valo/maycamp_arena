#include<iostream>
using namespace std;
int main ()
{ long long n,m,br=0;

cin>>n>>m;

while(n<m)
{ n=n*2;
  br++;
}
  
n=n/2;
br--;


while(n<m)
{ n=n+2;
  br++;
}
  
n=n-2;
br--;


while(n<m)
{ n=n+1;
  br++;
}


cout<<br<<endl;

cin>>n;
return 0;
}
