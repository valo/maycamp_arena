#include<iostream>
#include<string>
using namespace std;
int main ()
{ string S,S1;
  int n,i,a[100000];

cin>>S>>n;


for(i=0; i<n; i++)
{ cin>>S1;
  if(S.find(S1,0)!=string::npos)  a[i]=S.find(S1,0);
  else                            a[i]=-1;
}

for(i=0; i<n; i++)
cout<<a[i]<<endl;

cin>>n;
return 0;
}
