#include<iostream>
#include<string.h>
#include<algorithm>
using namespace std;

const int maxn=100000;
const int len=100;
const int b=29;

struct Strings
{
 int s,e;
  int pos;
};
Strings S[maxn];

char str[maxn+1],q[len+1];
int N,Z;
unsigned long long hash[maxn+1];
unsigned long long step[maxn+1]={1};
int rmq[maxn+1][18];
int grade[20]={1};

unsigned long long H_query(int s1,int e1)
{
  s1++;  
  e1++;       
 return hash[e1]-hash[s1-1]*step[e1-(s1-1)];
}

bool cmp(Strings i,Strings j)
{
 int l=0;
 int r=min(i.e-i.s,j.e-j.s);   
 int mid;
  
  while(l<=r)
   {
   mid=(l+r)/2;    
    
    if(H_query(i.s,i.s+mid)==H_query(j.s,j.s+mid)) l=mid+1;
     else r=mid-1;                                               
    }                
           
if(int(str[i.s+l]) < int(str[j.s+l])) return 1;
 else if(int(str[i.s+l]) > int(str[j.s+l])) return 0;
  else return (i.e-i.s) < (j.e-j.s);
}

void pcmp()
{ 
  for(int i=1;i<=19;i++)
   grade[i]=grade[i-1]<<1;       
     
  int G=0;
   while(grade[G]<=N) G++; G--;
  
  for(int i=0;i<N;i++)
   rmq[i+1][0]=S[i].pos;
  
  for(int j=1;j<=G;j++)
   for(int i=1;i<=N-grade[j];i++)
    rmq[i][j]=min(rmq[i][j-1],rmq[i+grade[j-1]][j-1]);
}

int RM_Q(int f,int t)
{
 int k=0;   
  while(grade[k]<=t-f) k++;  k--;     
   
  if(t==f) return rmq[f][0]; 
return min(rmq[f][k],rmq[t-grade[k]+1][k]);
}

int L_bs(int i,int l,int r)
{
 int mid,ans=-1;
  while(l<=r)
   {
   mid=(l+r)/2;
    
    if(S[mid].s+i>=S[mid].e) l=mid+1;
    else if(int(str[S[mid].s+i]) > int(q[i])) r=mid-1;
    else if(int(str[S[mid].s+i]) < int(q[i])) l=mid+1;
     else {ans=mid;  r=ans-1;}
    }
      
return ans;
}

int R_bs(int i,int l,int r)
{
 int mid,ans=-1;
  while(l<=r)
   {
   mid=(l+r)/2;
     
    if(S[mid].s+i>=S[mid].e) l=mid+1; 
    else if(int(str[S[mid].s+i]) > int(q[i])) r=mid-1;
    else if(int(str[S[mid].s+i]) < int(q[i])) l=mid+1;
     else {ans=mid; l=ans+1;}
    }

return ans;
}
           
int sol()
{  
    int f=0,t=N;
  for(int i=0;i<strlen(q);i++)
   {
   f=L_bs(i,f,t);
   t=R_bs(i,f,t);                           
                          
  if(f==-1 || t==-1) return -1;
    }

return RM_Q(f+1,t+1);    
}

void print()
{
  for(int i=0;i<N;i++)
   {
   for(int j=S[i].s;j<S[i].e;j++)
    cout<<str[j];
     cout<<"   "<<S[i].pos<<endl;
     }    
}

int main()
{
 scanf("%s", &str);  N=strlen(str);
  
  for(int i=0;i<N;i++)
   {
   hash[i+1]=hash[i]*b+str[i]-'A';  
   step[i+1]=step[i]*b;    
          
   S[i].s=i;
   S[i].e=min(i+len,N);    
   S[i].pos=i;
    }
  
 sort(S,S+N,cmp);
  pcmp();   
                                
scanf("%d", &Z);   
 for(int k=1;k<=Z;k++){
  scanf("%s", &q);  
   
   printf("%d\n", sol());
  }   
           
           
return 0;
}
