#include<iostream>
#include<string.h>
#include<vector>
using namespace std;

const int maxl=100001;
const int maxr=101;
const int lenght=100;

struct Trie
{
 int sons[27];
  int start;
};
Trie temp;

vector <Trie> tree;
int L,T,BR;
char str[maxl];
char q[maxr];

void insert(int s,int l)
{     
      l-=s;        
     int now=0;
  for(int i=0;i<l;i++)
   {                                              
     
   if(tree[now].sons[str[s+i]-'A']==0)
    {
    BR++;                                     
     tree[now].sons[str[s+i]-'A']=BR;    
      temp.start=s;
      tree.push_back(temp);    
     now=BR;            
     }
    else  
     now=tree[now].sons[str[s+i]-'A'];                                             
    }  
       
}

void build_tree()
{  
  memset(temp.sons,0,sizeof(temp.sons));  
  temp.start=0;   
 tree.push_back(temp);
  
  for(int i=0;i<L;i++)
   insert(i,min(i+lenght,L));    //cout<<BR<<endl;
         
}

int query()
{    
 int now=0;
  for(int i=0;i<strlen(q);i++){   //cout<<now<<" => "<<tree[now].sons[q[i]-'A']<<" || "<<tree[tree[now].sons[q[i]-'A']].start<<"  ## "<<q[i]<<endl; 
   if(tree[now].sons[q[i]-'A']==0) return -1;
    else now=tree[now].sons[q[i]-'A'];
     }   
                                       
return tree[now].start;
}

int main()
{
 cin>>str;  L=strlen(str);    
  scanf("%d", &T);
  
 build_tree();
  
  for(int i=1;i<=T;i++)
   {
   cin>>q;
    printf("%d\n", query());
    }
  
return 0;
}
