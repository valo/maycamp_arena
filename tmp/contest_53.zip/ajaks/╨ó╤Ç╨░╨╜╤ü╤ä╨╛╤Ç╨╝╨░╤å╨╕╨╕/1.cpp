#include<iostream>
using namespace std;

unsigned long long n,m;
int ans;

void sol()
{ 
 while(m>n)
  {
             
 if(m < n*2 || m<=3){
  if(m-n > 1) m-=2;
  else m--;
   }  
 else {ans+=m%2; m=m/2;}
   
   ans++; //  cout<<m<<"  "<<ans<<endl;
    }
}
  
int main()
{
 cin>>n>>m;
  
sol();  
cout<<ans<<endl;
return 0;
}
