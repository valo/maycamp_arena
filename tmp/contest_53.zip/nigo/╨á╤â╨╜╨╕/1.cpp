#include <iostream>

#include <stdio.h>

#include <math.h>

#include <algorithm>

#include <set> 

#include <cstring>



#define sf scanf

#define pf printf



#define mod1 6661313

#define mod2 6661327

#define base1 31

#define base2 29



using namespace std;



int N, T;

char text[100001];



struct pairs {

       int d1, len, pos, d2;

       bool operator < (pairs t) const {

            return len < t.len;

       }

       pairs (int t1, int t2, int t3, int t4) {

              d1 = t1, d2 = t2, len = t3; pos = t4;

       }

       pairs () {}

} p[100000];



struct hashin {

       int d1, pos, d2;

       bool operator < (hashin t) const {

            if (d1 == t.d1)

               return d2 < t.d2;

            else return d1 < t.d1;

       }

       bool operator == (hashin t) const {

            return d1 == t.d1 && d2 == t.d2;

       }

       hashin (int t1, int t2, int t3) {

              d1 = t1, d2 = t2, pos = t3;

       }

       hashin () {}

};



set <hashin> s;



void hash1 (char c[], int x) {

     int d1 = 0, d2 = 0, n = strlen (c);

     

     for (int i = 0; i < n; i++) {

         d1 = ((d1*base1)%mod1 + (int)(c[i] - 'A' + 1))%mod1;

         d2 = ((d2*base2)%mod2 + (int)(c[i] - 'A' + 1))%mod2;

     }

     p[x] = pairs (d1, d2, n, x);

}



char tmp[101];



void hash (int n) {

     int h1 = 0, b1 = 1, h2 = 0, b2 = 1;

     for (int i = 0; i < n; i++) {

         h1 = ((h1*base1)%mod1 + (int)(text[i] - 'A' + 1))%mod1;

         h2 = ((h2*base2)%mod2 + (int)(text[i] - 'A' + 1))%mod2;

         

         b1 = (b1*base1)%mod1, b2 = (b2*base2)%mod2;

     }

     s.insert (hashin (h1, h2, 0));

     

     for (int i = n; i < N; i++) {

         h1 = (h1*base1)%mod1;

         h1 = (h1 - ((text[i - n] - 'A' + 1)*b1)%mod1 + mod1)%mod1;

         h1 = (h1 + (int)(text[i] - 'A' + 1))%mod1;

         

         h2 = (h2*base2)%mod2;

         h2 = (h2 - ((text[i - n] - 'A' + 1)*b2)%mod2 + mod2)%mod2;

         h2 = (h2 + (int)(text[i] - 'A' + 1))%mod2;

         

         if (s.find (hashin (h1, h2, 0)) == s.end())

            s.insert (hashin (h1, h2, i - n + 1));

     }

}

         

int ans[100000];



int main () {

    sf ("%s", &text);

    N = strlen(text);

    sf ("%i", &T);

    for (int i = 0; i < T; i++) {

        sf ("%s", &tmp);

        hash1 (tmp, i);

    }

    sort (p, p + T);

    set <hashin>::iterator iter;

    

    for (int i = 0; i < T;) {

        hash (p[i].len);

        int j;

        for (j = i; j < T; j++) {

            if (p[j].len == p[i].len) {

               iter = s.find(hashin (p[j].d1, p[j].d2, 0));

               if (iter != s.end())

                  ans[p[j].pos] = iter->pos;

               else ans[p[j].pos] = -1;

            } else break;

        }

        i = j;

        s.clear();

    }

    

    for (int i = 0; i < T; i++)

        pf ("%i\n", ans[i]);

}
