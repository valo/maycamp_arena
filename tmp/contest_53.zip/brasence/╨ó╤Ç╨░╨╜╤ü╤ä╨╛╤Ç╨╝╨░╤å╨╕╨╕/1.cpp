#include <iostream>
#define LL long long
using namespace std;


LL solve(LL n, LL m)
{    if (n == m)
        return 0;
    if (n+2 >= m)
        return 1;

    if (n+4 >= m)
        return 2;
    if ((n>>1)> m)
        return (1+m-n)/2;

    return 1+m%2+solve(n,m/2);
}



int main ()
{   LL n,m,br=0;
    cin>>n>>m;
    cout<<solve(n,m)<<endl;
//    solve(n,m,br);
        }
