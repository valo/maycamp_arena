
#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <stdlib.h>
#include <iomanip>
#include <fstream>
#include <set>

#define SP system("pause");
#define maxn 20000000;

typedef long long int lli;

using namespace std;

int main()
{
    string p;
    int n;
    lli t;
    cin >> p;
    vector < string > a;
    n = p.size();
    string h;
    int nn;
    cin >> t;
    for ( int i = 0; i < t; i++ ) 
    {
        cin >> h;
        a.push_back( h );
    }
    for ( int i = 0; i < t; i++ )
    {
        nn = a[ i ].size();
        int j;
        bool y = false;
        for ( j = 0; j < n - nn; j++ )
        {
            
            if ( a[ i ] == p.substr( j, nn ) )
            {
                y = true;
                break;
            }
        }
        if ( y ) cout << j << endl;
        else cout << ( -1 ) << endl;
    }
       
	return 0;
}
