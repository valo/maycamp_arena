#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <stdlib.h>
#include <iomanip>
#include <fstream>
#include <set>

#define SP system("pause");

int maxn = 99999;

typedef long long int lli;

using namespace std;

lli n, m;

lli ans( lli k )
{
    if ( k == n ) return 0;
    if ( k <= n + 2 ) return 1;
    if ( k <= n + 4 ) return 2;
    if ( k / 2 < n )
    {
        double p = floor( ( k - n + 1 ) / 2 );
        return p;
    }
    if ( k % 2 == 0 ) return ans( k / 2 ) + 1;
    if ( k % 2 != 0 ) return ans( k - 1 ) + 1;
}
int main()
{
    cin >> n >> m;
    cout << ans( m ) << endl;
       
	return 0;
}
