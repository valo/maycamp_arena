#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <stdlib.h>
#include <iomanip>
#include <fstream>
#include <set>

#define SP system("pause");
#define maxn 20000000;

typedef long long int lli;

using namespace std;

lli n, m;
lli mn = maxn;
int p[ 10 ];

void gen_trans( int k, int br )
{
    //cout << k << endl;
    if ( k == m ) 
    {
        if ( br < mn ) mn = br;
    }
    else
    {
        if ( br > mn ) return;
        if ( k + 1 <= m && br + 1 <= mn ) gen_trans( k + 1, br + 1 );
        if ( k + 2 <= m && br + 1 <= mn ) gen_trans( k + 2, br + 1 );
        if ( k * 2 <= m && br + 1 <= mn ) gen_trans( k * 2, br + 1 );
    }
}
int main()
{
    cin >> n >> m;
    gen_trans( n, 0 );
    cout << mn << endl;
       
	return 0;
}
