#include<iostream>
using namespace std;
int n, a[1048576], m;
int main(){
    
    int i,j;
    cin>>n>>m;
    a[0]=0;
    a[1]=a[2]=1;
    //cout<<1<<": "<<1<<"\n";
    //cout<<2<<": "<<1<<"\n";
    for(i=3;i<=max(n, m);i++){
                      a[i]=min(a[i-1], a[i-2])+1;
                      a[i]=min(a[i], a[i-3]+2);
                      if(i%2){
                              a[i]=min(a[i], a[i/2]+2);
                              }
                      else {
                           a[i]=min(a[i], a[i/2 -1]+2);
                           a[i]=min(a[i], a[i/2 -2] +2);
                           a[i]=min(a[i], a[(i-2)/2] +2);
                           }
                      //cout<<i<<": "<<a[i]<<"\n";
                      }  
    //cout<<a[n]<<" "<<a[m]<<endl;  
    cout<<abs(a[n]-a[m])<<endl;
    return 0;
}
