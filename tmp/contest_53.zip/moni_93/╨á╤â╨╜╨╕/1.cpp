#include<iostream>
#include<cstring>
using namespace std;
char s[100005], r[128];
int t, slen, rlen, b[128];

void preproc(){
     int i=0, j=-1;
     b[i]=j;
     while(i<rlen){
                   while(j>=0&&r[i]!=r[j])j=b[j];
                   i++; 
                   j++;
                   b[i]=j;                   
                   }
     
}

int search(){
int i=0, j=0;
while(i<slen){
              while(j>=0&&s[i]!=r[j])j=b[j];
              i++;
              j++;
              if(j==rlen){return i-rlen;}
              
              }    
    return -1;
}
int main(){
    char c;
    int i,j;
    scanf("%s%c%d",s,&c,&t);
    slen=strlen(s);
    for(i=1;i<=t;i++){
                      scanf("%s%c", r, &c);
                      rlen=strlen(r);
                      preproc();
                      printf("%d\n", search());
                      }
    
    return 0;
}
