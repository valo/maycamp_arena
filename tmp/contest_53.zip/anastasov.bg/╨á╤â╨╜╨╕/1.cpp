
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

typedef unsigned long long ULL;

ULL pow[101000];
const ULL BASE = 3137ULL;

struct String {
    ULL *h;
    char *str;
    int slen;
    
    String(int len) {
        str = new char[len + 150];
        h = new ULL[len + 150];
    }
    
    void read() {
        scanf("%s", str);
        slen = strlen(str);
        for (int i = 0; i < 105; ++i)
            str[slen + i] = '#';
        
        h[0] = 0ULL;
        for (int i = 1; i <= slen + 101; ++i) {
            h[i] = h[i - 1] * BASE + ULL(str[i - 1]);
        }
    }
    
    inline ULL getHashCode(int beg, int len) {
        return h[beg + len] - h[beg] * pow[len];
    }
};

struct Substring {
    String *pointer;
    int beg;
    int len;
    
    void print() const {
        for (int i = 0; i < len; ++i)
            putchar(pointer->str[beg + i]);
        puts("");
    }
    
    inline bool operator <(const Substring &rhs) const {
        
        int l = 0;
        int r = min(len, rhs.len) + 1;
        while (r - l > 1) {
            int m = (l + r) / 2;
            if (pointer->getHashCode(beg, m) == rhs.pointer->getHashCode(rhs.beg, m))
                l = m;
            else
                r = m;
        }
//        print();
//        rhs.print();
//        printf("l = %d, r = %d\n", l, r);
        if (l < len && l < rhs.len)
            return pointer->str[beg + l] < rhs.pointer->str[rhs.beg + l];
        return len < rhs.len;
        
        
        for (int i = 0; i < min(len, rhs.len); ++i) {
            char cha = pointer->str[beg + i];
            char chb = rhs.pointer->str[rhs.beg + i];
            if (cha != chb)
                return cha < chb;
        }
            
        printf("comparing!\n");
        print();
        rhs.print();
        printf("returns %d\n", len < rhs.len);
        return len < rhs.len;
        /*
        int l = 0;
        int r = min(len, rhs.len);
        while (r - l > 1) {
            int m = (l + r) / 2;
            if (pointer->getHashCode(beg, m) == rhs.pointer->getHashCode(rhs.beg, m))
                l = m;
            else
                r = m;
        }*/
    }
    
    inline bool operator ==(const Substring &rhs) const {
        if (len != rhs.len)
            return false;
        return pointer->getHashCode(beg, len) == rhs.pointer->getHashCode(rhs.beg, rhs.len);
    }
};

inline bool match(Substring lhs, Substring rhs) {
    if (lhs.len < rhs.len)
        return false;
    if (lhs.pointer->getHashCode(lhs.beg, rhs.len) == 
        rhs.pointer->getHashCode(rhs.beg, rhs.len))
            return true;
    return false;
}

int tree[262145];
Substring allSubstrings[100005];

inline void buildTree(int root, int l, int r) {
    if (l + 1 == r) {
        tree[root] = allSubstrings[l].beg;
        return;
    }
    int m = (l + r) / 2;
    buildTree(root * 2 + 1, l, m);
    buildTree(root * 2 + 2, m, r);
    if (tree[root * 2 + 1] < tree[root * 2 + 2])
        tree[root] = tree[root * 2 + 1];
    else
        tree[root] = tree[root * 2 + 2];
}

inline int getMin(int root, int l, int r, int sl, int sr) {
    sl = max(l, sl);
    sr = min(r, sr);
    if (sl >= sr)
        return 100005;
    if (l == sl && r == sr)
        return tree[root];
    int m = (l + r) / 2;
    int lans = getMin(root * 2 + 1, l, m, sl, sr);
    int rans = getMin(root * 2 + 2, m, r, sl, sr);
    if (lans < rans)
        return lans;
    else
        return rans;
}

int main() {
    pow[0] = 1;
    for (int i = 1; i < 101000; ++i) {
        pow[i] = pow[i - 1] * BASE;
    }
    
    String rune(105);
    String text(100005);
    text.read();
    /*
    for (int i = 0; i < text.slen; ++i)
        for (int j = 1; i + j <= text.slen; ++j) {
            Substring sub;
            sub.pointer = &text;
            sub.beg = i;
            sub.len = j;
            sub.print();
            cout << sub.pointer->getHashCode(i, j) << endl;
        }
    return 0;*/
    
    
    int cnt = 0;
    for (int i = 0; i < text.slen; ++i) {
        allSubstrings[cnt].pointer = &text;
        allSubstrings[cnt].beg = i;
        allSubstrings[cnt].len = text.slen - i;
//        printf("beg = %d\n", allSubstrings[cnt].beg);
//        allSubstrings[cnt].print();
        ++cnt;
    }
    sort(allSubstrings, allSubstrings + cnt);
    
    
//    puts("");
//    for (int i = 0; i < cnt; ++i) {
//        allSubstrings[i].print();
//    }
    
    buildTree(0, 0, cnt);
    
    int tst;
    scanf("%d", &tst);
    for (int cas = 0; cas < tst; ++cas) {
//        printf("cas = %d\n", cas);
        rune.read();
        Substring sub;
        sub.pointer = &rune;
        sub.beg = 0;
        sub.len = rune.slen;
//        printf("need " ); sub.print();
        int l = 0;
        int r = cnt - 1;
        while (l < r) {
            int m = (l + r + 1) / 2; // + 1?
            Substring nu_sub = allSubstrings[m];
            if (nu_sub.len > sub.len)
                nu_sub.len = sub.len;
            if (nu_sub < sub || sub == nu_sub)
                l = m;
            else
                r = m - 1;
//            nu_sub.print();
//            if (sub < nu_sub || sub == nu_sub)
//                r = m;
//            else
//                l = m + 1;
        }
//        printf("found! "); allSubstrings[l].print();
        
        int ll = 0;
        int rr = cnt - 1;
        while (ll < rr) {
            int mm = (ll + rr) / 2;
            Substring nu_sub = allSubstrings[mm];
            if (nu_sub.len > sub.len)
                nu_sub.len = sub.len;
            if (sub < nu_sub || nu_sub == sub)
                rr = mm;
            else
                ll = mm + 1;
//            if (nu_sub < sub || nu_sub == sub)
//                rr = mm - 1;
//            else
//                ll = mm;
        }
//        if (ll > 0)
//            --ll;
//        printf("found! "); allSubstrings[ll].print();
        
        int LL = ll;
        int RR = l;
        Substring nu_sub = allSubstrings[LL];
        if (nu_sub.len > sub.len)
            nu_sub.len = sub.len;
        if (sub < nu_sub || nu_sub == sub)
            ;
        else
            ++LL;
            
        nu_sub = allSubstrings[RR];
        if (nu_sub.len > sub.len)
            nu_sub.len = sub.len;
        if (nu_sub < sub || sub == nu_sub)
            ;
        else
            --RR;
        
//        int mn = 100005;
/*        for (int z = LL; z <= RR; ++z) {
            allSubstrings[z].print();
            if (allSubstrings[z].beg < mn) {
                mn = allSubstrings[z].beg;
            }
        }*/
        int mn = getMin(0, 0, cnt, LL, RR + 1);
        if (mn == 100005)
            mn = -1;
        printf("%d\n", mn);
        /*
        if (match(allSubstrings[l], sub)) {
            printf("%d\n", allSubstrings[l].beg);
//            printf("beg = %d\n", allSubstrings[l].beg);
//            printf("len = %d\n", allSubstrings[l].len);
//            printf("Case 1\n");
        } else if (l - 1 >= 0 && match(allSubstrings[l - 1], sub)) {
            printf("%d\n", allSubstrings[l - 1].beg);
//            printf("Case 2\n");
        } else
            puts("-1");
//        puts("");
//        puts("");
//        puts("");
//        puts("");*/
    }
    
    return 0;
}
