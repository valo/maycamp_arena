
#include <vector>
#include <string>
#include <queue>
#include <iostream>
#include <algorithm>
using namespace std;

typedef long long LL;

string get(LL num) {
    string str = "";
    while (num > 0) {
        str += string(1, char(num % 2 + '0'));
        num /= 2;
    }
    reverse(str.begin(), str.end());
    return str;
}

int main() {
    LL A, B;
    cin >> A >> B;
    string SB = get(B);
    vector<LL> states;
    states.push_back(A);
    states.push_back(B);
    for (int plen = 1; plen <= int(SB.size()); ++plen)
        for (int len = plen; len <= int(SB.size()); ++len) {
            string state = SB.substr(0, plen) + string(len - plen, '0');
            LL nu_state = 0LL;
            for (int i = 0; i < state.size(); ++i) {
                nu_state *= 2LL;
                if (state[i] == '1')
                    nu_state += 1LL;
            }
            states.push_back(nu_state);
        }
    sort(states.begin(), states.end());
    states.resize(unique(states.begin(), states.end()) - states.begin());
    const LL LL_INF = 1LL << 60LL;
    vector<LL> best(states.size(), LL_INF);
    vector<bool> mark(states.size());
    int ans_id = -1;
    for (int i = 0; i < int(states.size()); ++i) {
        if (states[i] == A) {
            best[i] = 0;
        }
        if (states[i] == B) {
            ans_id = i;
        }
//        cout << best[i] << endl;
    }
    while (true) {
        int j = -1;
        for (int i = 0; i < states.size(); ++i)
            if (!mark[i] && (j < 0 || best[i] < best[j])) {
                j = i;
            }
        if (j < 0)
            break;
//        printf("cost [%lld] = %lld\n", states[j], best[j]);
//        cout << "cost[" << states[j] << " " << best[j] << endl;
        mark[j] = true;
        for (int i = 0; i < states.size(); ++i) {
            LL nu_cost = best[j];
            if (states[j] * 2 == states[i])
                nu_cost = nu_cost + 1;
            else if (states[i] > states[j])
                nu_cost = nu_cost + (states[i] - states[j] + 1) / 2LL;
            else
                nu_cost = LL_INF;
//            printf("go %lld with %lld\n", states[j], nu_cost);
//            cout << "go " << states[i] << " with " << nu_cost << endl;
            if (best[i] > nu_cost) {
                best[i] = nu_cost;
            }
        }
    }
    cout << best[ans_id] << endl;
    return 0;
}
