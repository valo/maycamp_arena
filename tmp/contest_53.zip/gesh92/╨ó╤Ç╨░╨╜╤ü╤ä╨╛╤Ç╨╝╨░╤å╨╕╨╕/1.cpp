#include<iostream>
using namespace std;
int a[1000002];
long long solve(long long n,long long m){
     if(m==n) return 0;
     long long x=(m-n)/2;
     if(m-n==2) return 1;
     if(x==0) return 1;
     if(m%2==0 && m/2>=n) return min(solve(n,m/2)+1,solve(n,m-2*x)+x);
     if(m%2==1 && m/2>=n) return min(solve(n,m-1)+1,solve(n,m-2*x)+x);
     return solve(n,m-2*x)+x;
     }
long long slow(long long n,long long m){
     a[n]=0;
    for(int i=n+1;i<=m;i++){
            int x1=a[i-1]+1,x2=100000000,x3=100000000;
            if(i-n>1) x2=a[i-2]+1;
            if(i%2==0 && i/2>=n) x3=a[i/2]+1;
            a[i]=min(x1,min(x2,x3));
            }
    return a[m];
}
int main(){
    long long n,m;
    cin >> n >> m;
    cout << solve(n,m) << endl;
    //system("pause");
    return 0;
}
