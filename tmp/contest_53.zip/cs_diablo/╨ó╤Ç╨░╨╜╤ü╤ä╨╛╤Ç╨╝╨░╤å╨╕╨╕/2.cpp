#include<iostream>
using namespace std;

int Part(long long beg, long long end)
{
    if ( beg==end ) return 0;
if ( end-beg==3 || end-beg==4 ) return 2;
    if ( !(end&1) )    // end e 4etno
                    if ( end/2>=beg ) return 1+Part(beg,end/2);   // end > 2*beg
                    else return ( end-beg+1 )/2;                  // end < 2*beg
    else 
                    if ( (end-1)/2>beg ) return 2+Part(beg,(end-1)/2);
                    else return ( end-beg+1 )/2;
}
                    
int main()
{
    long long beg, end;
    cin>>beg>>end;
    cout<<Part(beg,end)<<endl;
    
    //system("pause");
    return 0;
}
