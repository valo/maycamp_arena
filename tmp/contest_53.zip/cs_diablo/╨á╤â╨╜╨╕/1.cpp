#include<iostream>
#include<string.h>
using namespace std;

char a[100002], runa[102];

int main()
{
    int i,T,X;
    scanf("%s",a);
    X=strlen(a);
    scanf("%d",&T);
    for(int i=1; i<=T; i++)
    {
            scanf("%s",runa);
            if (strstr(a,runa)) printf("%d\n",X-strlen(strstr(a,runa)));
            else printf("-1\n");
    }
    
    //system("pause");
    return 0;
}
