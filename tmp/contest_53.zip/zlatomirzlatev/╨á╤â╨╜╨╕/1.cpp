#include <iostream>
using namespace std;
int a[128][128],n,m;
void read()
{
    int i,j;
    cin>>n>>m;
    for(i=0;i<n;i++)
    for(j=0;j<m;j++)
    cin>>a[i][j];
}
int max()
{
    int m1,i,j;
    m1=a[0][0];
    for(i=1;i<n;i++)
    for(j=1;j<m;j++)
    if(a[i][j]>m1) m1=a[i][j];
    return m1;
}
int main()
{
    read();
    cout<<max()<<endl;
    return 0;
}

