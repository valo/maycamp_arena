// greedy approach #1 - O(log(m))
#include <iostream>

long long numberOfOperations(long long n, long long m)
{
    if (n == m)
        return 0;

    if (n + 2 >= m)
        return 1;

    if (n + 4 >= m)
        return 2;

    if (n * 2 > m)
        return (1 + m - n) / 2;

    return 1 + m % 2 + numberOfOperations(n, m / 2);
}

int main()
{
    long long n, m;
    std::cin >> n >> m;
    std::cout << numberOfOperations(n, m) << "\n";
    return 0;
}
