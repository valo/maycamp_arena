// BFS approach - O(m - n)
#include <cstdio>
#include <algorithm>
#include <iostream>
#include <ext/hash_set>

const int MAX_QUEUE = 1000000;
int head, tail;
int queue[MAX_QUEUE];
int moves[MAX_QUEUE];

__gnu_cxx::hash_set<int> used;

void advance(int to, int newMoves)
{
     if (used.find(to) != used.end())
     {
                  return;
     }
     used.insert(to);
     queue[tail] = to;
     moves[tail] = newMoves;
     tail++;
     if (tail == MAX_QUEUE)
     {
              tail = 0;
     }
}

int numberOfOperationsBFS(int start, int target)
{
    if (start == target)
    {
              return 0;
    }
    used.clear();
    used.insert(start);
    queue[0] = start;
    moves[0] = 0;
    for (head = 0, tail = 1; head != tail; head++)
    {
        if (head == MAX_QUEUE)
        {
                 head = 0;
        }
        int current = queue[head];
        if (current * 2 <= target)
        {
                 advance(current * 2, moves[head] + 1);
        }
        advance(current + 2, moves[head] + 1);
        advance(current + 1, moves[head] + 1);
        if (used.find(target) != used.end())
        {
                         return moves[head] + 1;
        }
    }
}


int main()
{
    long long n,m;
    std::cin>>n>>m;
    std::cout<<numberOfOperationsBFS(n, m)<<"\n";
    
    fprintf(stderr, "%.4lf\n", (double)clock()/CLOCKS_PER_SEC);
    return 0;
}
