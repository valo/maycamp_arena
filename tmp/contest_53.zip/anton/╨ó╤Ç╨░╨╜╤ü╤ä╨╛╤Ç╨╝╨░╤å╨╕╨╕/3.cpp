// greedy approach #2 - O(log(m)*log(m))
#include <iostream>
#include <climits>

// finds the minimal number of operations required to reach the target if we start from zero
// and have a maximum of multiplicationsLeft multiplication operations available
// (that is only if limitedMultiplications is true, otherwise we can make an unlimited number of multiplications
// and then it is necessary to count them towards the answer as well)
long long numberOfOperationsLeft(long long target, bool limitedMultiplications, int multiplicationsLeft = 0)
{
    // we have reached the target -> do nothing
    if (target == 0)
    {
                return 0;
    }
    // we have an odd number -> subtract one
    if ((target & 1) == 1)
    {
                return 1 + numberOfOperationsLeft(target - 1, limitedMultiplications, multiplicationsLeft);
    }
    // we cannot make more multiplications (and we have a limited number of them) -> subtract two until we reach one
    if (limitedMultiplications && multiplicationsLeft == 0)
    {
                return target / 2 + numberOfOperationsLeft(target % 2, true, multiplicationsLeft);
    }
    // it is always optimal to subtract two in this situation... greedy magic :)
    if ((target & 2) == 2)
    {
                return 1 + numberOfOperationsLeft(target - 2, limitedMultiplications, multiplicationsLeft);
    }
    // none of the above is true -> divide by two
    if (limitedMultiplications)
    {
                // if we have a limited number of multiplications, then we have already counted them
                // and we just need to divide by two without adding anything to the answer
                return numberOfOperationsLeft(target / 2, true, multiplicationsLeft - 1);
    }
    else
    {
                // otherwise we have to count each multiplication
                return 1 + numberOfOperationsLeft(target / 2, false);
    }
}

long long numberOfOperations(long long start, long long target)
{
    long long result;
    switch (start)
    {
           case 0:
                // if the starting number is zero, then we can multiply by two as much as we like
                result = numberOfOperationsLeft(target, false);
                break;
           case 1:
                // if the starting number is one, then we can ternary search for the optimal number of multiplication operations
                // or, as in this case, we can just break when we find an answer that is worse than the current optimum
                result = LONG_LONG_MAX;
                for (int multiplications = 63 - __builtin_clzll(target); multiplications >= 0; multiplications--)
                {
                    long long temp = multiplications + numberOfOperationsLeft(target - (start << multiplications), true, multiplications);
                    if (temp <= result)
                    {
                             result = temp;
                    }
                    else
                    {
                             break;
                    }
                }
                break;
           default:
                // if the starting number is greater than one, then it is always optimal to multiply by two as much as possible
                int multiplications = 0;
                while ((start << (multiplications + 1)) <= target)
                {
                      multiplications++;
                }
                result = multiplications + numberOfOperationsLeft(target - (start << multiplications), true, multiplications);
    }
    return result;
}


int main()
{
    long long n, m;
    std::cin>> n >> m;
    std::cout << numberOfOperations(n, m) << "\n";
    return 0;
}
