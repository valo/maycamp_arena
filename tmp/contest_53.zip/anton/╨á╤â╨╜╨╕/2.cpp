#include <cstring>
#include <algorithm>
#include <iostream>
#include <ctime>
using namespace std;
#define maxs 131072
unsigned int hash1[maxs];
unsigned int hash2[maxs];
unsigned int d1[maxs];
unsigned int d2[maxs];
int sufa[maxs];
int tmin[2*maxs+10];
char a[100001];
int len;
int qlen;
int Q;
void h1()
	{
		int i;
		unsigned int b=31;
		d1[0]=1;
		for(i=1;i<len;i++)
			d1[i]=(d1[i-1]*b);
		unsigned int hash=0;
		unsigned int d=1;
			for(i=0;i<len;i++)
				{
					hash+=((a[i]-64)*d1[(len-1)-i]);
					hash1[i]=hash;
				}
	}






void h2()
	{
		int i;
		unsigned int b=27;
		d2[0]=1;
		for(i=1;i<len;i++)
			d2[i]=(d2[i-1]*b);
		unsigned int hash=0;
		unsigned int d=1;
			for(i=0;i<len;i++)
				{
					hash+=((a[i]-64)*d2[(len-1)-i]);
					hash2[i]=hash;
				}
	}





bool cmp(int i,int j)
	{
		int l=0,r;
		int mid;
		r=len/2;
		int ans=-1;
		int i1,j1;
		i1=i;
		j1=j;
		if(i1>j1) swap(i1,j1);
			while(l<=r)
				{
					mid=(l+r)/2;
					if(i+mid>len-1||j+mid>len-1)
						r=mid-1;
						else
							{
								unsigned int hash11,hash21,hash12,hash22;
								hash11=hash1[i+mid]-hash1[i-1];
								hash11*=d1[i];
								hash21=hash1[j+mid]-hash1[j-1];
								hash21*=d1[j];
								hash12=hash2[i+mid]-hash2[i-1];
								hash12*=d2[i];
								hash22=hash2[j+mid]-hash2[j-1];
								hash22*=d2[j];
									if(hash11==hash21&&hash12==hash22) 
									{ans=mid; l=mid+1;}
									
									else r=mid-1;
							}
				}
		if(i+ans+1>len-1) return 1;
		if(j+ans+1>len-1) return 0;
		if(a[i+ans+1]<a[j+ans+1]) return 1;
		else return 0;
}	

bool ssearch(char b[], pair <int,int> &p)
 {
  int l,r;
  l = 0;
  r = len - 1;
  int i = 0;
   for(i = 0; i < qlen; i++)
    {
     int templ,tempr;
      templ = l;
      tempr = r;
      int anslow = -1;
      int anshigh = -1;
       while(templ <= tempr)
        {
         int mid = (templ + tempr)/2;
         if(sufa[mid] + i > len) 
          {
           templ = mid + 1;
           continue;
          }
          if(a[sufa[mid] + i] >= b[i])
           {
            tempr = mid - 1;
            if(a[sufa[mid] + i] == b[i])
            {
             anslow = mid;
            } 
           } 
           else
           {
            templ = mid + 1;
           }
        }
        templ = l;
        tempr = r;
        while(templ <= tempr)
        {
         int mid = (templ + tempr)/2;
         if(sufa[mid] + i > len) 
          {
           templ = mid + 1;
           continue;
          }
          if(a[sufa[mid] + i] > b[i])
           {
            tempr = mid - 1;
            
           } 
           else
           {
            templ = mid + 1;
            if(a[sufa[mid] + i] == b[i])
            {
             anshigh = mid;
            } 
           }
         
        }
      
           if(anshigh == -1 || anslow == -1) return false;
         l = anslow;
         r = anshigh;  
     }
    p = pair <int,int> (l,r);
    return true;
 }

int rmq(int i,int &l,int &r,int &il,int &ir)
	{
		if(l==il&&r==ir) return tmin[i];
		int ll,lr,rl,rr;
		ll = il;
		lr = (il + ir)/2;
		rl = (il + ir)/2 + 1;
		rr = ir;
		if(l>=ll && l <= lr && r <= lr) return rmq(2*i,l,r,ll,lr);
		if(l>=rl && l <= rr && r <= rr) return rmq(2*i + 1,l,r,rl,rr);
		if(l>=ll && l <= lr && r >= rl && r <= rr) return min(rmq(2*i,l,lr,ll,lr),rmq(2*i + 1,rl,r,rl,rr));
	}


void precmp()
	{
		int i;
			for(i=maxs;i<=maxs+(len-1);i++)
				{
					tmin[i]=sufa[i-maxs];
				}	
			for(i=maxs-1;i>=1;i--)
				{
					tmin[i]=min(tmin[2*i],tmin[2*i+1]);
				}			
	}

			
int main()
{
	char b;
	int i;

	scanf("%s",&a);
	len = strlen(a);
    cin>>Q;
	h1();
	h2();
		for(i=0;i<len;i++)
			{
				sufa[i]=i;
			}
		sort(sufa,sufa+len,cmp);
	precmp();
     int j;
      char query[101];
      for(j = 1; j <= Q; j++)
       {
        scanf("%s",&query);
        qlen = strlen(query);
        pair <int,int> sol;
        int ans = ssearch(query,sol);
        if(ans) 
         {
       sol.first++;
       sol.second++;
       int t1,t2;
       t1 = 1;
       t2 = maxs;
         printf("%d\n",rmq(1,sol.first ,sol.second ,t1,t2));
         }
         else 
           printf("-1\n");
               }
    cerr<<double(clock())/CLOCKS_PER_SEC<<endl;
    //while(1);
	return 0;
}
