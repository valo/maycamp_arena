#include<iostream>
#include<string>
using namespace std;
int cmp(string a,string b)
{
    int i;
    if(a==b) return 0;
    if(a.size()>b.size()) return 1;
    if(a.size()<b.size()) return 2;
    for(i=0;i<a.size();i++)
    if(a[i]>b[i]) return 1;
    else if(a[i]<b[i]) return 2;
}
string trans(string a)
{
    string c="";
    int i,m=0;
    for(i=0;i<a.size();i++)
    {
        m=m*10+a[i]-'0';
        if(m/2||!c.empty()) c+=(m/2)+'0';
        m%=2;
    }
    return c;
}
int main()
{
    int n;
    string a,b;
    cin>>n>>a>>b;
    while(1)
    {
        if(cmp(a,b)==1) a=trans(a);
        else if(cmp(a,b)==0) break;
        else b=trans(b);
    }
    cout<<a<<endl;
    return 0;
}
