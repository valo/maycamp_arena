#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
#define MAXN 1000000000
using namespace std;
int a[15000],F[15000],n;
int cmp_3(int t1,int t2,int t3)
{
    vector<int>v;
    v.push_back(t1);
    v.push_back(t2);
    v.push_back(t3);
    sort(v.begin(),v.end());
    return v[2]+v[1];
}
int cmp_4(int t1,int t2,int t3,int t4)
{
    vector<int>v;
    v.push_back(t1);
    v.push_back(t2);
    v.push_back(t3);
    v.push_back(t4);
    sort(v.begin(),v.end());
    return v[3]+v[2]+v[1];
}
int main()
{
    int i;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    scanf("%d",&a[i]);
    F[1]=a[1];
    F[2]=a[1]+a[2];
    F[3]=min(F[2]+a[3],cmp_3(a[1],a[2],a[3]));
    F[4]=min(min(F[3]+a[4],F[1]+cmp_3(a[2],a[3],a[4])),cmp_4(a[1],a[2],a[3],a[4]));
    F[5]=min(min(F[4]+a[5],F[2]+cmp_3(a[3],a[4],a[5])),F[1]+cmp_4(a[2],a[3],a[4],a[5]));
    for(i=6;i<=n;i++)
    F[6]=min(min(F[i-1]+a[i],F[i-3]+cmp_3(a[i-2],a[i-1],a[i])),F[i-4]+cmp_4(a[i-3],a[i-2],a[i-1],a[i]));
    cout<<F[n]<<endl;
    return 0;
}
