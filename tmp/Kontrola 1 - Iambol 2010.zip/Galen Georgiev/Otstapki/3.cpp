#include<iostream>
#include<cstdio>
#include<algorithm>
#define MAXN 1000000000
using namespace std;
long long a[15000],n;
int main()
{
    long long i,j,sum=0;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    sort(a,a+n);
    for(i=n-1;i>=0;i--)
    if(i-2>=0)
    {
        int min=MAXN,ind;
        for(j=i;j>=i-2;j--)
        if(a[j]<min)
        {
            min=a[j];
            ind=j;
        }
        for(j=i;j>=i-2;j--)
        if(j!=ind) sum+=a[j];
        i-=2;
    }
    else sum+=a[i];
    printf("%d\n",sum);
    return 0;
}
