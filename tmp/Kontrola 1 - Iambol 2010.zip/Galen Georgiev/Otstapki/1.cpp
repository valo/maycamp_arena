#include<iostream>
#include<cstdio>
#include<algorithm>
#define MAXN 1000000000
using namespace std;
int a[15000],n;
void read()
{
    int i;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
}
int solve()
{
    int i,j,sum=0;
    sort(a,a+n);
    for(i=n-1;i>=0;i--)
    if(i-3>=0)
    {
        int min=MAXN,ind;
        for(j=i;j>=i-3;j--)
        if(a[j]<min)
        {
            min=a[j];
            ind=j;
        }
        for(j=i;j>=i-3;j--)
        if(j!=ind) sum+=a[j];
        i-=3;
    }
    else if(i-2>=0)
    {
        int min=MAXN,ind;
        for(j=i;j>=i-2;j--)
        if(a[j]<min)
        {
            min=a[j];
            ind=j;
        }
        for(j=i;j>=i-2;j--)
        if(j!=ind) sum+=a[j];
        i-=2;
    }
    else sum+=a[i];
    return sum;
}
int main()
{
    read();
    printf("%d\n",solve());
    return 0;
}
