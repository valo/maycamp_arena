#include<iostream>
#include<cstdio>
using namespace std;
int a[1024],ans[1024],n;
int main()
{
    int i,br=0;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
        ans[a[i]]++;
    }
    for(i=1;i<=n;i++)
    if(ans[i]==i) br++;
    if(br==1) printf("0\n");
    else printf("%d\n",br);
    return 0;
}
