#include <iostream>
using namespace std;
int a[1024];
int main()
{
    int n, cp[1024];
    cin >> n;
    for(int i=0; i<n; i++)
    {
            cin >> cp[i];
            a[cp[i]]++;
    }
    int res=0;
    for(int i=1; i<=n; i++)
    if(a[i]==i) res++;
    if(res==1) res--;
    cout << res << endl;
    return 0;
} 
