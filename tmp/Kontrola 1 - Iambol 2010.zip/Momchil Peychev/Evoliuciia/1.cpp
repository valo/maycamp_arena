/*
TASK: evo
LANG: C++
*/
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>

#define pb push_back

using namespace std;

int n;
string a,b;
vector<string> t;

void init()
{
    scanf("%d",&n);
    cin >> a >> b;
}

string div(string x)
{
    string ret;
    int s=0;

    for(int i=0;i<x.size();i++)
    {
        s*=10; s+=(x[i]-'0');
        if(i==0 && s==1) continue;
        ret.pb(s/2+'0');
        s%=2;
    }
    return ret;
}

void solve()
{
    for( ; ; )
    {
        if(a=="1") break;
        t.pb(a);
        a=div(a);
    }
    t.pb("1");
    for( ; ; )
    {
        for(int i=0;i<t.size();i++)
            if(b==t[i])
            {
                cout << b << endl;
                return;
            }
        b=div(b);
    }
}

int main()
{
    init();
    solve();

    return 0;
}
