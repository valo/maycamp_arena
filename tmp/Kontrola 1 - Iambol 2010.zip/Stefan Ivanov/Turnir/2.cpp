#include<iostream>
using namespace std;
long a[8192][8192],p1,p2,br;
void getnewtable (long x, long y)
{
   long i,j;
   for(i=1;i<=y;i++)
   {
      for(j=x+1;j<=2*x;j++)
      {
         a[j][i]=a[j-x][i]+p1;   
      }
   }
   for(i=y+1;i<=y*2;i++)
   {
      for(j=1;j<=x;j++)
      {
         a[j][i]=p2+1-a[j][i-y];
         a[a[j][i]][i]=j;
      }
   }
   for(i=1;i<=2*x;i++)
   {
      a[i][y*2+1]=p2-i+1;
   }
}
int main()
{
    long n,m,i,j,r1,r2;
    cin>>n;
    if (n==1) {cout<<2<<endl<<1<<endl;}
    else
    {
       a[1][1]=2;
       a[2][1]=1;
       r1=2;
       r2=1;
       p1=2;
       p2=4;
       while(1)
       {
          getnewtable(r1,r2);
          br++;
          p1=p1*2;
          p2=p2*2;
          r1=p1;
          r2=p1-1;
          if (br==n-1) {break;}
       }
       for(i=1;i<=r1;i++)
       {
          for(j=1;j<=r2;j++)
          {
             if (j==r2) {printf("%d\n",a[i][j]);}
             else {printf("%d ",a[i][j]);}
          }
       }
    }
    //system("pause");
    return 0;
}
       
    
