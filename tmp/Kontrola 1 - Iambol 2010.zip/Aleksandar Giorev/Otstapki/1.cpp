#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int MAXN = 10000 + 5;

int N, a[MAXN], s[MAXN], f[MAXN];

inline void update ( int &a, const int b ) {
	if ( a > b ) a = b;
}

int go ( int n ) {
	
	if ( !n ) return 0;
	
	int &ref = f[n];
	if ( ref != -1 ) return ref;
	
	ref = a[n] + go ( n-1 );
	if ( n >= 3 ) update ( ref, s[n]-s[n-2] + go ( n-3 ) );
	if ( n >= 4 ) update ( ref, s[n]-s[n-3] + go ( n-4 ) );
		
	return ref;
	
}

int main (void) {
	
	scanf ( "%d", &N );
	for ( int i=1; i<=N; ++i ) scanf ( "%d", a+i );
	
	sort ( a+1, a+1+N );
	for ( int i=1; i<=N; ++i ) s[i] = s[i-1] + a[i];
	
	memset ( f, -1, sizeof f );
	printf ( "%d\n", go ( N ) );
	
}
