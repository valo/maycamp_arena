#include <cstdio>

int const nmax=1024;
int a[nmax+1][nmax];
int k;

void tour(int s)
{
  int m,p,i,j;
  m=1<<s;
  if (s==1)
    {
      a[1][1] = 2;
      a[2][1] = 1;
    }
  else
    {
      tour(s-1);
      p=m/2;
      for (i=p+1;i<=m;i++)
        for (j=1;j<=(m-1);j++)
          a[i][j]=a[i-p][j]+p;
      for (i=1;i<=p;i++)
      {
        a[i][p]=p+i;
        a[p+i][p]=i;
      }
      for (j=(p+1);j<=(m-1);j++)
      {
        a[1][j]=a[p][j-1];
        a[a[1][j]][j]=1;
        for (i=2;i<=p;i++)
        {
          a[i][j]=a[i-1][j-1];
          a[a[i][j]][j]=i;
        }
      }
    }
}
int main()
{
  int n,i,j;
  scanf("%d", &k);
  tour(k);
  n=1<<k;
  for (i=1;i<=n;i++)
  {
    for (j=1;j<=(n-2);j++)
      printf("%d ",a[i][j]);
    printf ("%d\n",a[i][n-1]);
  }

  return 0;
}
