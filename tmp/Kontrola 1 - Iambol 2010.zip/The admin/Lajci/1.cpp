#include <iostream>

using namespace std;

int main()
{
  int ans[1001];
  int n,i,c;

  cin >> n;
  for (i=0;i<=n;i++)
    ans[i]=0;
  for (i=1;i<=n;i++)
    {
      cin >> c;
      ans[c]++;
    }
  c=0;
  for (i=1;i<=n;i++)
    if (ans[i]==i) c++;
  if (c==1)
    cout << 0 << endl;
  else
    cout << c << endl;
  return 0;
}
