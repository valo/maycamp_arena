#include <iostream>
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <stdlib.h>
#include <iomanip>
#include <fstream>
#include <set>

#define SP system("pause");
#define x first
#define y second
#define f( a, b ) for ( int i = a; i < b; i++ )
#define fm( a, b ) for ( int i = a; i >= b; i-- )

int maxn = 99999;

typedef long long int lli;

using namespace std;

int n;
int a[ 10005 ];

int main()
{
    cin >> n;
    for ( int i = 0; i < n; i++ ) cin >> a[ i ];
    sort( a, a + n );
    int p, t;
    lli sum = 0;
    int i;
    for ( i = n - 1; i > 1;  )
    {
        p = a[ i ] + a[ i - 1 ] + a[ i - 3 ];
        t = a[ i ] + a[ i - 1 ] + a[ i - 2 ];
        if ( p > t )
        {
            sum += p - a[ i - 3 ];
            i -= 3;
        }
        else if ( p <= t )
        {
            sum += t;
            i -= 4;
        }
    }
    if ( i == 1 ) 
    {
        sum += a[ i ];
        sum += a[ i - 1 ];
    }
    else if ( i == 0 )
    {
        sum += a[ i ];
    }
    cout << sum << endl;
        
	return 0;
}
