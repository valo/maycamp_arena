/*
FROM: SPRING 2002 A
PROB: selo
KEYW: triangulation
NOTE: worked first time!!
*/

#include <cstdio>
#include <cmath>

const int MAXN = 1 << 10;

struct point {
	int x, y;
	point () {}
	point (int _x, int _y) : x (_x), y (_y) {}
	point (const point &c) : x (c.x), y (c.y) {}
	int operator * (const point &a) const {return x * a.x + y * a.y;}
	point operator - (const point &a) const {return point (x - a.x, y - a.y);}
	int sq () {return (*this) * (*this);}
};

int N;
point vec[MAXN];
bool ma3x[MAXN][MAXN];

int _2S (const point &a, const point &b, const point &c) {
	return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}

double costh (const point &a, const point &b, const point &c) {
	return (double)((c - a).sq () + (c - b).sq () - (a - b).sq ()) / (2.0 * sqrt ((c - b).sq ()) * sqrt ((c - a).sq ()));
}

void input () {
	for (int i = 0; scanf ("%d %d", &vec[i].x, &vec[i].y) != EOF || (N = i, 0); ++i);
}

int tr (int a) {
	if (a > 0) return 1;
	if (a < 0) return -1;
	return 0;
}

void dfs (int a, int b, int c) {
	ma3x[a][b] = ma3x[b][a] = 1;
	int i;
	double ang_cos;
	double a2;
	int id;
	int expected = (tr (_2S (vec[a], vec[b], vec[c])) == 1 ? -1 : 1);

	for (i = 0; i < N; ++i) {//finds the first point on the right side
		if (i == a || i == b) continue;
		if (tr (_2S (vec[a], vec[b], vec[i])) == expected) {
			id = i;
			ang_cos = costh (vec[a], vec[b], vec[i]);
			break;
		}
	}
	if (i == N) return;

	for (++i; i < N; ++i) {
		if (i == a || i == b) continue;
		if (tr (_2S (vec[a], vec[b], vec[i])) == expected && (a2 = costh (vec[a], vec[b], vec[i])) < ang_cos) {
			id = i;
			ang_cos = a2;
		}
	}

	if (!ma3x[a][id]) dfs (a, id, b);
	if (!ma3x[b][id]) dfs (b, id, a);
}

void solve () {
	if (N < 3) return;
	//find the lowest-right point
	int id = 0;
	int i;
	for (i = 1; i < N; ++i)
		if (vec[i].y < vec[id].y || (vec[i].y == vec[id].y && vec[i].x > vec[id].x))
			id = i;

	//find the point standing next to id in the convex hull (positive rotation)
	int id2 = (id == 0 ? 1 : 0);
	int s;
	for (i = id2 + 1; i < N; (++i == id ? ++i : 0))
		if ((s = _2S (vec[id], vec[id2], vec[i])) < 0 || (s == 0 && (vec[id2] - vec[id]).sq () > (vec[i] - vec[id]).sq ()))
			id2 = i;

	ma3x[id][id2] = ma3x[id2][id] = 1;

	vec[N] = point (20001, 0);
	dfs (id, id2, N);
}

void output () {
	for (int i = 0; i < N; ++i)
		for (int j = i + 1; j < N; ++j)
			if (ma3x[i][j]) printf ("%d %d\n", i + 1, j + 1);
}

int main () {
	input ();
	solve ();
	output ();

	return 0;
}
