/*
PROB: dictionary
CONT: MayCamp round 10 20.04.2010
KEYW: RK + binary search
*/

#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

const int MAXN = 30001;
const int MAXLEN = 32;

const int K1 = 317;
const int MOD1 = 2295473;
const int K2 = 113;
const int MOD2 = 9064673;
const int K3 = 71;
const int MOD3 = 13657529;

int n;
int len[MAXN];
int prefixA[MAXN][MAXLEN], prefixB[MAXN][MAXLEN], prefixC[MAXN][MAXLEN];
int pA[MAXLEN], pB[MAXLEN], pC[MAXLEN];

void Init()
{
	char s[MAXLEN];

	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		{
			scanf("%s", &s); len[i] = strlen(s);
			prefixA[i][0] = 0; prefixB[i][0] = 0; prefixC[i][0] = 0;
			for (int j = 1; j <= len[i]; j++)
				{
					prefixA[i][j] = (int) ((long long)(prefixA[i][j - 1] * K1 + s[j - 1]) % MOD1);
					prefixB[i][j] = (int) ((long long)(prefixB[i][j - 1] * K2 + s[j - 1]) % MOD2);
					prefixC[i][j] = (int) ((long long)(prefixC[i][j - 1] * K3 + s[j - 1]) % MOD3);
				}
		}
}

void Solve()
{
	pA[0] = 0; pB[0] = 0; pC[0] = 0;

	char s[MAXLEN]; int l;
	scanf("%s", &s); l = strlen(s);

	int res = 0;
	int lf, rt, mid, i;

	for (i = 1; i <= l; i++)
		{
			pA[i] = (int) ((long long)(pA[i - 1] * K1 + s[i - 1]) % MOD1);
			pB[i] = (int) ((long long)(pB[i - 1] * K2 + s[i - 1]) % MOD2);
			pC[i] = (int) ((long long)(pC[i - 1] * K3 + s[i - 1]) % MOD3);
		}

	for (i = 0; i < n; i++)
		{
			lf = -1, rt = min(l, len[i]) + 1;
			while (lf + 1 < rt)
				{
					mid = lf + rt; mid = mid >> 1;
					if (pA[mid] == prefixA[i][mid] && pB[mid] == prefixB[i][mid] && pC[mid] == prefixC[i][mid])
						lf = mid;
					else
						rt = mid;
				}
			res += rt;
			if (rt == l + 1 && rt == len[i] + 1) break;
		}

	printf("%d\n", res);
}

int main()
{
	Init();

	int queries;
	scanf("%d", &queries);
	while (queries--)
		Solve();

	return 0;
}
