#include <iostream>
#include <set>

using namespace std;

struct Person
{
	int A, B, ind;
	Person(int _A = 0, int _B = 0, int _ind = 0)
	{ A = _A; B = _B; ind = _ind; }
};

struct cmpByB
{
	bool operator()(Person a, Person b)
	{
		if (a.B < b.B) return 1;
		if (a.B > b.B) return 0;

		if (a.A < b.A) return 1;
		if (a.A > b.A) return 0;

		return a.ind < b.ind;
	}
};

Person inp[200010];

int main()
{
	set < Person, cmpByB > ss;
	set < Person > :: iterator it;

	char op;
	int id, a, b, cntPeople = 0;

	int n;
	cin >> n;
	while (n--)
		{
			cin >> op;
			if (op == 'D')
				{
					cin >> a >> b;
					ss.insert(Person(a, b, cntPeople));
					inp[cntPeople] = Person(a, b, cntPeople);
					cntPeople++;
				}
			else
			if (op == 'P')
				{
					cin >> id;

					it = ss.upper_bound(Person(inp[id - 1].A, inp[id - 1].B, id - 1));
					while (it != ss.end())
						{
							a = (*it).A; b = (*it).B;
							if (inp[id - 1].A <= a && inp[id - 1].B <= b)
								{
									printf("%d\n", (*it).ind + 1);
									break;
								}
							it++;
						}

					if (it == ss.end()) printf("NE\n");
				}
		}

	return 0;
}
