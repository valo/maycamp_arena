#include<iostream>
//#include<fstream>
#include<string.h>
using namespace std;

char a[30002][31];
int rez[30002];

int min(int a, int b)
{
     return (a>b) ? b : a;
}

int Calculate(char niz[], int br)
{
     int ind=1, f=0, rezult=0, i;
     int lena, lenniz=strlen(niz);
     while ( ind<=br && !f)
     {
           lena=strlen(a[ind]);
           for(i=0; i<lenniz; i++)
                    if ( niz[i]!=a[ind][i]) break;
           i++;
           if ( lena==lenniz && i==lena+1 ) { rezult+=i; break; }
           rezult+=i;
           ind++;
           //cout<<ind<<" "<<i<<endl;
     }
     return rezult;
}
           

int main()
{
     int i,j,k,len,n,q;
     char duma[30];
     //ifstream cin("test.txt");
     
     scanf("%d",&n);
     //cin>>n;
     for(i=1; i<=n; i++) {
              scanf("%s",a[i]);
              //cin>>a[i];
              }
     
     scanf("%d",&q);
     //cin>>q;
     for(i=1; i<=q; i++)
     {
              scanf("%s",duma);
              //cin>>duma;
              rez[i]=Calculate(duma,n);
     }
     
     for(i=1; i<=q; i++)
              printf("%d\n",rez[i]);
              
     //system("pause");
     return 0;
}
