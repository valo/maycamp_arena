#include <iostream>
#include <cstring>
#include <set>
#include <vector>
#include <cmath>
using namespace std;

struct point
{
    double x, y;
    int no;

    bool operator<( const point& a ) const
    {
        if ( x == a.x )
            return y < a.y;
        return x < a.x;
    }
};

double dist( point a, point b )
{
    return sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
}

struct LS
{
    point a, b;
    bool operator<( const LS& x ) const
    {
        if ( a.no == x.a.no )
            return b.no < x.b.no;
        return a.no < x.a.no;
    }
};

LS make_LS( point a, point b )
{
    if ( b < a )
        swap( a, b );
    LS r;
    r.a = a;
    r.b = b;
    return r;
}

struct triangle
{
    point a, b, c;
    point O;
    double R;

    bool operator<( const triangle& t ) const
    {
        return O.x - R < t.O.x - t.R;
    }

    point calcO()
    {
        double a1, b1, c1, a2, b2, c2, D;
        a1 = 2*(a.x-b.x);
        b1 = 2*(a.y-b.y);
        c1 = a.x*a.x + a.y*a.y - b.x*b.x - b.y*b.y;

        a2 = 2*(a.x-c.x);
        b2 = 2*(a.y-c.y);
        c2 = a.x*a.x + a.y*a.y - c.x*c.x - c.y*c.y;

        D = a1*b2 - a2*b1;
        if ( D == 0 )
        {
            O = a;
            return O;
            cout << "ERROR\n";
            return a;
        }
        O.y = (c2*a1-c1*a2) / D;
        O.x = (b2*c1-b1*c2) / D;
        return O;
    }
    double calcR()
    {
        R = dist( a, O );
        return R;
    }
};

triangle make_tri( point a, point b, point c )
{
    triangle r;
    r.a = a;
    r.b = b;
    r.c = c;
    r.calcO();
    r.calcR();
    return r;
}

point make_point( double x, double y, int no )
{
    point r;
    r.x = x;
    r.y = y;
    r.no = no;
    return r;
}

int n;
point p[1024];
bool us[1024][1024];

multiset<triangle> T;
set<LS> S;
vector<LS> sol;

int main()
{
    int i, j, k;
    triangle t;
    multiset<triangle>::iterator it, jt;
    set<LS>::iterator ils;

    i = 1;
    while ( scanf( "%lf %lf", &p[i].x, &p[i].y ) == 2 )
    {
        p[i].no = i;
        i++;
    }
    n = i-1;

    sort( p + 1, p + n + 1 );

    T.insert( make_tri( make_point( -100000, -100000, -1 ), make_point( 0, 100000, -1 ), make_point( 100000, 0, -1 ) ) );
//    cout << (*T.begin()).O.x << " " << (*T.begin()).O.y << " " << (*T.begin()).R << endl;
    for ( k = 1; k <= n; k++ )
    {
        t = make_tri( p[k], p[k], p[k] );
//        cout << t.R << " " << t.O.x << " " << t.O.y << endl;
//        it = T.lower_bound( t );
//        cout << "AA " << (*it).a.no << " " << (*it).b.no << " " << (*it).c.no << endl;
        S.clear();
//        for ( ; ( it != T.end() ) && ( ( (*it).O.x+(*it).R >= t.O.x )); it = jt )
        for ( it = T.begin(); it != T.end(); it = jt )
        {
            jt = it;
            jt++;
            if ( dist( p[k], (*it).O ) <= (*it).R )
            {
//                cout << (*it).a.no << " " << (*it).b.no << " " << (*it).c.no << endl;
                ils = S.find( make_LS( (*it).a, (*it).b ) );
                if ( ils != S.end() )
                    S.erase( ils );
                else
                    S.insert( make_LS( (*it).a, (*it).b ) );

                ils = S.find( make_LS( (*it).a, (*it).c ) );
                if ( ils != S.end() )
                    S.erase( ils );
                else
                    S.insert( make_LS( (*it).a, (*it).c ) );

                ils = S.find( make_LS( (*it).c, (*it).b ) );
                if ( ils != S.end() )
                    S.erase( ils );
                else
                    S.insert( make_LS( (*it).c, (*it).b ) );
                T.erase( it );
            }
        }
        for ( ils = S.begin(); ils != S.end(); ils++ )
        {
            T.insert( make_tri( p[k], (*ils).a, (*ils).b ) );
        }
    }

    memset( us, 0, sizeof( us ) );
    for ( it = T.begin(); it != T.end(); it++ )
    {
        if ( ( (*it).a.no == -1 ) || ( (*it).b.no == -1 ) || ( (*it).c.no == -1 ) )
            continue;
        if ( us[(*it).a.no][(*it).b.no] == 0 )
        {
            us[(*it).a.no][(*it).b.no] = 1;
            us[(*it).b.no][(*it).a.no] = 1;
            sol.push_back( make_LS( (*it).a, (*it).b ) );
        }
        if ( us[(*it).c.no][(*it).b.no] == 0 )
        {
            us[(*it).c.no][(*it).b.no] = 1;
            us[(*it).b.no][(*it).c.no] = 1;
            sol.push_back( make_LS( (*it).c, (*it).b ) );
        }
        if ( us[(*it).a.no][(*it).c.no] == 0 )
        {
            us[(*it).c.no][(*it).a.no] = 1;
            us[(*it).a.no][(*it).c.no] = 1;
            sol.push_back( make_LS( (*it).a, (*it).c ) );
        }
    }

    sort( sol.begin(), sol.end() );

    for ( i = 0; i < sol.size(); i++ )
    {
        printf( "%d %d\n", sol[i].a.no, sol[i].b.no );
    }

    return 0;
}
