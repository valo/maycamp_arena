#include <iostream>
#include <cstring>
#include <set>
#include <vector>
#include <cmath>
using namespace std;

struct point
{
    double x, y;
};

double dist( point a, point b )
{
    return sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
}

struct triangle
{
    point a, b, c;
    point O;
    double R;

    point calcO()
    {
        double a1, b1, c1, a2, b2, c2, D;
        a1 = 2*(a.x-b.x);
        b1 = 2*(a.y-b.y);
        c1 = a.x*a.x + a.y*a.y - b.x*b.x - b.y*b.y;

        a2 = 2*(a.x-c.x);
        b2 = 2*(a.y-c.y);
        c2 = a.x*a.x + a.y*a.y - c.x*c.x - c.y*c.y;

        D = a1*b2 - a2*b1;
        if ( D == 0 )
        {
            cout << "ERROR\n";
            return a;
        }
        O.y = (c2*a1-c1*a2) / D;
        O.x = (b2*c1-b1*c2) / D;
        return O;
    }
    double calcR()
    {
        R = dist( a, O );
        return R;
    }
};

triangle make_tri( point a, point b, point c )
{
    triangle r;
    r.a = a;
    r.b = b;
    r.c = c;
    r.calcO();
    r.calcR();
    return r;
}

point make_point( double x, double y )
{
    point r;
    r.x = x;
    r.y = y;
    return r;
}

int n;
point p[1024];

triangle T[20020]; //mozhe i pove4e da mi trqbva;
int ne[20020], pr[20020];

int main()
{
    int i, j, k;

    i = 1;
    while ( scanf( "%lf %lf", &p[i].x, &p[i].y ) != 0 )
    {
        i++;
    }
    n = i-1;
}
