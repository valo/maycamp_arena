#include <iostream>
#include <cstring>
#include <set>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;

struct point
{
    double x, y;
    int no;

    bool operator<( const point& a ) const
    {
        if ( x == a.x )
            return y < a.y;
        return x < a.x;
    }
};

double dist( point a, point b )
{
    return sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
}

struct LS
{
    point a, b;
    bool operator<( const LS& x ) const
    {
        if ( a.no == x.a.no )
            return b.no < x.b.no;
        return a.no < x.a.no;
    }
};

LS make_LS( point a, point b )
{
    if ( b.no < a.no )
        swap( a, b );
    LS r;
    r.a = a;
    r.b = b;
    return r;
}

struct triangle
{
    point a, b, c;
    point O;
    double R;

    bool operator<( const triangle& t ) const
    {
        return O.x - R < t.O.x - t.R;
    }

    point calcO()
    {
        double a1, b1, c1, a2, b2, c2, D;
        a1 = 2*(a.x-b.x);
        b1 = 2*(a.y-b.y);
        c1 = a.x*a.x + a.y*a.y - b.x*b.x - b.y*b.y;

        a2 = 2*(a.x-c.x);
        b2 = 2*(a.y-c.y);
        c2 = a.x*a.x + a.y*a.y - c.x*c.x - c.y*c.y;

        D = a1*b2 - a2*b1;
        if ( D == 0 )
        {
            O = a;
            return O;
            cout << "ERROR\n";
            return a;
        }
        O.y = (c2*a1-c1*a2) / D;
        O.x = (b2*c1-b1*c2) / D;
        return O;
    }
    double calcR()
    {
        R = dist( a, O );
        return R;
    }
};

bool crossOtsOts( point a, point b, point c, point d ) //dail ots AB pres. CD
{
    double A1, A2, B1, B2, C1, C2;
    double det;
    point prt;
    A1 = b.y - a.y;
    B1 = a.x - b.x;
    C1 = A1*a.x + B1*a.y;

    A2 = d.y - c.y;
    B2 = c.x - d.x;
    C2 = A2*c.x + B2*c.y;

    det = A1*B2 - A2*B1;
    if ( det == 0 )
        return 0;

    prt.x = ( B2*C1 - C2*B1 ) / det;
    prt.y = ( A1*C2 - C1*A2 ) / det;

    if ( (prt.x < max( a.x, b.x ) ) && (prt.x > min( a.x, b.x ) ) && (prt.y<max(a.y,b.y)) && (prt.y>min(a.y,b.y)) )
    {
        if ( (prt.x < max( c.x, d.x ) ) && (prt.x > min( c.x, d.x ) ) && (prt.y<max(c.y,d.y)) && (prt.y>min(c.y,d.y)) )
            return true;
    }

    return false;
}

triangle make_tri( point a, point b, point c )
{
    triangle r;
    r.a = a;
    r.b = b;
    r.c = c;
    r.calcO();
    r.calcR();
    return r;
}

point make_point( double x, double y, int no )
{
    point r;
    r.x = x;
    r.y = y;
    r.no = no;
    return r;
}

typedef pair<int,int> pii;

pii MPI( int a, int b )
{
    if ( a > b )
        swap( a, b );
    pii r = make_pair( a, b );
    return r;
}

int n;
point p[1024];
bool us[1024][1024];

multiset<triangle> T;
//set<LS> S;
set<pii> S;
vector< pair<int,int> > sol;

int main()
{
    int i, j, k;
    triangle t;
    multiset<triangle>::iterator it, jt;
//    set<LS>::iterator ils;
    set<pii>::iterator ils;

    i = 1;
    while ( scanf( "%lf %lf", &p[i].x, &p[i].y ) == 2 )
    {
        p[i].no = i;
        i++;
    }
    n = i-1;

//    sort( p + 1, p + n + 1 );
    if ( n > 200 )
    {
        T.insert( make_tri( make_point( -50000000, -50000000, n+1 ), make_point( 0, 5000000000.0, n+2 ), make_point( 5000000000.0, 0, n+3 ) ) );
        p[n+1] = make_point( -50000000, -50000000, n+1 );
        p[n+2] = make_point( 0, 5000000000.0, n+2 );
        p[n+3] = make_point( 5000000000.0, 0, n+3 );
    }
    else
    {
        T.insert( make_tri( make_point( -500000, -500000, n+1 ), make_point( 0, 50000000.0, n+2 ), make_point( 50000000.0, 0, n+3 ) ) );
        p[n+1] = make_point( -500000, -500000, n+1 );
        p[n+2] = make_point( 0, 50000000.0, n+2 );
        p[n+3] = make_point( 50000000.0, 0, n+3 );
    }
    for ( k = 1; k <= n; k++ )
    {
//        t = make_tri( p[k], p[k], p[k] );
        S.clear();
        for ( it = T.begin(); it != T.end(); it = jt )
        {
            jt = it;
            jt++;
//            cout << p[k].x << " " << p[k].y << " " << p[k].no << " " << (*it).a.no << " " << (*it).b.no << " " << (*it).c.no << endl;
            if ( dist( p[k], (*it).O ) <= (*it).R )
            {
//                cout << "INSIDE " << (*it).a.no << " " << (*it).b.no << " " << (*it).c.no << endl;
//                ils = S.find( make_LS( (*it).a, (*it).b ) );
                ils = S.find( MPI( (*it).a.no, (*it).b.no ) );
                if ( ils != S.end() )
                    S.erase( ils );
                else
//                    S.insert( make_LS( (*it).a, (*it).b ) );
                    S.insert( MPI( (*it).a.no, (*it).b.no ) );

//                ils = S.find( make_LS( (*it).a, (*it).c ) );
                ils = S.find( MPI( (*it).a.no, (*it).c.no ) );
                if ( ils != S.end() )
                    S.erase( ils );
                else
//                    S.insert( make_LS( (*it).a, (*it).c ) );
                    S.insert( MPI( (*it).a.no, (*it).c.no ) );

//                ils = S.find( make_LS( (*it).c, (*it).b ) );
                ils = S.find( MPI( (*it).b.no, (*it).c.no ) );
                if ( ils != S.end() )
                    S.erase( ils );
                else
//                    S.insert( make_LS( (*it).c, (*it).b ) );
                    S.insert( MPI( (*it).b.no, (*it).c.no ) );
                T.erase( it );
            }
        }
        for ( ils = S.begin(); ils != S.end(); ils++ )
        {
            T.insert( make_tri( p[k], p[(*ils).first], p[(*ils).second] ) );
//            cout << "INSERT " << p[k].x << " " << p[k].y << ", " << (*ils).a.x << " " << (*ils).a.y << ", " << (*ils).b.x << " " << (*ils).b.y << endl;
        }
    }

    memset( us, 0, sizeof( us ) );
    for ( it = T.begin(); it != T.end(); it++ )
    {
//        if ( ( (*it).a.no < 0 ) || ( (*it).b.no < 0 ) || ( (*it).c.no < 0 ) )
        if ( ( (*it).a.no > n ) || ( (*it).b.no > n ) || ( (*it).c.no > n ) )
            continue;
        if ( us[(*it).a.no][(*it).b.no] == 0 )
        {
            us[(*it).a.no][(*it).b.no] = 1;
            us[(*it).b.no][(*it).a.no] = 1;
            sol.push_back( make_pair( (*it).a.no, (*it).b.no ) );
            if ( (*it).a.no > (*it).b.no )
                swap( sol[sol.size()-1].first, sol[sol.size()-1].second );
        }
        if ( us[(*it).c.no][(*it).b.no] == 0 )
        {
            us[(*it).c.no][(*it).b.no] = 1;
            us[(*it).b.no][(*it).c.no] = 1;
            sol.push_back( make_pair( (*it).c.no, (*it).b.no ) );
            if ( (*it).c.no > (*it).b.no )
                swap( sol[sol.size()-1].first, sol[sol.size()-1].second );
        }
        if ( us[(*it).a.no][(*it).c.no] == 0 )
        {
            us[(*it).c.no][(*it).a.no] = 1;
            us[(*it).a.no][(*it).c.no] = 1;
            sol.push_back( make_pair( (*it).a.no, (*it).c.no ) );
            if ( (*it).a.no > (*it).c.no )
                swap( sol[sol.size()-1].first, sol[sol.size()-1].second );
        }
    }

    sort( sol.begin(), sol.end() );

    for ( i = 0; i < sol.size(); i++ )
    {
        printf( "%d %d\n", sol[i].first, sol[i].second );
    }

    return 0;
}
