#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
using namespace std;

struct qword
{
    char x[32];
    int on;
    int pos;
    bool operator<( const qword &x ) const
    {
        return pos < x.pos;
    }
};

struct node
{
    char x;
    int wcount;
    int ew;
    int ne[32];
};

int n, q;

int sol[30020];

char di[30020][32];

int ltr, rt;
node tr[1000020];

qword w[30020];

void make_trie()
{
    int i, j, k;
    memset( tr, -1, sizeof( tr ) );

    ltr = 0;
    rt = 0;
    for ( k = 1; k <= n; k++ )
    {
        i = rt;
        for ( j = 0; j < strlen( di[k] ); j++ )
        {
            if ( tr[i].ne[di[k][j]-'a'] == -1 )
            {
                ltr++;
//                printf( "%d ", ltr );
                tr[i].ne[di[k][j]-'a'] = ltr;
            }
            i = tr[i].ne[di[k][j]-'a'];
        }
        tr[i].ew = k;
    }
}

int main()
{
    int i, j, k, l;

    scanf( "%d", &n );
    for ( i = 1; i <= n; i++ )
    {
        scanf( "%s", &di[i] );
    }

    scanf( "%d", &q );
    for ( i = 1; i <= q; i++ )
    {
        scanf( "%s", &w[i].x );
        w[i].on = i;
    }

    make_trie();

    for ( k = 1; k <= q; k++ )
    {
        i = rt;
        for ( j = 0; j < strlen( w[k].x ); j++ )
        {
            i = tr[i].ne[w[k].x[j]-'a'];
            if ( i == -1 )
            {
                break;
            }
        }
        if ( i == -1 )
            w[k].pos = n+1;
        else if ( tr[i].ew == -1 )
            w[k].pos = n+1;
        else
            w[k].pos = tr[i].ew;
    }

    sort( w + 1, w + q + 1 );

    l = 0; //dokade sam obrabotil bazata( trie-to )
    for ( k = 1; k <= q; k++ )
    {
        while ( ( l < w[k].pos ) && ( l < n ) )
        {
            l++;
            i = rt;
            for ( j = 0; j < strlen( di[l] ); j++ )
            {
                if ( tr[i].wcount < 0 )
                    tr[i].wcount = 0;
                tr[i].wcount++;

                i = tr[i].ne[di[l][j]-'a'];
//                if ( i == -1 )
//                    printf( "ERROR\n" );
            }
            if ( tr[i].wcount < 0 )
                tr[i].wcount = 0;
            tr[i].wcount++;
//            cout << "ADDTOTRIE " << l << " " << j << " " << "kraq" << " " << i << " " << tr[i].wcount << endl;
        }

//        cout << k << " " << w[k].pos << " " << w[k].on << " " << l << " " << w[k].x << endl;

        i = rt;
        for ( j = 0; j < strlen( w[k].x ); j++ )
        {
            if ( tr[i].wcount < 0 )
                tr[i].wcount = 0;
            sol[w[k].on] = sol[w[k].on] + tr[i].wcount;
            i = tr[i].ne[w[k].x[j]-'a'];
            if ( i == -1 )
                break;
        }
        if ( i != -1 )
            sol[w[k].on] = sol[w[k].on] + tr[i].wcount;
    }

    for ( i = 1; i <= q; i++ )
    {
        printf( "%d\n", sol[i] );
    }
    return 0;
}
