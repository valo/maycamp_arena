#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <set>
#include <map>
using namespace std;

struct el
{
    int A, B;
    int no;
    bool operator<( const el& x ) const
    {
        if ( A + B != x.A + x.B )
            return ( A + B ) < ( x.A + x.B );
        if ( A == x.A )
            return B < x.B;
        return A > x.A;
    }
};

int n;
int la;
el p[200020];
set<el> S;

int main()
{
    int i, j, k;
    el a;
    set<el>::iterator it;
    char tp[4];

    scanf( "%d", &n );
    la = 0;
    for ( i = 1; i <= n; i++ )
    {
        scanf( "%s", &tp );
        if ( tp[0] == 'D' )
        {
            la++;
            scanf( "%d %d", &p[la].A, &p[la].B );
            p[la].no = la;
            S.insert( p[la] );
        }
        else if ( tp[0] == 'P' )
        {
            scanf( "%d", &k );
            for ( it = S.upper_bound( p[k] ); it != S.end(); it++ )
            {
                a = (*it);
                if ( ( a.A >= p[k].A ) && ( a.B >= p[k].B ) )
                {
                    printf( "%d\n", a.no );
                    break;
                }
            }
            if ( it == S.end() )
                printf( "NE\n" );
        }
    }
    return 0;
}
