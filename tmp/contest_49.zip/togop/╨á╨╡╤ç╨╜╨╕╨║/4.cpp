#include <iostream>
#include <map>
using namespace std;

unsigned Max=2000000000;
map<unsigned, map<unsigned,unsigned> > ids;
unsigned xx[200000], yy[200000];

struct node
{
	unsigned l, r, n, u;
	node *a, *b, *c, *d;
	int br;
	node() { l=r=u=n=0; a=b=c=d=0; br=0; }
	node(unsigned _l, unsigned _r, unsigned _d, unsigned _u)
	{
		l=_l; r=_r; u=_u; n=_d; a=b=c=d=0; br=0;
		if(l>r || n>u) l=r=u=n=0;
	}
	void add(unsigned x, unsigned y)
	{
		br++;
		//cout<<"add "<<l<<' '<<r<<' '<<n<<' '<<u<<' '<<br<<' '<<x<<' '<<y<<endl;
		if(l==r && u==n) return;
		unsigned h=(n+u)/2, v=(l+r)/2;
		if(x<=v && y<=h) { if(a==0) a=new node(l, v, n, h); a->add(x,y); }
		else if(x<=v && y>h) { if(d==0) d=new node(l, v, h+1, u); d->add(x,y); }
		else if(x>v && y<=h) { if(b==0) b=new node(v+1, r, n, h); b->add(x,y); }
		else { if(c==0) c=new node(v+1, r, h+1, u); c->add(x,y); }
	}
	int q(unsigned _l, unsigned _r, unsigned _d, unsigned _u)
	{
		if(l>r || u<n) { l=r=u=n=br=0; a=b=c=d=0; }
		if(l>=_l && r<=_r && u<=_u && n>=_d) return br;
		if(_r<l || _l>r || _d>u || _u<n) return 0;
		int res=0;
		if(a) res+=a->q(_l,_r,_d,_u);
		if(b) res+=b->q(_l,_r,_d,_u);
		if(c) res+=c->q(_l,_r,_d,_u);
		if(d) res+=d->q(_l,_r,_d,_u);
		//cout<<"query "<<l<<' '<<r<<' '<<n<<' '<<u<<' '<<_l<<' '<<_r<<' '<<_d<<' '<<_u<<' '<<res<<'\n';
		return res;
	}
};

node* pts;
int find(unsigned x, unsigned y)
{
	unsigned l=x-1, r=Max, m;
	while(r-l>1)
	{
		m=(l+r)/2;
		if(pts->q(x,m,y,Max)>=2) r=m;
		else l=m;
	}
	unsigned X=r;
	l=y-1; r=Max; int mu=x==X?2:1;
	while(r-l>1)
	{
		m=(l+r)/2;
		//cout<<l<<' '<<r<<' '<<m<<' '<<X<<' '<<y<<' '<<pts->q(X,X,y,m)<<endl;
		if(pts->q(X,X,y,m)>=mu) r=m;
		else l=m;
	}
	unsigned Y=r;
	//cout<<X<<' '<<Y<<endl;
	return ids[X][Y];
}

int main()
{
	pts=new node(0,Max,0,Max);
	int q; cin>>q;
	unsigned x, y; char c;
	int i, j;
	for(i=j=0; i<q; i++)
	{
		cin>>c;
		if(c=='D') { cin>>y>>x; pts->add(x,y); ids[x][y]=j+1; xx[j+1]=x; yy[j+1]=y; ++j; }
		else { cin>>x; y=find(xx[x],yy[x]); if(y==0) cout<<"NE\n"; else cout<<y<<endl; }
		//else { cout<<pts->q(8,8,8,8)<<endl; }
	}
	return 0;
}
