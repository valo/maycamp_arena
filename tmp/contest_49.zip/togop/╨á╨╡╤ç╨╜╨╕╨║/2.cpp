#include <iostream>
#include <vector>
using namespace std;

//vector <string> w;
int inf=200000;

struct node
{
	int end;
	vector <int> thr;
	node *next[26];
	node() { end=inf; thr.clear(); for(int i=0; i<26; i++) next[i]=0; }
	
	void add(const char* c, int id)
	{
		thr.push_back(id);
		if(*c=='\0') { end=id; return; }
		if(next[*c-'a']==0) next[*c-'a']=new node;
		next[*c-'a']->add(c+1,id);
	}
	
	int dfs(const char* c, int &fid)
	{
		//cout<<c<<endl;
		int res=0;
		if(*c=='\0') fid=end;
		if(fid==-1)
		{
			if(next[*c-'a']==0) { fid=inf; res+=0; }
			else res+=next[*c-'a']->dfs(c+1, fid);
		}
		for(int i=0; i<(int)thr.size(); i++) if(thr[i]<=fid) ++res;
		//cout<<c<<' '<<res<<endl;
		return res;
	}
};

node* trie;

int main()
{
	trie=new node;
	int n; cin>>n; inf=n;
	string t;
	for(int i=0; i<n; ++i) { cin>>t; trie->add(t.c_str(), i); }
	int q, fid; cin>>q;
	for(int i=0; i<q; ++i) { cin>>t; fid=-1; cout<<trie->dfs(t.c_str(), fid)<<endl; }
	return 0;
}
