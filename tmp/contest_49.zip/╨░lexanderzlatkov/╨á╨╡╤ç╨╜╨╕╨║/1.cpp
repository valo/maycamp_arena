#include <cstdio>
#include <string.h>
#include <cstdlib>
#include <vector>
#include <utility>
#include <algorithm>
#define pb push_back
#define mp make_pair
#define sz size
using namespace std;

struct Trie{
    int ts,index;
    bool word;
    Trie *next[26];
};

Trie * T = new Trie;
int N,tr[30001];
bool can[30001],should_check[30001];
vector<pair<int,int> >ans;
char QW[30001][32],all[30001][32];


int cmpA(pair<int,int> a,pair<int,int> b){return a.second < b.second;}

void trie_add(char* key,int index,int v){
    Trie * cur = T;
    while(*key != '\0'){
        if(cur->next[*key - 'a'] == 0){
            cur->next[*key - 'a'] = new Trie;
            cur->ts = 0;
         }
        cur = cur->next[*key - 'a'];
        cur->ts += v;
        key++;
    }

       cur->index = index;
       cur->word = true;
}


int trie_find(char *key,int &index){;
     int cnt=0;
    Trie* cur = T;
    while(*key != '\0'){
        if(!cur->next[*key - 'a']){index = N;return cnt;}
        cur = cur->next[*key - 'a'];
        cnt += cur->ts;
        key++;
    }
  index = (cur->word) ? cur->index : N;
 return cnt;
}
int main(){
   char inp[32];
   char word[30001][32];


   int Q,i,j,index,curInd;
    scanf("%d",&N);
     for(i=0;i<N;i++){
         scanf("%s",word[i]);
         trie_add(word[i],i,0);
     }
   scanf("%d",&Q);
     for(i=0;i<Q;i++){
         scanf("%s",all[i]);
          trie_find(all[i],curInd);

          if(curInd != N){
          tr[curInd] = i+1;
          strcpy(QW[curInd],all[i]);

          }

          else
          should_check[i] = true;

     }

     i=j=0;
     int tkv,tki;

     for(;i<N;i++){
         trie_add(word[i],i,1);

     if(tr[i]){
            tkv = tki = 0;
            tkv = trie_find(QW[i],tki);
            ans.pb(mp(tkv+i+1,tr[i]-1));
      }
     }


      for(i=0;i<Q;i++)
      if(should_check[i]){
        tkv = tki = 0;
        tkv = trie_find(all[i],tki);
        ans.pb(mp(tkv+N,i));

      }

    sort(ans.begin(),ans.end(),cmpA);
    for(i=0;i<ans.sz();i++)
      printf("%d\n",ans[i].first);

 delete[] T;
return 0;
}
