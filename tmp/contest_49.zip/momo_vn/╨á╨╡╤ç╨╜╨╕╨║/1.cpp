#include <stdio.h>
#include <iostream>
#include <string.h>

using namespace std;

int n,q;
char s[30010][32],a[32];
int len[30010];

void read()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%s",&s[i]);
        len[i]=strlen(s[i]);
    }
}

int solve1()
{
    int ret=0;
    int llen=strlen(a);
    for(int i=0;i<n;i++)
    {
        bool fl=(len[i]==llen);
        bool wtf=true;
        for(int j=0;j<min(len[i],llen);j++)
        {
            ret++;
            if(a[j]!=s[i][j]) { wtf=false; fl=false; break; }
        }
        ret+=wtf;
        if(fl) break;
    }
    return ret;
}

void solve()
{
    scanf("%d",&q);
    for(int i=0;i<q;i++)
    {
        scanf("%s",&a);
        printf("%d\n",solve1());
    }
}

int main()
{
    read();
    solve();
    
    return 0;
}
