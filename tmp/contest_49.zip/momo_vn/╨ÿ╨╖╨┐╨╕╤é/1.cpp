#include <stdio.h>
#include <iostream>
#include <set>

using namespace std;

typedef struct
{
    int a,b,ind;
} student;

struct cmp
{
    bool operator()(student x, student y)
    {
        if(x.b<y.b) return true;
        if(x.b>y.b) return false;
        if(x.a<y.b) return true;
        return false;
    }
};

struct comp
{
    bool operator()(student x, student y)
    {
        if(x.b<y.b) return false;
        return true;
    }
};

int n;
int tek=1;
student all[200010];
set<student , cmp> s;
set<student , cmp> :: iterator it1, it2;
set<student , cmp> :: iterator it;
char op;

void print_set()
{
    for(it=s.begin();it!=s.end();it++) cout << (*it).a << " " << (*it).b << " " << (*it).ind << endl;
}

int main()
{
    scanf("%d\n",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%c",&op);
        if(op=='D')
        {
            int A,B;
            scanf("%d %d\n",&A,&B);
            all[tek].a=A; all[tek].b=B; all[tek].ind=tek;
            s.insert(all[tek]);
            tek++;
        }
        else
        {
            int ii;
            scanf("%d\n",&ii);
            all[ii].b++;
            //printf("%d\n",ii);
            //print_set();
            //cout << endl;
                  
            it=s.lower_bound(all[ii]);
            //cout << (*it).ind << endl;
            
            bool fl=false;
            for(it=it;it!=s.end();it++)
             if((*it).a>=all[ii].a) { printf("%d\n",(*it).ind); fl=true; break; }
            if(!fl) printf("NE\n");
            all[ii].b--;
        }
    }
    
    return 0;
}
