#include <iostream>
#include <map>
#include <algorithm>
#include <utility>
#include <vector>
#include <cstdio>
using namespace std;
string a[1 << 15];
vector < pair <string, int> > p[31];
map<string, int> mp;
int n;
void scan(){
    cin >> n;
    for ( int i = 0; i < n; ++i ){
        cin >> a[i];
   //     a[i] = "*" + a[i];
        mp[a[i]] = i;
    }
}
void predo(){
    for ( int k = 1; k <= 30; ++k ){
        for ( int i = 0; i < n; ++i )
            if ( a[i].size() >= k ) p[k].push_back(make_pair(a[i].substr(0, k), i));
        sort(p[k].begin(), p[k].end());
    }
}
int num( int k, pair<string, int> tmp){
    pair <string, int> tmp1 = make_pair(tmp.first, 0);
    int ind1 = lower_bound(p[k].begin(), p[k].end(), tmp1) - p[k].begin(),
        ind2 = upper_bound(p[k].begin(), p[k].end(), tmp) - p[k].begin();
    return ind2 - ind1;
}
int get(string tmp){
    int rez = 0, ind;
    if ( !mp.count(tmp) ) ind = n;
    else ind = mp[tmp];
    rez = ind;
    if ( ind != n ) ++rez;
    for ( int k = 1; k <= tmp.size(); ++k )
        rez += num(k, make_pair(tmp.substr(0, k), ind));
    return rez;
}
void solve(){
    predo();
    /*for ( int k = 1; k<= 31; ++k ){
        for ( int i = 0; i < p[k].size(); ++i )
            cout << p[k][i].first << " " << p[k][i].second << endl;
        cout << endl;
    }*/
    int m;
    cin >> m;
    string tmp;
    for ( int i = 0; i < m; ++i ){
        cin >> tmp;
        cout << get(tmp) << endl;
    }
}
int main(){
    scan();
    solve();
}
