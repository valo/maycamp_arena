#define _CRT_SECURE_NO_DEPRECATE
#include <iostream> 
#include <string>
#include <vector>
#include <sstream>
#include <queue>
#include <algorithm>
#include <iomanip>
#include <map>
#include <set>
#include <math.h>
#include <stack>
#include <deque>
#include <numeric>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <bitset>
#define mpair make_pair
#define all(v) v.begin(),v.end()
using namespace std;
typedef long long ll;
typedef long double ld;
const ld epsylon = 1e-9;
struct node{
	node *next[26];
	vector<int> a;
	bool end;
	node(){
		//broi = 0;
		for(int i=0;i<26;i++){
			next[i] = 0;
		}
		end = false;
	}
};
struct trie{
	node *root;
	int sz;
	trie(){
		root = new node;
		sz = 0;
	}
	void add(const string& w){
		node *c = root;
		root -> a.push_back(sz) ;
		for(int i=0;i<w.size();i++){
			if(c -> next[w[i]-'a']){
				c = c -> next[w[i]-'a'];
				c -> a.push_back(sz);
			}else{
				c -> next[w[i]-'a'] = new node;
				c = c -> next[w[i]-'a'];
				c -> a.push_back(sz);
			}
		}
		c -> end = true;
		sz++;
	}
	int lookup(const string& b){
		node *c = root;
		for(int i=0;i<b.size();i++){
			if(c ->next[b[i] - 'a']){
				c = c ->next[b[i] - 'a'];
			}else{
				return -1;
			}
		}
		if(c -> a.size()&&c->end){
			return c ->a[0];
		}else{
			return -1;
		}
	}
	int cnt(const string& b){
		int upto = lookup(b);
		if(upto == -1) upto = 100000000;
		node *c = root;
		int ans = upper_bound(all(c ->a),upto) - ((c->a).begin());
		for(int i = 0; i<b.size();i++){
			if(c -> next[b[i]-'a']){
				c = c -> next[b[i]-'a'];
				int idx = upper_bound(all(c ->a),upto) - ((c->a).begin());
				ans += idx;//c -> broi;
			}else{
				return ans;
			}
		}
		return ans;
	}
};
int main()
{
	//freopen("ivo.in","r",stdin);

	int n;
	cin>>n;
	char b[32];
	trie t;
	for(int i=0;i<n;i++){
		scanf("%s",b);
		t.add(b);
	}
	int m;
	cin>>m;
	for(int i=0;i<m;i++){
		scanf("%s",b);
		printf("%d\n",t.cnt(b));
	}	
	return 0;
}
