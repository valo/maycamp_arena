#include "stdio.h";
#include "stdlib.h";
#include "string.h";

#define MAXPRIM 30005
#define MAX 30

char *db[MAXPRIM];
char *q[MAXPRIM];
int N, Q;

void main ()
{
	//FILE *fin  = fopen ("p2.in", "r");
	//fscanf(fin, "%d", &N);

	scanf("%d", &N);
	int dbCount = 0;
	for(int i = 0;i < N;i++)
	{
		db[dbCount] = new char[MAX];
		//fscanf (fin, "%s", db[dbCount++]);
		scanf ("%s", db[dbCount++]);
	}

	//fscanf(fin, "%d", &Q);
	scanf("%d", &Q);

	int qCount = 0;
	for(int i = 0;i < Q;i++)
	{
		q[qCount] = new char[MAX];
		//fscanf (fin, "%s", q[qCount++]);
		scanf ("%s", q[qCount++]);
	}

	//foreach query
	for(int i = 0;i < Q;i++)
	{
		int ans = 0;
		//foreach word in db
		for(int k = 0;k < N;k++)
		{
			bool found = false;
			int f = 0, s = 0;
			while(db[k][f] != '\0' && q[i][s] != '\0')
			{
				if(db[k][f++] != q[i][s++])
					break;
				else
					ans++;

				if(db[k][f] == '\0' && q[i][s] == '\0')
				{
					found = true;
					break;
				}
			}

			ans++;
			if(found)
				break;
		}

		printf("%d\n", ans);
	}
}
