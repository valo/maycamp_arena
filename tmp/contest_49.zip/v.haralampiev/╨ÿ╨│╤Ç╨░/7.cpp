#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include <cmath>
#include <utility>
#define F first
#define S second
#define razm 1000
using namespace std;
int mini(int a,int b){return (a<b)?a:b;}
int maxi(int a,int b){return (a>b)?a:b;}
struct point{
  int x,y;point(){}point(int a,int b){x=a;y=b;}
  point operator-(point& w){return point(x-w.x,y-w.y);}
  bool operator==(const point& w) const{return (x==w.x&&y==w.y);}
};
vector<point> p;int n;
struct line{
  int f,t,d;line(){}line(int a,int b){f=a;t=b;d=(p[a].x-p[b].x)*(p[a].x-p[b].x)+(p[a].y-p[b].y)*(p[a].y-p[b].y);}
  bool operator<(const line& w) const{return d<w.d;}
};
struct tr_line{
  int f,t;
  tr_line(){}tr_line(int a,int b){if(a<b){f=a;t=b;}else{f=b;t=a;}}
  bool operator<(const tr_line& w)const{
   if(f<w.f) return true;if(f>w.f) return false;
   return (t<w.t);
                                       }
};
void remove(pair<vector<int>,bool>& w, int d){
    int i;
    for(i=0;i<w.F.size();i++)if(w.F[i]==d)break;
    if(i<w.F.size())w.F.erase(w.F.begin()+i);
}
vector<line> use;
int sp(int f,int s,int t){
  int S=(p[f].x-p[s].x)*(p[f].y+p[s].y)+(p[s].x-p[t].x)*(p[s].y+p[t].y)+(p[t].x-p[f].x)*(p[t].y+p[f].y);
  if(S==0) return 0;if(S<0) return -1;if(S>0) return 1;
}
inline bool is_between(point f,point t,point w){
  if(w==f||w==t) return false;
  return (mini(f.x,t.x)<=w.x&&w.x<=maxi(f.x,t.x)&&mini(f.y,t.y)<=w.y&&w.y<=maxi(f.y,t.y));
}
inline bool does_intersect(tr_line a,line b){
  if(sp(a.f,a.t,b.f)==0 && sp(a.f,a.t,b.t)==0){
    if(is_between(p[b.f],p[b.t],p[a.f]) || is_between(p[b.f],p[b.t],p[a.t])) return true;
    return false;
                                              }
  if(sp(a.f,a.t,b.f)*sp(a.f,a.t,b.t)>=0) return false;
  if(sp(b.f,b.t,a.f)*sp(b.f,b.t,a.t)>=0) return false;
  return true;
}
vector<tr_line> tr;map<tr_line,pair<vector<int>,bool> > in;
vector<int> nasl[razm];
typedef map<tr_line,pair<vector<int>,bool> > data;
// Delaune triangulation
int dp(point f,point s){return (f.x*s.x+f.y*s.y);} // Scalqrnoe proizv.
int cp(point f,point s){return abs(f.x*s.y-f.y*s.x);} // Vectornoe proizv.
bool need_flip(int lb,int le,int a,int b){
  int P=cp(p[a]-p[lb],p[a]-p[le])*dp(p[b]-p[lb],p[b]-p[le])+dp(p[a]-p[lb],p[a]-p[le])*cp(p[b]-p[lb],p[b]-p[le]);
  if(P<0)return true;return false;
}
data::iterator it,tek;
vector< data::iterator > base;
// ANSWER PART
set<pair<int,int> > fp;
int main(){
  int i,j,k,l;
  //system("pause");
  n=0;
  while(cin>>j>>k){p.push_back(point(j,k));n++;}
  for(i=0;i<n;i++)
   for(j=i+1;j<n;j++) use.push_back(line(i,j));
  sort(use.begin(),use.end());
  l=use.size();
  bool ok;
  for(i=0;i<l;i++){
   ok=true;
   for(j=0;j<tr.size();j++)
    if(does_intersect(tr[j],use[i])){ok=false;break;}
   if(ok){
    nasl[use[i].f].push_back(use[i].t);nasl[use[i].t].push_back(use[i].f);
    tr.push_back(tr_line(use[i].f,use[i].t));
    in.insert(make_pair(tr_line(use[i].f,use[i].t),pair<vector<int>,bool>()));
         }
                  }
  for(i=0;i<n;i++){
   l=nasl[i].size();
   for(j=0;j<l;j++)
    for(k=j+1;k<l;k++){
     it=in.find(tr_line(nasl[i][j],nasl[i][k]));
     if(it!=in.end())it->S.F.push_back(i);
                      }
                  }
  for(it=in.begin();it!=in.end();it++){
   it->S.S=true;
   base.push_back(it);
                                      }
  int A,B,C,D;
  while(!base.empty()){
    tek=base.back();base.pop_back();tek->S.S=false;
    if(tek->S.F.size()<2) continue;
    A=tek->F.f;B=tek->F.t;C=tek->S.F[0];D=tek->S.F[1];
    if(!need_flip(A,B,C,D)) continue;
    in.erase(tek);
    it=in.find(tr_line(A,C));remove(tek->S,B);tek->S.F.push_back(D);if(it->S.S==false){it->S.S=true;base.push_back(it);}
    it=in.find(tr_line(C,B));remove(tek->S,A);tek->S.F.push_back(D);if(it->S.S==false){it->S.S=true;base.push_back(it);}
    it=in.find(tr_line(B,D));remove(tek->S,A);tek->S.F.push_back(C);if(it->S.S==false){it->S.S=true;base.push_back(it);}
    it=in.find(tr_line(A,D));remove(tek->S,B);tek->S.F.push_back(C);if(it->S.S==false){it->S.S=true;base.push_back(it);}
    in.insert(make_pair(tr_line(C,D),pair<vector<int>,bool>()));it=in.find(tr_line(C,D));it->S.F.push_back(A);it->S.F.push_back(B);
                      }
  for(it=in.begin();it!=in.end();it++)fp.insert(make_pair(mini(it->F.f,it->F.t),maxi(it->F.f,it->F.t)));
  for(set<pair<int,int> >::iterator IT=fp.begin();IT!=fp.end();IT++) cout<<IT->F+1<<' '<<IT->S+1<<'\n';
  //system("pause");
  return 0;
}
