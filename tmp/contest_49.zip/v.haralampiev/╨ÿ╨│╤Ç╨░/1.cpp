#include <iostream>
#include <set>
using namespace std;
// STORING INTERVALS
struct interval{
  int f,t;interval(){}interval(int a,int b){if(a<b){f=a;t=b;}else{f=b;t=a;}}
  bool operator<(const interval& w)const{
   if(f<w.f) return true;if(f>w.f) return false;
   return (t<w.t);
                                        }
};
set<interval> fp;
// </end>
struct vect3d{
 int x,y,z;vect3d(){}vect3d(int a,int b,int c){x=a;y=b;z=c;}
 int sp(vect3d w){return (x*w.x+y*w.y+z*w.z);}
 vect3d lp(vect3d w){return vect3d(y*w.z-w.y*z,-x*w.z+w.x*z,x*w.y-w.x*y);}
 vect3d operator-(vect3d w){return vect3d(x-w.x,y-w.y,z-w.z);}
 void reverse(){x*=-1;y*=-1;z*=-1;}
};
struct plane{
vect3d zero,lp;
plane(vect3d a,vect3d b,vect3d c){zero=a;b=b-a;c=c-a;lp=b.lp(c);}
int get_or(vect3d w){
  w=w-zero;int sp=w.sp(lp);
  if(sp>0) return 1;if(sp<0) return -1;return 0;
                    }
};
int n;
vect3d vhod[100];
int main(){
  //system("pause");
  int i,j,k,l,x,y,z;
  n=0;
  while(cin>>x>>y){
   vhod[n]=vect3d(x,y,x*x+y*y);
   n++;
                  }
  int bro,brp;
  for(i=0;i<n;i++)
   for(j=i+1;j<n;j++)
    for(k=j+1;k<n;k++){
     bro=brp=0;
     plane tmp=plane(vhod[i],vhod[j],vhod[k]);
     for(l=0;l<n;l++){
      x=tmp.get_or(vhod[l]);
      if(x>0) brp++;if(x<0) bro++;
                     }
     if(bro*brp==0){
       if(bro>0) tmp.lp.reverse();
       if(tmp.lp.z>=0){
         fp.insert(interval(i,j));
         fp.insert(interval(j,k));
         fp.insert(interval(i,k));
         //printf("%d - %d - %d\n",i,j,k);
                      }
                   }
                      }
  set<interval>::iterator it;
  interval TMP;
  for(it=fp.begin();it!=fp.end();it++){
    TMP=*it;
    cout<<TMP.f+1<<' '<<TMP.t+1<<'\n';
                                      }
  //system("pause");
  return 0;
}
