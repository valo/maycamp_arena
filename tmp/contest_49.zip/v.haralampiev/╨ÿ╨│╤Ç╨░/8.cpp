#include <cstdio>
#include <vector>
#include <algorithm>
#include <map>
#include <cmath>
#define F first
#define S second 
using namespace std;
struct point{
 int x,y;point(){}point(int a,int b){x=a;y=b;}
 point operator-(const point& w)const{return point(x-w.x,y-w.y);}
};
int n;
vector<point> u;
bool used[1000];
int os(int f,int s,int t){
  int st=(u[f].x-u[s].x)*(u[f].y+u[s].y)+(u[s].x-u[t].x)*(u[s].y+u[t].y)+(u[t].x-u[f].x)*(u[t].y+u[f].y);
  if(st==0)return 0;if(st>0)return 1;return -1;
}
int mod(int f,int t){return (u[t].x-u[f].x)*(u[t].x-u[f].x)+(u[t].y-u[f].y)*(u[t].y-u[f].y);}
class compare{
 public:int b;compare(int a){b=a;}
 bool operator()(const int& f,const int& s)const{
  int S=os(b,f,s);if(S>0)return true;if(S<0)return false;
  return (mod(b,f)<mod(b,s));
                                                }
};
vector<int> base;
vector<int> hull;
void create_hull(){
  int i,j,k;base.clear();hull.clear();
  for(i=0;i<n;i++)if(!used[i])base.push_back(i);
  for(i=1;i<base.size();i++)
   if(u[base[i]].y<u[base[0]].y||(u[base[i]].y==u[base[0]].y&&u[base[i]].x<u[base[0]].x)){j=base[0];base[0]=base[i];base[i]=j;}
  sort(base.begin()+1,base.end(),compare(base[0]));
  i=base.size()-2;
  while(i>=0){
    if(os(base[i],base.back(),base[0])!=0)break;
    i--;
             }
  i++;j=base.size()-1;
  while(i<j){k=base[i];base[i]=base[j];base[j]=k;i++;j--;}
  for(i=0;i<base.size();i++){
   while(hull.size()>1){
    if(os(hull[hull.size()-2],hull.back(),base[i])>=0) break;
    hull.pop_back();
                       }
   hull.push_back(base[i]);
                            }
}
// CREATING TRIANGULATION
struct line{
 int f,t;line(){}line(int a,int b){if(a<b){f=a;t=b;}else{f=b;t=a;}}
 bool operator<(const line& w)const{
  if(f<w.f)return true;if(f>w.f)return false;
  return (t<w.t);
                                   }
};
struct data{
  vector<int> su;bool used;
  void remove(int w){int i;for(i=0;i<su.size();i++)if(su[i]==w) break;if(i<su.size())su.erase(su.begin()+i);}
};
map<line,data> tr;map<line,data>::iterator it;
int add(int p,int how){return (p+hull.size()+how)%(hull.size());}
void add_edge(int f,int t){tr[line(f,t)]=data();}
bool create_next(){
  bool is_line=true;
  int i,j,B,L,R;
  create_hull();
  B=hull[0];L=hull[1];R=hull.back();
  used[B]=true;create_hull();
  for(i=0;i<hull.size();i++)if(os(hull[i],hull[add(i,1)],hull[add(i,2)])!=0){is_line=false;break;}
  if(is_line){
   for(i=0;i<hull.size();i++)add_edge(B,hull[i]);
   for(i=0;i<hull.size()-1;i++)add_edge(hull[i],hull[add(i,1)]);
   return false;
             }
  for(i=0;i<hull.size();i++)if(hull[i]==L){L=i;break;}
  for(i=0;i<hull.size();i++)if(hull[i]==R){R=i;break;}
  for(i=R;i!=L;i=add(i,1))add_edge(B,hull[i]);
  add_edge(B,hull[L]);
  for(i=0;i<hull.size();i++)add_edge(hull[i],hull[add(i,1)]);
  return true;
}
void solve(){while(create_next());}
// DELONE_TRIANGULATION
int sp(point f,point s){return f.x*s.x+f.y*s.y;}
int vp(point f,point s){return abs(f.x*s.y-f.y*s.x);}
bool need_flip(point f,point t,point a,point b){return (vp(f-a,t-a)*sp(f-b,t-b)+vp(f-b,t-b)*sp(f-a,t-a))<0;}
vector<line> sta;
vector<int> ne[1000];
void delone_tr(){
  int i,j,k,l;solve();
  for(it=tr.begin();it!=tr.end();it++){ne[it->F.f].push_back(it->F.t);ne[it->F.t].push_back(it->F.f);}
  for(i=0;i<n;i++){
   l=ne[i].size();
   for(j=0;j<l;j++)
    for(k=j+1;k<l;k++){
     it=tr.find(line(ne[i][j],ne[i][k]));
     if(it!=tr.end())it->S.su.push_back(i);
                      }
                  }
  for(it=tr.begin();it!=tr.end();it++){it->S.used=true;sta.push_back(it->F);}
  int A,B,C,D;
  while(!sta.empty()){
   A=sta.back().f;B=sta.back().t;sta.pop_back();
   tr[line(A,B)].used=false;
   if(tr[line(A,B)].su.size()<2) continue;
   C=tr[line(A,B)].su[0];D=tr[line(A,B)].su[1];
   if(!need_flip(u[A],u[B],u[C],u[D])) continue;
   tr[line(A,C)].remove(B);tr[line(C,B)].remove(A);
   tr[line(B,D)].remove(A);tr[line(D,A)].remove(B);
   tr.erase(tr.find(line(A,B)));
   tr[line(C,D)].used=false;tr[line(C,D)].su.push_back(A);tr[line(C,D)].su.push_back(B);
   tr[line(A,C)].su.push_back(D);tr[line(C,B)].su.push_back(D);
   tr[line(B,D)].su.push_back(C);tr[line(A,D)].su.push_back(C);
   if(!tr[line(A,C)].used){tr[line(A,C)].used=true;sta.push_back(line(A,C));}if(!tr[line(C,B)].used){tr[line(C,B)].used=true;sta.push_back(line(C,B));}
   if(!tr[line(B,D)].used){tr[line(B,D)].used=true;sta.push_back(line(B,D));}if(!tr[line(D,A)].used){tr[line(D,A)].used=true;sta.push_back(line(D,A));}
                     }
}
int main(){
  int i,j,x,y;
  //system("pause");
  n=0;
  while(scanf("%d%d",&x,&y)!=EOF){u.push_back(point(x,y));n++;}
  delone_tr();
  for(it=tr.begin();it!=tr.end();it++)printf("%d %d\n",it->first.f+1,it->first.t+1);
  //system("pause");
  return 0;
}
