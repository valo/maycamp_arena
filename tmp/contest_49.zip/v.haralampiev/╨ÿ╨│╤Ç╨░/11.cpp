#include <cstdio>
#include <algorithm>
#include <vector>
#include <cmath>
#include <set>
#include <queue>
#include <map>
#include <utility>
using namespace std;
struct triang{
  int ver[3];
  triang(int a=0,int b=0,int c=0){ver[0]=a;ver[1]=b;ver[2]=c;sort(ver,ver+3);}
  bool operator<(const triang& w)const{
    for(int i=0;i<3;i++){
     if(ver[i]<w.ver[i])return true;
     if(ver[i]>w.ver[i])return false;
                        }
    return false;
                                      }
};
struct point{
 double x,y,z;point(double a=0,double b=0,double c=0){x=a;y=b;z=c;}
 bool operator<(const point& w)const{
  if(x<w.x)return true;if(x>w.x)return false;
  if(y<w.y)return true;if(y>w.y)return false;
  return (z<w.z);
                                    }
 point operator+(point w){return point(x+w.x,y+w.y,z+w.z);}
 point operator-(point w){return point(x-w.x,y-w.y,z-w.z);}
 point operator*(double w){return point(x*w,y*w,z*w);}
};
double len(point w){return sqrt(w.x*w.x+w.y*w.y+w.z*w.z);}
double sp(point a,point b){return (a.x*b.x+a.y*b.y+a.z*b.z);}
point perp(point A,point B,point C){ // perp from C to AB
  double a=len(B-C),b=len(A-C),c=len(A-B);
  double cosa=(b*b+c*c-a*a)/(2*b*c);
  point gr=A+((B-A)*((cosa*b)/c));
  return (C-gr);
}
vector<point> vhod;
int get_follower(int eb,int ee,int ts){// edge begin, edge end, third side
  point bp=perp(vhod[eb],vhod[ee],vhod[ts]);
  double min_cos=1000;int p=-1;
  for(int i=0;i<vhod.size();++i){
   if(i==eb || i==ee || i==ts)continue;
   point TMP=perp(vhod[eb],vhod[ee],vhod[i]);
   double TC=sp(TMP,bp)/(2*len(TMP)*len(bp));
   if(TC<min_cos){min_cos=TC;p=i;}
                                }
  return p;
}
set<triang> in;
queue<triang> use;
void HULL(){
  sort(vhod.begin(),vhod.end());
  in.insert(triang(0,1,2));
  use.push(triang(0,1,2));
  triang TMP,next;int P;
  while(!use.empty()){
   TMP=use.front();use.pop();
   P=get_follower(TMP.ver[0],TMP.ver[1],TMP.ver[2]);
   if(P!=-1){next=triang(TMP.ver[0],TMP.ver[1],P);if(in.find(next)==in.end()){in.insert(next);use.push(next);}}
   P=get_follower(TMP.ver[1],TMP.ver[2],TMP.ver[0]);
   if(P!=-1){next=triang(TMP.ver[1],TMP.ver[2],P);if(in.find(next)==in.end()){in.insert(next);use.push(next);}}
   P=get_follower(TMP.ver[0],TMP.ver[2],TMP.ver[1]);
   if(P!=-1){next=triang(TMP.ver[0],TMP.ver[2],P);if(in.find(next)==in.end()){in.insert(next);use.push(next);}}
                     }
}
// CREATING DELONE TRIANGULATION
vector<int> nasl[1010],tr[1010];
bool in_hull[1010];
void init(){
  HULL();
  for(set<triang>::iterator it=in.begin();it!=in.end();it++){
   int a=it->ver[0],b=it->ver[1],c=it->ver[2];
   nasl[a].push_back(b);nasl[a].push_back(c);
   nasl[b].push_back(a);nasl[b].push_back(c);
   nasl[c].push_back(a);nasl[c].push_back(b);
                                                          }
  int t=0,beg=0,next,i,p;
  point vect(0,-1);in_hull[0]=true;
  double mcos,tcos;
  do{
   mcos=-1000;p=beg;
   for(i=0;i<nasl[t].size();i++){
    tcos=sp(vhod[nasl[t][i]]-vhod[t],vect)/(2*len(vhod[nasl[t][i]]-vhod[t]));
    if(tcos<=mcos)continue;
    mcos=tcos;p=nasl[t][i];
                                }
   in_hull[p]=true;
   vect=vhod[p]-vhod[t];vect=vect*(1/len(vect));
   tr[t].push_back(p);tr[p].push_back(t);
   t=p;
  }while(t!=beg);
}
void delone(){
  int i,j,p;
  init();
  for(i=0;i<vhod.size();i++)
   for(j=0;j<nasl[i].size();j++){
    p=nasl[i][j];
    if(!in_hull[i] || !in_hull[p])tr[i].push_back(p);
                                }
}
map<point,int> num;
set<pair<int,int> >fp;
int main(){
  int i(0),j,x,y,z;
  point T;
  while(scanf("%d%d",&x,&y)!=EOF){
   T=point(x,y,x*x+y*y);vhod.push_back(T);
   num[T]=i++;
                                 }
  delone();
  for(i=0;i<vhod.size();i++)
   for(j=0;j<tr[i].size();j++){
    x=num[vhod[i]];y=num[vhod[tr[i][j]]];
    if(x<y)fp.insert(make_pair(x+1,y+1));
                              }
  for(set<pair<int,int> >::iterator it=fp.begin();it!=fp.end();it++)
   printf("%d %d\n",it->first,it->second);
  return 0;
}
