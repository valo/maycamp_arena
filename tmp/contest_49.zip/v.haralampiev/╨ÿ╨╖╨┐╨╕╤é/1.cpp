//#include <iostream>
#include <cstdio>
#include <map>
#include <vector>
#define razm 262144
using namespace std;
vector<char> op;
vector<int> A,B,ui;
struct data{
 int a,b;data(){}data(int x,int y){a=x;b=y;}
 bool operator<(const data& w)const{
  if(b<w.b)return true;if(b>w.b) return false;
  return (a<w.a);
                                   }
};
map<data,int> use;
map<data,int>::iterator it;
map<int,int> fp;
int n;
// INDEX TREE
int tree[2*razm];
void init(){for(int i=2*razm-1;i>0;i--)tree[i]=n;}
void push(int w){
  int p=B[w]+razm;
  if(A[tree[p]]>=A[w])return;
  tree[p]=w;p/=2;
  while(p>0){if(A[tree[p]]>=A[w])return;tree[p]=w;p/=2;}
}
int get(int p,int f,int t,int sa,int sb){
  if(t<sb||A[tree[p]]<sa) return -1;
  if(p>=razm) return tree[p];
  int ans=-1;
  if(A[tree[2*p]]>=sa && sb<=(f+t)/2)ans=get(2*p,f,(f+t)/2,sa,sb);
  if(ans>=0) return ans;
  if(A[tree[2*p+1]]>=sa && sb<=t)ans=get(2*p+1,(f+t)/2+1,t,sa,sb);
  if(ans>=0) return ans;
  return -1;
}
// </end>
int main(){
  int i,j,k,x,y,last;
  char T;
  //system("pause");
  scanf("%d",&n);
  for(i=0;i<n;i++){
    while(1){scanf("%c",&T);if(T=='P'||T=='D')break;}op.push_back(T);
    if(T=='D'){scanf("%d%d",&x,&y);A.push_back(x);B.push_back(y);ui.push_back(i);use[data(x,y)]=0;}
    else{scanf("%d",&x);A.push_back(x-1);B.push_back(0);}
                  }
  for(it=use.begin(),i=0;it!=use.end();it++,i++)it->second=i;
  last=i-1;
  j=1;
  for(i=0;i<n;i++)if(op[i]=='D'){B[i]=use[data(A[i],B[i])];fp[i]=j;j++;}
  A.push_back(-1);B.push_back(-1);
  init();
  for(i=0;i<n;i++){
   if(op[i]=='D')push(i);
   else{
    if(B[ui[A[i]]]==last) j=-1;
    else j=get(1,0,razm-1,A[ui[A[i]]],B[ui[A[i]]]+1);
    if(j>=0) printf("%d\n",fp[j]);
    else printf("NE\n");
       }
                  }
  //system("pause");
  return 0;
}
