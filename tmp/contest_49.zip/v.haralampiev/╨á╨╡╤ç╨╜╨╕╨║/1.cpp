#include <iostream>
using namespace std;
int mas[15000000];
int main(){
  //system("pause");
  //system("pause");
  return 0;
}
