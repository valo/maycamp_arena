#include <iostream>
#include <cstdio>
#include <map>
#include <vector>
#include <cstring>
#include <algorithm>
#define null -1
#define max_val 100000
using namespace std;
int n,q;
char vhod[30001][32];
int len[30001];
char tar[30001][32];
int tl[30001];
// TRIE
struct vrux{
  int st;map<char,int> next;
  vrux(){st=0;}
  void add(char to,int w){next[to]=w;}
  int get(char to){
   map<char,int>::iterator it=next.find(to);
   if(it==next.end()) return null;
   return it->second;
                   }
};
vrux u[910000];int I=1;
int new_vrux(){I++;return I-1;}
int root=0;
vector<int> path;
void spush(int w){
  int i,p=root,next;path.clear();
  path.push_back(p);
  for(i=0;i<len[w];i++){
   p=u[p].get(vhod[w][i]);
   path.push_back(p);
                       }
  p=u[p].get('$');
  u[p].st=1;for(i=0;i<path.size();i++)u[path[i]].st++;
}
void bpush(int w){
  int i,p=root,next;
  for(i=0;i<len[w];i++){
   next=u[p].get(vhod[w][i]);
   if(next==null){u[p].add(vhod[w][i],new_vrux());next=u[p].get(vhod[w][i]);}
   p=next;
                       }
  u[p].add('$',new_vrux());p=u[p].get('$');
  u[p].st=w;
}
int find(int w){
  int i,p=root,next;
  for(i=0;i<tl[w];i++){
   next=u[p].get(tar[w][i]);
   if(next==null)return max_val;
   p=next;
                       }
  p=u[p].get('$');if(p==null) return max_val;
  return u[p].st;
}
int ob[33];
int parse_word(int w){
  int i,p=root,br=0,next;
  for(i=0;i<=tl[w];i++)ob[i]=0;
  ob[0]=u[p].st;
  for(i=0;i<tl[w];i++){
   next=u[p].get(tar[w][i]);
   if(next==null)break;
   p=next;ob[i+1]=u[p].st;
                       }
  for(i=0;i<tl[w];i++) ob[i]-=ob[i+1];
  int ans=0;for(i=0;i<=tl[w];i++) ans+=(i+1)*ob[i];
  return ans;
}
// </end>
struct elem{
  int i,t;elem(){}elem(int a,int b){i=a;t=b;}
  bool operator<(const elem& w) const{return (i<w.i);}
};
vector<elem> base;
int fp[30010];
int main(){
  //system("pause");
  int i,j,k,l;
  scanf("%d",&n);
  for(i=0;i<n;i++){scanf("%s",&vhod[i]);len[i]=strlen(vhod[i]);}
  scanf("%d",&q);
  for(i=0;i<q;i++){scanf("%s",&tar[i]);tl[i]=strlen(tar[i]);}
  for(i=0;i<n;i++)bpush(i);
  for(i=0;i<q;i++)base.push_back(elem(find(i),i));
  sort(base.begin(),base.end());
  l=0;
  for(i=0;i<q;i++){
   j=base[i].i;if(j==max_val)j=n-1;
   for(;l<=j;l++)spush(l);
   fp[base[i].t]=parse_word(base[i].t);
                  }
  for(i=0;i<q;i++) printf("%d\n",fp[i]);
  //system("pause");
  return 0;
}
