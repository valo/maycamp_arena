#include<cstdio>
#include<algorithm>
#include<string>
#include<iostream>
using namespace std;
struct data
{
    string word;
    int pos;
    int found;
};
data q[30100];
string d[30100];
int rez[30100];
bool f(data a,data b)
{
    if(a.word<=b.word) return 1;
    return 0;
}
int n,m;
int bin(string val)
{
    int l=0,r=m,mid;
    while(l<r)
    {
        mid=(l+r)/2;
        if(q[mid].word==val) return mid;
        else if(q[mid].word>val) r=mid;
        else l=mid+1;
    }
    return -1;
}
struct node
{
    int val;
    node* con[30];
    char conv[30];
    int cos;
};
node* root;
void add(string x,node* cur,int p)
{
    if(p==x.size()) return;
    int pp=0;
    for(int i=0;i<cur->cos;i++)
        if(cur->conv[i]==x[p])
        {
            cur->con[i]->val++;
            add(x,cur->con[i],p+1);
            pp=1;
            break;
        }
    if(pp==0)
    {
        cur->con[cur->cos]=new node;
        cur->conv[cur->cos]=x[p];
        cur->con[cur->cos]->val++;
        cur->cos++;
        add(x,cur->con[cur->cos-1],p+1);
    }
}
int find(string x,node* cur,int p)
{
    if(p==x.size()) return cur->val;
    for(int i=0;i<cur->cos;i++)
        if(cur->conv[i]==x[p])
        return cur->val+find(x,cur->con[i],p+1);
    return cur->val;
}
int main()
{
    root=new node;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    cin>>d[i];
    scanf("%d",&m);
    for(int i=0;i<m;i++)
    {
        cin>>q[i].word;
        q[i].pos=i;
    }
    sort(q,q+m,f);
    int k;
    for(int i=0;i<n;i++)
    {
        add(d[i],root,0);
        k=bin(d[i]);
        if(k!=-1)
        {
            rez[q[k].pos]=find(q[k].word,root,0)+i+1;
            q[k].found=1;
            //cout<<"found "<<q[k].word<<" at "<<i<<endl;
        }
    }
    for(int i=0;i<m;i++)
    if(q[i].found!=1)
    rez[q[i].pos]=find(q[i].word,root,0)+n;
    for(int i=0;i<m;i++)
    cout<<rez[i]<<endl;
}
