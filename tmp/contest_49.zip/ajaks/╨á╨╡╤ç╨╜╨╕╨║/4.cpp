#include<iostream>
#include<vector>
#include<string.h>
using namespace std;

const int maxn=30001;
const int maxl=31;

struct Trie
{
 int br; 
  int end;
   int sons[26];
};
vector <Trie> tree;
Trie t;

int N,Q;
char word[maxl];
int T=0;

void insert()
{
 int n=strlen(word);
   
   int j=0,res=1,p;
  for(int i=0;i<n;i++)
   {  
    p=int(word[i]-'a');      
   tree[j].br++;     res+=tree[j].br - tree[tree[j].sons[p]].br + tree[tree[j].sons[p]].br;           
              
            if(tree[j].sons[p]==0) 
             {
               T++;
              tree[j].sons[p]=T;  
               
               t.br=0;
               t.end=0;
                tree.push_back(t);
                 j=T;
                }  
             else j=tree[j].sons[p];                      
     }
   
   tree[j].br++;
   tree[j].end=res;   
}    

int query()
{
 int j=0,res=1,p; 
  int n=strlen(word);
  
  for(int i=0;i<n;i++)
   {  
    p=int(word[i]-'a');     
     res+=tree[j].br - tree[tree[j].sons[p]].br + tree[tree[j].sons[p]].br; 
     
     if(tree[j].sons[p]==0) return res-1;
       
      j=tree[j].sons[p];
    }
  
if(tree[j].end) return tree[j].end;   
else return res;    
}
    
int main()
{
   t.br=0;
   t.end=0;
    tree.push_back(t); 
    
  scanf("%d", &N);
   
   for(int i=1;i<=N;i++)
    {
    cin>>word;  
     insert();
     }
  
  scanf("%d", &Q);
   
   for(int i=1;i<=Q;i++)
    {
    cin>>word;
     printf("%d\n", query());
     }   

return 0;
}   
