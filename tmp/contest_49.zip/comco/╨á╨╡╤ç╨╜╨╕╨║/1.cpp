#include <cstdio>
using namespace std;

const int max_s = 30010;

int n, q;

char dictionary[max_s][32];

int p[32];

int compare(char* w, char* t, bool& eq){
    int i = 0;
    while(w[i] && t[i]){
        if(w[i] == t[i]){ i++; continue; }
        else break;
    }
    eq = false;
    if(w[i] == 0 && t[i] == 0) eq = true;

    return i+1;
}

char str[32];

int main(){
    scanf("%d", &n);
    for(int i = 0; i < n; i++) scanf(" %s", dictionary[i]);

    scanf("%d", &q);
    for(int j = 0; j < q; j++){
        scanf(" %s", str);
        int i = 0, res = 0;
        bool eq = false;
        while(i < n && !eq){
            res += compare(dictionary[i], str, eq);
            i++;
        }
        printf("%d\n", res);
    }

    return 0;
}
