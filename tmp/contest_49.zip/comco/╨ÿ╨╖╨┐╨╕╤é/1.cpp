#include <cstdio>
#include <cstdlib>
#include <algorithm>

using namespace std;

typedef struct s_quad* quad;
struct s_quad{
    int i;
    int x[3], y[3];
    quad c[4];

    s_quad(int i_, int x_, int y_){
        i = i_;
        x[0] = x[1] = x[2] = x_;
        y[0] = y[1] = y[2] = y_;
        c[0] = c[1] = c[2] = c[3] = 0;
    }

    inline void expand(int x_, int y_){
        x[1] = min(x[1], x_);
        x[2] = max(x[2], x_);
        y[1] = min(y[1], y_);
        y[2] = max(y[2], y_);
    }

    inline bool inside(int x_, int y_){
        return x[1] <= x_ && x_ <= x[2] && y[1] <= y_ && y_ <= y[2];
    }
};

inline int comp(int xn, int yn, int xp, int yp){
    int v = 0;
    if(yn > yp) v += 1;
    if(xn > xp) v += 2;
    return v;
}

quad insert(quad& r, int i, int x, int y){
    if(!r){
        r = new s_quad(i, x, y);
        return r;
    }

    r->expand(x, y);
    int c = comp(x, y, r->x[0], r->y[0]);
    return insert(r->c[c], i, x, y);
}

quad head = new s_quad(0, 0, 0);

quad find(quad r, int x, int y){
    if(!r) return 0;
    if(r->x[2] < x || r->y[2] < y) return 0;
    quad t;
    t = find(r->c[0], x, y); if(t) return t;
    if(x <= r->x[0] && y <= r->y[0]) return r;
    t = find(r->c[1], x, y); if(t) return t;
    t = find(r->c[2], x, y); if(t) return t;
    t = find(r->c[3], x, y); if(t) return t;
    return 0;
}

const int max_n = 200010;
quad t[max_n];

int main(){
    int i, j, a, b, q, n, ld = 1;
    char ch;
    quad u;
    scanf("%d", &n);
    for(q = 0; q < n; q++){
        scanf(" %c", &ch);
        switch(ch){
            case 'D':
                scanf("%d%d", &a, &b);
                t[ld] = insert(head, ld, a, b);
                ld++;
                break;
            case 'P':
                scanf("%d", &a);
                u = find(head, t[a]->x[0], t[a]->y[0] + 1);
                if(u){
                    printf("%d\n", u->i);
                    break;
                }
                u = find(head, t[a]->x[0] + 1, t[a]->y[0]);
                if(u){
                    printf("%d\n", u->i);
                    break;
                }else{
                    printf("NE\n");
                    break;
                }
        }
    }
    return 0;
}
