/*
codr: timiter
task: dictionary
lang: C++
*/

#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

int n, q, p;
int d[32768], s[32], e[32];
char w[32];
char b[32768][32];

bool comp(int, int);

int main()
{
    scanf("%d", &n);
    int i;
    n++;
    d[0] = 0;
    strcpy(b[0], "[ START ]");
    d[1] = 1;
    strcpy(b[1], "{ END }");
    for (i = 2; i <= n; i++)
    {
        d[i] = i;
        scanf("%s", b[i]);
    }
    sort(d, d + n + 1, comp);
    for (i = 0; i <= n; i++)
    {
        //printf("%s\n", b[d[i]]);
    }
    scanf("%d", &q);
    int j, k, l, m, r;
    for (i = 0; i < q; i++)
    {
        scanf("%s", w);
        l = strlen(w);
        for (j = 0; j <= l; j++)
        {
            if (j == 0)
            {
                k = 0;
                r = n;
            }
            else
            {
                k = s[j - 1];
                r = e[j - 1] + 1;
            }
            while (r - k > 1)
            {
                m = (r + k) / 2;
                //printf("--> %d %d %d %d\n", j, k, m, r);
                if (b[d[m]][j] < w[j])
                {
                    k = m;
                }
                if (b[d[m]][j] >= w[j])
                {
                    r = m;
                }
                //printf("->> %d %d %d %d\n", j, k, m, r);
            }
            s[j] = k;
            if (j == 0)
            {
                k = 0;
                r = n;
            }
            else
            {
                k = s[j - 1];
                r = e[j - 1] + 1;
            }
            while (r - k > 1)
            {
                m = (r + k) / 2;
                //printf(">-> %d %d %d %d\n", j, k, m, r);
                if (b[d[m]][j] <= w[j])
                {
                    k = m;
                }
                if (b[d[m + 1]][j] > w[j])
                {
                    r = m;
                }
                //printf(">>> %d %d %d %d\n", j, k, m, r);
            }
            e[j] = k;
            //printf("--> %d %d %d\n", j, s[j], e[j]);
        }
        if (s[l] == e[l])
        {
            p = n - 1;
            for (j = 0; j <= l; j++)
            {
                p += e[j] - s[j];
            }
            printf("%d\n", p);
        }
        else
        {
            p = n - 1;
            for (j = 0; j <= l; j++)
            {
                p += e[j] - s[j];
            }
            printf("%d\n", p);
        }
    }
    return 0;
}

bool comp(int x, int y)
{
    return strcmp(b[x], b[y]) < 0;
}
