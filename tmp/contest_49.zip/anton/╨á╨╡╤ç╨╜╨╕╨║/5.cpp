#include <cstdio>
#include <algorithm>
#include <vector>
#include <cstring>

class TreeNode {

public:
	TreeNode(char letter, int word_id);
	~TreeNode();
	TreeNode* AddNextNode(char letter, int word_id);
	void SetEndNode(unsigned short word_id);
	void Clear();

	char GetLetter() const;
	bool IsEndNode() const;
	unsigned short GetMinWordId() const;
	unsigned short GetCounter() const;
	TreeNode* GetNode(char letter);

private:
	std::vector<TreeNode*> nextNodes;
	bool isEndNode;
	char letter;
	unsigned short minWordId;
	unsigned short counter;
};

TreeNode::TreeNode(char letter, int word_id) :
		letter(letter), minWordId(word_id), isEndNode(false), counter(1) {
}

TreeNode::~TreeNode() {
	for (size_t idx = 0; idx < this->nextNodes.size(); idx++) {
		delete this->nextNodes[idx];
	}
	this->nextNodes.clear();
}

TreeNode* TreeNode::AddNextNode(char letter, int word_id) {
	for (size_t idx = 0; idx < this->nextNodes.size(); idx++) {
		if (this->nextNodes[idx]->GetLetter() == letter) {
			this->nextNodes[idx]->counter++;
			return this->nextNodes[idx];
		}
	}

	TreeNode* new_node = new TreeNode(letter, word_id);
	this->nextNodes.push_back(new_node);
	return new_node;
}

void TreeNode::SetEndNode(unsigned short word_id) {
	if (!this->isEndNode) {
		this->isEndNode = true;
		this->minWordId = word_id;
	}
}

void TreeNode::Clear() {
	for (size_t idx = 0; idx < this->nextNodes.size(); idx++) {
		this->nextNodes[idx]->Clear();
		delete this->nextNodes[idx];
	}

	this->nextNodes.clear();
}

char TreeNode::GetLetter() const {
	return this->letter;
}

bool TreeNode::IsEndNode() const {
	return this->isEndNode;
}

unsigned short TreeNode::GetMinWordId() const {
	return this->minWordId;
}

unsigned short TreeNode::GetCounter() const {
	return this->counter;
}

TreeNode* TreeNode::GetNode(char letter) {
	for (size_t idx = 0; idx < this->nextNodes.size(); idx++) {
		if (this->nextNodes[idx]->letter == letter) {
			return this->nextNodes[idx];
		}
	}

	return NULL;
}

const unsigned MAX_WORD_NUM = 30000;
const unsigned MAX_WORD_LEN = 29;

struct WordIndex {
	unsigned short origId;
	unsigned short dictId;
};

int n, q;
char dict[MAX_WORD_NUM][MAX_WORD_LEN + 1];
char quer[MAX_WORD_NUM][MAX_WORD_LEN + 1];
WordIndex qInd[MAX_WORD_NUM];
unsigned int ans[MAX_WORD_NUM];

void AddWordToTree(TreeNode* root, const char* word, unsigned short word_id) {
	size_t wlen = strlen(word);
	TreeNode* curr_node = root;
	for (size_t i = 0; i < wlen; i++) {
		curr_node = curr_node->AddNextNode(word[i], word_id);
	}

	curr_node->SetEndNode(word_id);
}

unsigned short FindWordInTree(TreeNode* root, const char* q_word) {
	TreeNode* curr_node = root;
	size_t wlen = strlen(q_word);
	size_t cnt = 0;
	while(curr_node != NULL && cnt < wlen) {
		curr_node = curr_node->GetNode(q_word[cnt]);
		cnt++;
	}

	if (curr_node == NULL || (cnt == wlen && !curr_node->IsEndNode())) {
		return n - 1;
	}
	else {
		return curr_node->GetMinWordId();
	}
}

int CountLettersInTree(TreeNode* root, const char* q_word) {
	int res = 0;
	TreeNode* curr_node = root;
	size_t wlen = strlen(q_word);
	size_t cnt = 0;
	while(curr_node != NULL && cnt < wlen) {
		curr_node = curr_node->GetNode(q_word[cnt]);
		if (curr_node) {
			res += curr_node->GetCounter();
		}
		cnt++;
	}

	return res;
}

bool CompareWordIndex(const WordIndex& wi1, const WordIndex& wi2) {
	return wi1.dictId < wi2.dictId;
}

int main() {

	//freopen("c10g1.in", "r", stdin);
	//freopen("c10g1.out", "w", stdout);

	// The root of the tree
	TreeNode root(0, 0);

	scanf("%d\n", &n);
	for (int i = 0; i < n; i++) {
		scanf("%s", dict[i]);
	}

	scanf("%d\n", &q);
	for (int i = 0; i < q; i++) {
		scanf("%s", quer[i]);
	}

	// Create the tree first time
	for (int i = 0; i < n; i++) {
		AddWordToTree(&root, dict[i], i);
	}

	// Find the index for each query word.
	for (int i = 0; i < q; i++) {
		qInd[i].origId = i;
		qInd[i].dictId = FindWordInTree(&root, quer[i]);
	}

	// Clear the tree
	root.Clear();

	// Sort words by ids in the dictionary
	std::sort(qInd, qInd + q, CompareWordIndex);

	// Build the tree again word by word
	int qword_id = 0;
	int i = 0;
	while (i < n) {
		while(i < n && i <= qInd[qword_id].dictId) {
			AddWordToTree(&root, dict[i], i);
			i++;
		}

		while (qword_id < q && qInd[qword_id].dictId == i - 1) {
			ans[qInd[qword_id].origId] = CountLettersInTree(&root, quer[qInd[qword_id].origId]);
			ans[qInd[qword_id].origId] += qInd[qword_id].dictId + 1;
			qword_id++;
		}

		if (qword_id == q) {
			break;
		}
	}

	// Print out the results
	for (int i = 0; i < q; i++) {
		printf("%u\n", ans[i]);
	}

	return 0;
}
/*
#include <iostream>
int main()
{
	freopen("test2.out", "w", stdout);
	int n, c0=0; 
	long long p=1; // 8 байта
	long long p2=1;
	int c1 = 0;
	std::cin>>n;
	for(int i=2;i<=n;i++)
	{
		p=p*i;
		p2=p2*i;
		while((p%10)==0) {
			p=p/10;c0++;
		}
		while((p2%10)==0) {
			p2=p2/10;c1++;
		}

		p=p%1000000; // пазим само последните 6 цифри
		p2=p2%1000;
		if (p%10 != p2%10 || i==124 || i==125) {
			std::cout << i << " " << p << " " << p2 << std::endl;	
		}
	}
	std::cout<<p%10<<" "<<c0<<std::endl;
}
*/
/*
#include <cstdio>
#include <cstdlib>
#include <cstring>

int n, m;
char s[32];
char a[30000][32];

char sorted[30000][32];
int counter[30000][32];
int before[30000][32];
int id[30000];

int cmp( const void *e1, const void *e2 ) {
   return strcmp( (const char *)e1, (const char *)e2 );
}

int find_border( char x, int column, int lo, int hi ) {
   if( x > sorted[hi-1][column] ) return hi;

   while( lo + 1 < hi ) {
      int mid = (lo+hi-1)/2;
      if( x > sorted[mid][column] ) lo = mid+1; else hi = mid+1;
   }

   return lo;
}

int begin[32], end[32];

int search( char *s, int column, int lo, int hi ) {
   begin[column] = end[column] = -1;

   if( s[column] == 0 ) return sorted[lo][column] == 0 ? lo : -1;

   begin[column] = find_border( s[column], column, lo, hi );
   end[column] = find_border( s[column]+1, column, lo, hi );
   
   if( begin[column] == end[column] ) return -1;
   
   return search( s, column + 1, begin[column], end[column] );
}

int main( void ) {
   scanf( "%d", &n );
   for( int i = 0; i < n; ++i ) {
      scanf( "%s", a[i] );
      strcpy( sorted[i], a[i] );
   }
   qsort( sorted, n, 32, cmp );

   for( int i = 0; i < n; ++i ) {
      int row = search( a[i], 0, 0, n );      
      id[row] = i+1;

      for( int column = 0; begin[column] < end[column]; ++column )
         before[row][column] = ++counter[begin[column]][column];      
   }

   scanf( "%d", &m );
   for( int qq = 0; qq < m; ++qq ) {
      scanf( "%s", s );
   
      int ret = 0;
      int row = search( s, 0, 0, n );
      if( row == -1 ) {
         ret += n;
         for( int column = 0; begin[column] < end[column]; ++column )
            ret += counter[begin[column]][column];
      } else {
         ret += id[row];
         for( int column = 0; s[column]; ++column ) 
            ret += before[row][column];
      }

      printf( "%d\n", ret );
   }
   
   return 0;
}
*/
