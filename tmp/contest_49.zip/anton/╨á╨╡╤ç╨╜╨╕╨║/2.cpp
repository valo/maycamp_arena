#include <cstdio>
#include <algorithm>
#include <vector>

class TreeNode {

public:
	TreeNode(char letter, int word_id);
	~TreeNode();
	TreeNode* AddNextNode(char letter, int word_id);
	void SetEndNode(unsigned short word_id);
	void Clear();

	char GetLetter() const;
	bool IsEndNode() const;
	unsigned short GetMinWordId() const;
	unsigned short GetCounter() const;
	TreeNode* GetNode(char letter);

private:
	std::vector<TreeNode*> nextNodes;
	bool isEndNode;
	char letter;
	unsigned short minWordId;
	unsigned short counter;
};

TreeNode::TreeNode(char letter, int word_id) :
		letter(letter), minWordId(word_id), isEndNode(false), counter(1) {
}

TreeNode::~TreeNode() {
	for (size_t idx = 0; idx < this->nextNodes.size(); idx++) {
		delete this->nextNodes[idx];
	}
	this->nextNodes.clear();
}

TreeNode* TreeNode::AddNextNode(char letter, int word_id) {
	for (size_t idx = 0; idx < this->nextNodes.size(); idx++) {
		if (this->nextNodes[idx]->GetLetter() == letter) {
			this->nextNodes[idx]->counter++;
			return this->nextNodes[idx];
		}
	}

	TreeNode* new_node = new TreeNode(letter, word_id);
	this->nextNodes.push_back(new_node);
	return new_node;
}

void TreeNode::SetEndNode(unsigned short word_id) {
	if (!this->isEndNode) {
		this->isEndNode = true;
		this->minWordId = word_id;
	}
}

void TreeNode::Clear() {
	for (size_t idx = 0; idx < this->nextNodes.size(); idx++) {
		this->nextNodes[idx]->Clear();
		delete this->nextNodes[idx];
	}

	this->nextNodes.clear();
}

char TreeNode::GetLetter() const {
	return this->letter;
}

bool TreeNode::IsEndNode() const {
	return this->isEndNode;
}

unsigned short TreeNode::GetMinWordId() const {
	return this->minWordId;
}

unsigned short TreeNode::GetCounter() const {
	return this->counter;
}

TreeNode* TreeNode::GetNode(char letter) {
	for (size_t idx = 0; idx < this->nextNodes.size(); idx++) {
		if (this->nextNodes[idx]->letter == letter) {
			return this->nextNodes[idx];
		}
	}

	return NULL;
}

const unsigned MAX_WORD_NUM = 30000;
const unsigned MAX_WORD_LEN = 29;

struct WordIndex {
	unsigned short origId;
	unsigned short dictId;
};

int n, q;
char dict[MAX_WORD_NUM][MAX_WORD_LEN + 1];
char quer[MAX_WORD_NUM][MAX_WORD_LEN + 1];
WordIndex qInd[MAX_WORD_NUM];
unsigned int ans[MAX_WORD_NUM];

void AddWordToTree(TreeNode* root, const char* word, unsigned short word_id) {
	size_t wlen = strlen(word);
	TreeNode* curr_node = root;
	for (size_t i = 0; i < wlen; i++) {
		curr_node = curr_node->AddNextNode(word[i], word_id);
	}

	curr_node->SetEndNode(word_id);
}

unsigned short FindWordInTree(TreeNode* root, const char* q_word) {
	TreeNode* curr_node = root;
	size_t wlen = strlen(q_word);
	size_t cnt = 0;
	while(curr_node != NULL && cnt < wlen) {
		curr_node = curr_node->GetNode(q_word[cnt]);
		cnt++;
	}

	if (curr_node == NULL || (cnt == wlen && !curr_node->IsEndNode())) {
		return n - 1;
	}
	else {
		return curr_node->GetMinWordId();
	}
}

int CountLettersInTree(TreeNode* root, const char* q_word) {
	int res = 0;
	TreeNode* curr_node = root;
	size_t wlen = strlen(q_word);
	size_t cnt = 0;
	while(curr_node != NULL && cnt < wlen) {
		curr_node = curr_node->GetNode(q_word[cnt]);
		if (curr_node) {
			res += curr_node->GetCounter();
		}
		cnt++;
	}

	return res;
}

bool CompareWordIndex(WordIndex& wi1, WordIndex& wi2) {
	return wi1.dictId < wi2.dictId;
}

int main() {

	//freopen("c10g1.in", "r", stdin);
	//freopen("c10g1.out", "w", stdout);

	// The root of the tree
	TreeNode root(0, 0);

	scanf("%d\n", &n);
	for (int i = 0; i < n; i++) {
		scanf("%s", dict[i]);
	}

	scanf("%d\n", &q);
	for (int i = 0; i < q; i++) {
		scanf("%s", quer[i]);
	}

	// Create the tree first time
	for (int i = 0; i < n; i++) {
		AddWordToTree(&root, dict[i], i);
	}

	// Find the index for each query word.
	for (int i = 0; i < q; i++) {
		qInd[i].origId = i;
		qInd[i].dictId = FindWordInTree(&root, quer[i]);
	}

	// Clear the tree
	root.Clear();

	// Sort words by ids in the dictionary
	std::sort(qInd, qInd + q, CompareWordIndex);

	// Build the tree again word by word
	int qword_id = 0;
	int i = 0;
	while (i < n) {
		while(i < n && i <= qInd[qword_id].dictId) {
			AddWordToTree(&root, dict[i], i);
			i++;
		}

		while (qword_id < q && qInd[qword_id].dictId == i - 1) {
			ans[qInd[qword_id].origId] = CountLettersInTree(&root, quer[qInd[qword_id].origId]);
			ans[qInd[qword_id].origId] += qInd[qword_id].dictId + 1;
			qword_id++;
		}

		if (qword_id == q) {
			break;
		}
	}

	// Print out the results
	for (int i = 0; i < q; i++) {
		printf("%u\n", ans[i]);
	}

	return 0;
}
