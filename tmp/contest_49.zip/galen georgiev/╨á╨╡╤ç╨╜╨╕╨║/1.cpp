#include<iostream>
#include<string>
using namespace std;
int main()
{
    string dic[30000];
    string s;
    int n,m,i,j,br=0,k;
    cin>>n;
    for(i=0;i<n;i++)
    cin>>dic[i];
    cin>>m;
    for(i=0;i<m;i++)
    {
        br=0;
        cin>>s;
        int t=s.size();
        for(j=0;j<n;j++)
        {
            int r=dic[j].size();
            int pos=0,l=0;
            while(1)
            {
                if(dic[j][pos]==s[pos])
                {
                    br++;
                    if(dic[j].substr(0,pos)==s)
                    {
                        l=1;
                        break;
                    }
                }
                else
                {
                    br++;
                    break;
                }
                if(pos>=r||pos>=t) break;
                pos++;
            }
            if(l==1) break;
        }
        cout<<br<<endl;
    }
    return 0;
}
