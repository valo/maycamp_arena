#include<cstdio>
#include<iostream>
#include<vector>
#include<queue>
#include<algorithm>
using namespace std;
struct student
{
    int understand,amount,index;
    bool operator < (const student &p) const{
        if(understand<p.understand) return 1;
        if(understand==p.understand) return amount<p.amount;
        return 0;
    }
};
vector<student>v,vsort;
queue<int>q;
int n,m;
void read()
{
    int i,a,b;
    char c;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        cin>>c;
        if(c=='D')
        {
            scanf("%d%d",&a,&b);
            student p;
            p.understand=a;
            p.amount=b;
            v.push_back(p);
            p.index=m;
            vsort.push_back(p);
            m+=1;
        }
        else
        {
            scanf("%d",&a);
            q.push(a);
        }
    }
}
void init()
{
    int i;
    for(i=0;i<m;i++)
    v[vsort[i].index].index=i;
}
void solve()
{
    int i;
    sort(vsort.begin(),vsort.end());
    init();
    while(!q.empty())
    {
        int tc=q.front()-1,l=0;
        q.pop();
        for(i=v[tc].index+1;i<m;i++)
        if(v[tc].understand<=vsort[i].understand)
        if(v[tc].amount<=vsort[i].amount)
        {
            printf("%d\n",vsort[i].index+1);
            l=1;
            break;
        }
        if(l==0) printf("NE\n");
    }
}
int main()
{
    read();
    solve();
    return 0;
}
