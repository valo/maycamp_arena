#include<iostream>
#include<vector>
#include<cmath>
using namespace std;
vector<long long>D1,D2,P;
long long MIN=9999999;
long long n;
void read()
{
    int i,a,b,j=0;
    char c;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>c;
        if(c=='D')
        {
            cin>>a>>b;
            D1.push_back(a);
            D2.push_back(b);
        }
        if(c=='P')
        {
            cin>>a;
            P.push_back(a);
        }
    }
}
void solve()
{
    long long m=P.size(),t=D1.size();
    long long i,j,k,ans;
    for(i=0;i<m;i++)
    {
        long long sum=0,min=MIN,ans=-1;
        sum=D1[P[i]-1]+D2[P[i]-1];
        for(j=0;j<t;j++)
        {
            if(D1[j]>=D1[P[i]-1]&&D2[j]>=D2[P[i]-1])
            if(abs(sum-(D1[j]+D2[j]))<min&&abs(sum-(D1[j]+D2[j]))>0)
            {
                min=abs(sum-D1[j]+D2[j]);
                ans=j+1;
            }
        }
        if(ans==-1) cout<<"NE"<<endl;
        else cout<<ans<<endl;
    }
}
int main()
{
    read();
    solve();
    return 0;
}
