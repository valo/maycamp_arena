#include<iostream>
using namespace std;
long long n,k,i,a[1024][8];
int main()
{
    cin>>n;
    a[2][1]=1;
    a[2][2]=9;
    a[2][3]=80;
    a[2][4]=1;
    k=90;
    for(i=3;i<=n;i++)
    {
       k=(k*10)%12345678;
       a[i][1]=(a[i-1][1]*10+a[i-1][2])%12345678;
       a[i][2]=(a[i-1][2]+a[i-1][3])%12345678;
       a[i][3]=(k-a[i][1]-a[i][2])%12345678;
       a[i][4]=(a[i-1][4]+a[i][1])%12345678;
       //cout<<a[i][1]<<" "<<a[i][2]<<" "<<a[i][3]<<" "<<a[i][4]<<endl;
    }
    cout<<a[n][4]<<endl;
    //system("pause");
    return 0;
}
