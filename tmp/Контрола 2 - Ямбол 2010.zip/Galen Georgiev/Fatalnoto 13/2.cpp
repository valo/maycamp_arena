#include<iostream>
using namespace std;
long long n,k=12345678;
long long stepen(long long m)
{
    long long i,st=1;
    for(i=1;i<m;i++)
    st=(st*10)%k;
    st=(st*9)%k;
    return st;
}
int main()
{
    int i,a=80,b=9,c=1,ans=1,a1;
    cin>>n;
    for(i=3;i<=n;i++)
    {
        a1=stepen(i);
        c=((c*10)+b)%k;
        b=(a+b)%k;
        a=(a1-((b+c)%k))%k;
        ans=(ans+c)%k;
    }
    cout<<ans<<endl;
    return 0;
}
