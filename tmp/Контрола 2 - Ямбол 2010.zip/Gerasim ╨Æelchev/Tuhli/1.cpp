#include <iostream>
#include <algorithm>
using namespace std;
struct data { int a, b, c; } a[500], m[3000];
int dp[3000];
int i, j, n, k, ans;

bool cmp(data x,data y)
{
if(x.a != y.a) return x.a < y.a;
return x.b < y.b;
}
int main()
{
scanf("%d", &n);
for(i=0; i<n; i++)
{
scanf("%d%d%d", &a[i].a, &a[i].b, &a[i].c);
m[k].a = a[i].a, m[k].b = a[i].b, m[k].c = a[i].c;
k++;
m[k].a = a[i].b, m[k].b = a[i].a, m[k].c = a[i].c;
k++;
m[k].a = a[i].a, m[k].b = a[i].c, m[k].c = a[i].b;
k++;
m[k].a = a[i].c, m[k].b = a[i].a, m[k].c = a[i].b;
k++;
m[k].a = a[i].b, m[k].b = a[i].c, m[k].c = a[i].a;
k++;
m[k].a = a[i].c, m[k].b = a[i].b, m[k].c = a[i].a;
k++;
}
sort(m, m+k, cmp);
for(i=0; i<k; i++)
{
dp[i] = m[i].c;
for(j=0; j<i; j++)
if(m[j].a < m[i].a && m[j].b < m[i].b)
dp[i] = max(dp[j] + m[i].c, dp[i]);
ans = max(ans, dp[i]);
}
printf("%d\n", ans);
return 0;
}
