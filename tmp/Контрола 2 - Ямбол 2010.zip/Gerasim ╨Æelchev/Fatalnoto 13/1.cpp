#include <iostream>
#define MOD 12345678
using namespace std;

int i, j, k, n, ans, dp[1001][10];
long long pow(int x)
{
if(x == 0) return 1;
if(x == 1) return 10;
if(x == 2) return 100;
long long w = pow(x / 2);
if(!(x % 2)) return (w * w) % MOD;
return (10 * w * w) % MOD;
}

int main()
{
scanf("%d", &n);
for(i=1; i<=9; i++) dp[1][i] = 1, ans++;

for(i=2; i<=n; i++)
for(j=0; j<=9; j++)
{
for(k=0; k<=9; k++)
{
if(j == 3 && k == 1) continue;
dp[i][j] = (dp[i][j] + dp[i-1][k]) % MOD;
}
ans = (ans + dp[i][j]) % MOD;
}
printf("%lld\n", (pow(n) - 1 - ans + MOD) % MOD);
return 0;
}
