/*
TASK: wpipe
LANG: C++
*/
#include <iostream>
#include <stdio.h>

using namespace std;

const int MAXSZ = 1510;

int dx,dy;
int dp[MAXSZ][MAXSZ];
int way[MAXSZ][MAXSZ][4];
int n,br;
int x1,y1,x2,y2;

void init()
{
    scanf("%d %d",&dx,&dy);
    swap(dx,dy);
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&br);
        for(int j=0;j<br;j++)
        {
            scanf("%d %d %d %d",&x1,&y1,&x2,&y2);
            swap(x1,y1);
            swap(x2,y2);
            if(y1==y2)
            {
                if(x1>x2) swap(x1,x2);

                //cout << x1 << " " << y1 << " " << x2 << " " << y2 << " " << "2/3" << endl;
                for(int k=x1+1;k<x2;k++)
                {
                    way[k][y1][2]=1;
                    way[k][y2][3]=1;
                }
                way[x1][y1][3]=1;
                way[x2][y1][2]=1;
            }
            else
            {
                if(y1>y2) swap(y1,y2);

                //cout << x1 << " " << y1 << " " << x2 << " " << y2 << " " << "0/1" << endl;
                for(int k=y1+1;k<y2;k++)
                {
                    way[x1][k][0]=1;
                    way[x1][k][1]=1;
                }
                way[x1][y1][0]=1;
                way[x1][y2][1]=1;
            }
        }
    }
/*
    for(int i=0;i<=dx;i++)
    {
        for(int j=0;j<=dy;j++) cout << way[i][j][2] << " ";
        cout << endl;
    }
*/
}

void solve()
{
    for(int i=0;i<=dx;i++)
        for(int j=0;j<=dy;j++)
            if(i || j)
            {
                dp[i][j]=2*MAXSZ;
                if(j-1>=0)
                    if(way[i][j][1]) dp[i][j]=min(dp[i][j],dp[i][j-1]);
                    else dp[i][j]=min(dp[i][j],dp[i][j-1]+1);
                if(i-1>=0)
                    if(way[i][j][2]) dp[i][j]=min(dp[i][j],dp[i-1][j]);
                    else dp[i][j]=min(dp[i][j],dp[i-1][j]+1);
            }

    cout << dp[dx][dy] << endl;
}

int main()
{
    init();
    solve();

    return 0;
}
