/*
TASK: tuhli
LANG: C++
*/
#include <iostream>
#include <stdio.h>
#include <vector>
#include <algorithm>

#define pb push_back

using namespace std;

const int MAXN = (1<<9);

typedef struct
{
    int a,b,c;
} Brick;

int n;
Brick tmp;
vector<Brick> m;
int dp[3*MAXN];

Brick f(Brick t,int k)
{
    if(k==0) swap(t.c,t.a);
    if(k==1) swap(t.c,t.b);

    if(t.a<t.b) swap(t.a,t.b);
    return t;
}

bool cmp(Brick t1,Brick t2)
{
    if(t1.a<t2.a) return true;
    if(t1.a>t2.a) return false;
    if(t1.b<t2.b) return true;
    return true;
}

void init()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d %d %d",&tmp.a,&tmp.b,&tmp.c);
        if(tmp.a>tmp.b) swap(tmp.a,tmp.b);
        if(tmp.a>tmp.c) swap(tmp.a,tmp.c);
        if(tmp.b>tmp.c) swap(tmp.b,tmp.c);

        m.pb( f(tmp,0) );
        if(tmp.b!=tmp.a) m.pb( f(tmp,1) );
        if(tmp.c!=tmp.a && tmp.c!=tmp.b) m.pb( f(tmp,2) );
    }
    sort(m.begin(),m.end(),cmp);

    //for(int i=0;i<m.size();i++) cout << m[i].a << " " << m[i].b << " " << m[i].c << endl;
}

void solve()
{
    for(int i=0;i<m.size();i++)
    {
        int mx=m[i].c;
        for(int j=0;j<i;j++)
            if(m[i].a>m[j].a && m[i].b>m[j].b && mx<dp[j]+m[i].c)
                mx=dp[j]+m[i].c;
        dp[i]=mx;
    }

    int ans=-1;
    for(int i=0;i<m.size();i++)
        if(ans<dp[i])
            ans=dp[i];
    cout << ans << endl;
}

int main()
{
    init();
    solve();

    return 0;
}
