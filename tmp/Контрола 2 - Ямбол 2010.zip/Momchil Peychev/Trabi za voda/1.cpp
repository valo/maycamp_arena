#include <stdio.h>
#include <iostream>
#include <algorithm>

#define x first
#define y second
#define mp make_pair

using namespace std;

inline int min(int s1,int s2)
{
    if(s1<=s2) return s1;
    return s2;
}

inline int abs(int x)
{
    if(x<0) x=-x;
    return x;
}

typedef pair<int,int> Point;
typedef struct
{
    Point a,b;
    void read()
    {
        scanf("%d %d %d %d",&a.x,&a.y,&b.x,&b.y);
        if(a.x==b.x && a.y>b.y) swap(a,b);
        if(a.y==b.y && a.x>b.x) swap(a,b);
    }
} Seg;

const int MAXN = (1<<7);
const int MAXB = (1<<5);
const int MAXD = (1<<20);

int X,Y;
int n;
int b[MAXN];
Seg data[MAXN][MAXB];
int g[MAXN][MAXN];

Seg make(int _x1,int _y1,int _x2,int _y2)
{
    Seg ret;
    ret.a=mp(_x1,_y1);
    ret.b=mp(_x2,_y2);
    return ret;
}

void init()
{
    scanf("%d %d",&X,&Y);
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&b[i]);
        for(int j=0;j<b[i];j++)
            data[i][j].read();
    }
    data[n][0]=make(0,0,0,0); b[n]=1; n++;
    data[n][0]=make(X,Y,X,Y); b[n]=1; n++;
}

inline int len(Point a,Point b) { return abs(a.x-b.x)+abs(a.y-b.y); }

inline int _dist(Seg p,Seg q)
{
    if(p.a.x!=p.b.x)
    {
        swap(p.a.x,p.a.y);
        swap(p.b.x,p.b.y);
        if(p.a.y>p.b.y) swap(p.a,p.b);
        swap(q.a.x,q.a.y);
        swap(q.b.x,q.b.y);
        if(q.a.y>q.b.y) swap(q.a,q.b);
    }
        if(q.a.x==q.b.y)
        {
            if(q.a.y>p.b.y) return len(p.b,q.a);
            if(p.a.y>q.b.y) return len(p.a,q.b);
            return abs(p.a.x-q.a.x);
        }
        else
        {
            if(q.a.x<=p.a.x && p.a.x<=q.b.x)
            {
                if(p.a.y<=q.a.y && q.a.y<=p.b.y) return 0;
                return min( abs(p.a.y-q.a.y) , abs(p.b.y-q.a.y) );
            }
            else
            {
                if(p.a.y<=q.a.y && q.a.y<=p.b.y) return min( abs(q.a.x-p.a.x) , abs(q.b.x-p.a.x) );
                else
                {
                    int ret;
                    ret=len(p.a,q.a);
                    ret=min(ret,len(p.a,q.b));
                    ret=min(ret,len(p.b,q.a));
                    ret=min(ret,len(p.b,q.b));
                    return ret;
                }
            }
        }
}

inline int dist(int _1,int _2)
{
    int ret=MAXD;
    for(int i=0;i<b[_1];i++)
        for(int j=0;j<b[_2];j++)
        {
            int tmp=_dist(data[_1][i],data[_2][j]);
            if(ret>tmp) ret=tmp;
        }
    
    return ret;
}

void build()
{
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            if(i==j) g[i][j]=0;
            else g[i][j]=dist(i,j);
}

void floyd()
{
    for(int k=0;k<n;k++)
        for(int i=0;i<n;i++)
            for(int j=0;j<n;j++)
                if(g[i][k]+g[k][j]<g[i][j])
                    g[i][j]=g[i][k]+g[k][j];
}

int main()
{
    init();
    build();
    floyd();
    printf("%d\n",g[n-2][n-1]);
    
    return 0;
}
